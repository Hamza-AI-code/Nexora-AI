# 📘 Nexora AI — Frontend Documentation (`readmeFrontendResumer.md`)

> **Système d'Automatisation Intelligent de Centre d'Appels Propulsé par l'IA**
> PFA 2025–2026 — **Yassine Sinif** & **Hamza Zaidi**
> A B2B AI-powered call center automation SaaS targeting **Morocco & MENA markets**.

---

## 1. 🎯 What is this app?

**Nexora AI** is a SaaS platform that lets Moroccan/MENA call centers **automate 70–85% of their customer support** with a multilingual AI agent (French, Arabic, Darija, English).

The platform offers:

| Feature | Description |
|---|---|
| 🤖 **AI Chatbot 24/7** | Answers customers on WhatsApp, web chat, voice — using RAG over the company's knowledge base |
| 👥 **Human handoff** | Seamless takeover from AI → human agent when needed |
| 🎫 **Ticketing** | Auto-creates, prioritizes & assigns tickets |
| 📚 **Knowledge Base (RAG)** | Indexes PDFs / URLs / FAQs into a vector store for grounded answers |
| 📊 **Analytics** | Real-time KPIs: cost saved (MAD), auto-resolve rate, sentiment, SLA |
| 🔌 **Integrations** | WhatsApp Business API, HubSpot, Salesforce, Zendesk, Slack |
| 🇲🇦 **MENA-ready** | Darija support, CNDP (Loi 09-08) compliance, MAD pricing |

**Target customers:** E-commerce, telecoms, banks, insurance, public services in Morocco and MENA.

---

## 2. 🧱 Tech Stack

| Layer | Technology |
|---|---|
| Framework | **TanStack Start v1** (React 19 + SSR) |
| Build | **Vite 7** |
| Routing | **TanStack Router** (file-based) |
| Styling | **Tailwind CSS v4** (via `src/styles.css`) |
| UI Primitives | **shadcn/ui** (Radix-based) |
| Charts | **Recharts** |
| Animation | **Framer Motion** |
| Icons | **Lucide React** |
| State | Local React state + custom API client (see §5) |

---

## 3. 📂 Project Structure

```
src/
├── routes/                          # File-based routing (TanStack Router)
│   ├── __root.tsx                   # HTML shell + global providers
│   ├── index.tsx                    # 🏠 Landing page (marketing)
│   ├── dashboard.tsx                # Protected layout (sidebar + outlet)
│   ├── dashboard.index.tsx          # 📊 Dashboard overview (KPIs + activity)
│   ├── dashboard.conversations.tsx  # 💬 3-pane chat UI (AI/Human takeover)
│   ├── dashboard.tickets.tsx        # 🎫 Ticket list + filters
│   ├── dashboard.knowledge.tsx      # 📚 RAG document manager
│   ├── dashboard.analytics.tsx      # 📈 Charts & comparisons
│   ├── dashboard.insights.tsx       # 🧠 AI-driven insights
│   └── dashboard.settings.tsx       # ⚙️  Tabs: company, integrations, AI, etc.
│
├── components/
│   ├── dashboard/
│   │   ├── header.tsx               # Top bar (title, search, user menu, theme)
│   │   └── sidebar.tsx              # Collapsible left nav
│   └── ui/                          # shadcn/ui primitives (button, card, …)
│
├── lib/
│   ├── api.ts                       # 🔌 API CLIENT — single source of truth (READ THIS)
│   ├── mock-data.ts                 # Mock data fed into api.ts during dev
│   └── utils.ts                     # cn() helper
│
├── styles.css                       # Tailwind + design tokens (OKLCH dark/light)
├── router.tsx                       # Router bootstrap
└── server.ts                        # SSR entry (Cloudflare Worker)
```

---

## 4. 🛣️ User Journey

### 👤 Visitor (Marketing)
```
1. Lands on  /                           → Hero, value props, animated AI chat demo
2. Clicks    "Demander une démo"         → (future) lead form
3. Clicks    "Voir la démo"              → /dashboard (no auth gate in demo)
```

### 👨‍💼 Admin / Manager (Dashboard)
```
1. /dashboard              → KPI cards (cost saved MAD, auto-resolve %, etc.)
                           → Live activity feed (simulated)
2. /dashboard/conversations → Pick a conversation → see messages
                           → Toggle AI ↔ Human takeover
                           → AI summary panel on the right
3. /dashboard/tickets      → Filter by status/priority → assign agent
4. /dashboard/knowledge    → Upload PDF / paste URL → reindex
5. /dashboard/analytics    → Cost-saving trends, AI vs Human resolution
6. /dashboard/insights     → AI-suggested improvements
7. /dashboard/settings     → Company profile, integrations, AI model tuning
```

### 🧑‍💻 Agent (UI-only role today)
- Same routes, but write actions on Settings/Knowledge should be hidden.
- A future `useRole()` hook will gate UI based on `auth.me().role`.

---

## 5. 🔌 API Integration Layer — `src/lib/api.ts`

**This is the most important file for the backend team.**

Every backend call the frontend will ever make is declared in `src/lib/api.ts`. Today each method returns mock data after a simulated delay (`USE_MOCK = true`). When the backend is ready, flip the flag and the real `fetch()` calls take over — **no other file in the app needs to change**.

### Usage in components
```tsx
import { api } from "@/lib/api";

const kpis = await api.dashboard.getKPIs();
const msgs = await api.conversations.getMessages("c1");
await api.conversations.sendMessage("c1", "Bonjour", "agent");
```

### Configuration
```bash
# .env
VITE_API_BASE_URL=https://api.nexora-ai.ma/v1
```

### Endpoints expected from backend

| Domain | Method + Path | Purpose |
|---|---|---|
| **Auth** | `POST /auth/login` | email/password → JWT |
| | `POST /auth/logout` | invalidate session |
| | `GET  /auth/me` | current user |
| **Dashboard** | `GET /dashboard/kpis` | aggregated KPIs |
| | `GET /dashboard/activity` | live event feed |
| **Conversations** | `GET  /conversations` | list |
| | `GET  /conversations/:id/messages` | thread |
| | `POST /conversations/:id/messages` | send (as AI or agent) |
| | `POST /conversations/:id/takeover` | switch AI ↔ human |
| | `POST /conversations/:id/summarize` | AI summary + intents + sentiment |
| **Tickets** | `GET /tickets?status=&priority=` | filtered list |
| | `PATCH /tickets/:id` | update |
| | `POST /tickets/:id/assign` | assign to agent |
| **Analytics** | `GET /analytics/ticket-volume?range=7d` | chart data |
| | `GET /analytics/cost-savings?range=6m` | chart data |
| **Knowledge (RAG)** | `GET /knowledge/documents` | list |
| | `POST /knowledge/documents` | upload (multipart) |
| | `DELETE /knowledge/documents/:id` | remove |
| | `POST /knowledge/query` | vector search → top-k chunks |
| **Settings** | `GET/PATCH /settings/company` | company profile |
| | `GET/PATCH /settings/ai` | model, temperature, system prompt |
| | `GET /settings/integrations` | list |
| | `POST /settings/integrations/:id/connect` | OAuth/credentials handshake |
| **Webhooks (incoming)** | `POST /webhooks/whatsapp` | Meta WABA events |
| | `POST /webhooks/voice` | Twilio / Genesys |
| | `POST /webhooks/crm/:vendor` | HubSpot / Salesforce sync |

### Auth contract
- Frontend stores JWT in `localStorage.nexora_token`.
- Every request adds `Authorization: Bearer <jwt>`.
- 401 responses should redirect to `/auth/login` (TODO route).

---

## 6. 🏗️ How to Build the Backend

### Recommended stack
| Concern | Recommended |
|---|---|
| API | **FastAPI** (Python) or **NestJS** (Node) |
| Database | **PostgreSQL** (Supabase if you want managed auth + storage) |
| Vector store (RAG) | **pgvector** or **Qdrant** |
| LLM | **OpenAI GPT-4** (prod) + **Llama 3 70B** (sovereign hosting option) |
| Queue | **Redis** + **Celery** / BullMQ (for async AI jobs) |
| Messaging | **WhatsApp Business API** (via Meta Cloud API) |
| Voice | **Twilio** or **Genesys** |
| Hosting | **Cloudflare Workers** (frontend SSR) + **AWS Casablanca / OVH MA** (backend, for CNDP compliance) |

### Suggested DB schema (simplified)
```sql
users           (id, email, name, role, password_hash, created_at)
companies       (id, name, sector, country, timezone, ai_config jsonb)
conversations   (id, company_id, customer_name, channel, takeover, sentiment, created_at)
messages        (id, conversation_id, role, content, sentiment, created_at)
tickets         (id, company_id, conversation_id, intent, priority, status, agent_id)
knowledge_docs  (id, company_id, title, source, storage_path, indexed_at)
knowledge_chunks(id, doc_id, content, embedding vector(1536))  -- pgvector
integrations    (id, company_id, vendor, credentials jsonb, connected_at)
activity_log    (id, company_id, type, payload jsonb, created_at)
```

### Implementation order
1. **Auth + users + companies** — JWT, multi-tenancy via `company_id`
2. **Knowledge ingestion** — upload PDF → chunk → embed → store in pgvector
3. **RAG query endpoint** — `/knowledge/query` returning top-k chunks
4. **AI chat endpoint** — LLM call grounded with retrieved chunks
5. **WhatsApp webhook** — receive message → run AI chain → reply via Meta API
6. **Conversations & messages** — persistence + real-time push (SSE or WebSocket)
7. **Tickets** — auto-create from conversations, classification model for priority
8. **Analytics aggregations** — daily roll-ups into materialized views
9. **Integrations** — HubSpot / Salesforce OAuth + bi-directional sync

### Realtime
Frontend currently polls. For production add **Server-Sent Events** on:
- `GET /conversations/:id/stream` — new messages
- `GET /dashboard/activity/stream` — live activity feed

### Security & compliance (MENA)
- ✅ Host data **in Morocco** (CNDP Loi 09-08)
- ✅ Encrypt at rest (AES-256) and in transit (TLS 1.3)
- ✅ Audit logs for every admin action
- ✅ 2FA on admin accounts
- ✅ Data Processing Agreement (DPA) template per client

---

## 7. 🎨 Design System

- **Theme:** Dark by default, light toggle in header
- **Colors:** OKLCH palette, semantic tokens in `src/styles.css`
- **Effects:** `.glass` (glassmorphism), `.gradient-primary`, `.shadow-glow`
- **Spacing & radius:** Tailwind defaults + custom `--radius` token
- **Typography:** System UI stack (replaceable with Inter or SF Pro)
- ⚠️ **Never hardcode colors** (`text-white`, `bg-[#000]`) — always use semantic tokens

---

## 8. 🚀 Run Locally

```bash
bun install
bun dev          # → http://localhost:8080
```

Switch to real backend:
```bash
# .env
VITE_API_BASE_URL=https://your-backend.example.com/v1
# then in src/lib/api.ts:
const USE_MOCK = false;
```

---

## 9. 📌 Roadmap

- [ ] Auth pages (`/login`, `/signup`) + protected route gate
- [ ] Real-time SSE/WebSocket layer
- [ ] Multi-tenant company switcher
- [ ] Billing (Stripe / CMI for MAD)
- [ ] Mobile app (React Native — share `api.ts`)
- [ ] Voice channel (Twilio streams + Whisper transcription)
- [ ] Arabic RTL layout

---

## 10. 👥 Credits

Built with ❤️ by **Yassine Sinif** & **Hamza Zaidi** — PFA 2025–2026.

For backend questions, start with **`src/lib/api.ts`** — it's the contract.
