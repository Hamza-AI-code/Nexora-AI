import { Bell, Search, Sun, Moon, ChevronDown, LogOut } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { cn } from "@/lib/utils";

export function DashboardHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  const [dark, setDark] = useState(true);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ["auth", "me"],
    queryFn: () => api.auth.me(),
  });

  const statusMutation = useMutation({
    mutationFn: (status: "online" | "offline") => api.agents.updateStatus(status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["auth", "me"] });
      queryClient.invalidateQueries({ queryKey: ["agents"] });
    },
  });

  useEffect(() => {
    document.documentElement.classList.toggle("light", !dark);
  }, [dark]);

  function handleLogout() {
    api.auth.logout().finally(() => navigate({ to: "/login" }));
  }

  const initials = user?.name
    ? user.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()
    : "..";

  return (
    <header className="sticky top-0 z-30 h-16 border-b border-border bg-background/70 backdrop-blur-xl flex items-center justify-between px-6 gap-4">
      <div className="min-w-0">
        <h1 className="text-lg font-semibold truncate">{title}</h1>
        {subtitle && <p className="text-xs text-muted-foreground truncate">{subtitle}</p>}
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden md:flex items-center gap-2 px-3 h-9 rounded-lg bg-secondary border border-border w-72">
          <Search className="w-4 h-4 text-muted-foreground" />
          <input
            placeholder="Rechercher tickets, clients..."
            className="bg-transparent text-sm outline-none flex-1 placeholder:text-muted-foreground"
          />
          <kbd className="text-[10px] text-muted-foreground border border-border rounded px-1.5 py-0.5">⌘K</kbd>
        </div>

        <button
          onClick={() => setDark(!dark)}
          className="w-9 h-9 rounded-lg border border-border bg-secondary/50 flex items-center justify-center hover:bg-secondary transition-colors"
          aria-label="Toggle theme"
        >
          {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        <button
          className="w-9 h-9 rounded-lg border border-border bg-secondary/50 flex items-center justify-center hover:bg-secondary transition-colors relative"
          aria-label="Notifications"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-primary pulse-dot" />
        </button>

        <button
          onClick={() => statusMutation.mutate(user?.status === "online" ? "offline" : "online")}
          disabled={!user || statusMutation.isPending}
          className="hidden sm:flex items-center gap-2 px-3 h-9 rounded-lg border border-border bg-secondary/50 hover:bg-secondary transition-colors text-xs font-medium disabled:opacity-60"
          title="Basculer votre disponibilité"
        >
          <span className={cn("w-2 h-2 rounded-full", user?.status === "online" ? "bg-success pulse-dot" : "bg-muted-foreground/40")} />
          {user?.status === "online" ? "En ligne" : "Hors ligne"}
        </button>

        <div className="flex items-center gap-2.5 pl-3 border-l border-border">
          <div className="w-9 h-9 rounded-full gradient-primary flex items-center justify-center text-xs font-semibold text-primary-foreground">
            {initials}
          </div>
          <div className="hidden lg:block leading-tight">
            <div className="text-sm font-medium">{user?.name ?? "..."}</div>
            <div className="text-[11px] text-muted-foreground capitalize">{user?.role ?? ""}</div>
          </div>
          <button
            onClick={handleLogout}
            className="w-9 h-9 rounded-lg border border-border bg-secondary/50 flex items-center justify-center hover:bg-secondary transition-colors"
            aria-label="Déconnexion"
            title="Déconnexion"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
