// Mock data for the SaaS dashboard

export const kpis = {
  conversations: 12847,
  autoResolvedRate: 81.3,
  activeTickets: 142,
  avgResponseTime: 1.8,
  costSaved: 247500,
  conversationsDelta: 12.4,
  resolvedDelta: 4.2,
  ticketsDelta: -8.1,
  responseDelta: -22,
  costDelta: 18.7,
};

export const activityFeed = [
  { id: 1, type: "intent", text: "Intent détecté : Suivi de commande", time: "il y a 2s", channel: "WhatsApp" },
  { id: 2, type: "resolved", text: "Ticket #4821 auto-résolu par l'IA", time: "il y a 14s", channel: "Web" },
  { id: 3, type: "escalation", text: "Escaladé vers Sara M. (Agent humain)", time: "il y a 32s", channel: "WhatsApp" },
  { id: 4, type: "knowledge", text: "Base de connaissances mise à jour : Politique retours", time: "il y a 1min", channel: "Système" },
  { id: 5, type: "intent", text: "Intent détecté : Réclamation facturation", time: "il y a 1min", channel: "Web" },
  { id: 6, type: "resolved", text: "Ticket #4818 résolu — Sentiment positif", time: "il y a 2min", channel: "WhatsApp" },
  { id: 7, type: "intent", text: "Intent détecté : Annulation abonnement", time: "il y a 3min", channel: "Web" },
  { id: 8, type: "knowledge", text: "RAG : 47 documents indexés", time: "il y a 4min", channel: "Système" },
];

export const recentTickets = [
  { id: "T-4821", customer: "Karim El Idrissi", intent: "Suivi commande", priority: "low", status: "resolved", agent: "IA — Auto", channel: "WhatsApp" },
  { id: "T-4820", customer: "Fatima Benali", intent: "Réclamation facture", priority: "high", status: "progress", agent: "Sara M.", channel: "Web" },
  { id: "T-4819", customer: "Yassir Lamrini", intent: "Demande de remboursement", priority: "high", status: "open", agent: "Non assigné", channel: "WhatsApp" },
  { id: "T-4818", customer: "Salma Tazi", intent: "Question produit", priority: "low", status: "resolved", agent: "IA — Auto", channel: "Web" },
  { id: "T-4817", customer: "Omar Chraibi", intent: "Annulation abonnement", priority: "medium", status: "progress", agent: "Hamza Z.", channel: "WhatsApp" },
  { id: "T-4816", customer: "Nadia Bennani", intent: "Technique — Connexion", priority: "medium", status: "open", agent: "Yassine S.", channel: "Web" },
  { id: "T-4815", customer: "Mehdi Alaoui", intent: "Information tarifs", priority: "low", status: "resolved", agent: "IA — Auto", channel: "WhatsApp" },
  { id: "T-4814", customer: "Imane Fassi", intent: "Réclamation livraison", priority: "high", status: "progress", agent: "Sara M.", channel: "WhatsApp" },
];

export const ticketVolumeData = [
  { day: "Lun", total: 980, ai: 790, human: 190 },
  { day: "Mar", total: 1240, ai: 1010, human: 230 },
  { day: "Mer", total: 1480, ai: 1210, human: 270 },
  { day: "Jeu", total: 1380, ai: 1140, human: 240 },
  { day: "Ven", total: 1820, ai: 1520, human: 300 },
  { day: "Sam", total: 1620, ai: 1340, human: 280 },
  { day: "Dim", total: 1110, ai: 920, human: 190 },
];

export const costSavingsData = [
  { month: "Jan", saved: 142000 },
  { month: "Fév", saved: 168000 },
  { month: "Mar", saved: 189000 },
  { month: "Avr", saved: 205000 },
  { month: "Mai", saved: 231000 },
  { month: "Juin", saved: 247500 },
];

export const automationDonut = [
  { name: "Auto-résolu IA", value: 81.3 },
  { name: "Agent humain", value: 18.7 },
];

export const handlingTimeData = [
  { week: "S1", before: 12.4, after: 2.1 },
  { week: "S2", before: 11.8, after: 1.9 },
  { week: "S3", before: 12.2, after: 1.8 },
  { week: "S4", before: 11.5, after: 1.7 },
];

export const conversations = [
  { id: "c1", name: "Karim El Idrissi", phone: "+212 6 12 34 56 78", last: "Merci, le problème est résolu 🙏", time: "10:42", unread: 0, channel: "whatsapp", sentiment: "positive", online: true, avatar: "KE" },
  { id: "c2", name: "Fatima Benali", phone: "+212 6 65 43 21 09", last: "Je n'ai toujours pas reçu ma facture corrigée", time: "10:38", unread: 2, channel: "whatsapp", sentiment: "negative", online: true, avatar: "FB" },
  { id: "c3", name: "Yassir Lamrini", phone: "+212 6 22 11 88 44", last: "Bonjour, je souhaite un remboursement", time: "10:21", unread: 1, channel: "web", sentiment: "neutral", online: false, avatar: "YL" },
  { id: "c4", name: "Salma Tazi", phone: "+212 6 77 88 99 11", last: "Parfait, merci beaucoup !", time: "09:55", unread: 0, channel: "web", sentiment: "positive", online: false, avatar: "ST" },
  { id: "c5", name: "Omar Chraibi", phone: "+212 6 44 55 66 77", last: "Je veux annuler mon abonnement", time: "09:42", unread: 0, channel: "whatsapp", sentiment: "negative", online: true, avatar: "OC" },
  { id: "c6", name: "Nadia Bennani", phone: "+212 6 33 22 11 00", last: "Comment réinitialiser mon mot de passe ?", time: "09:18", unread: 0, channel: "web", sentiment: "neutral", online: false, avatar: "NB" },
  { id: "c7", name: "Mehdi Alaoui", phone: "+212 6 99 88 77 66", last: "Quels sont vos tarifs entreprise ?", time: "Hier", unread: 0, channel: "whatsapp", sentiment: "neutral", online: false, avatar: "MA" },
  { id: "c8", name: "Imane Fassi", phone: "+212 6 11 22 33 44", last: "Ma livraison est en retard de 5 jours", time: "Hier", unread: 0, channel: "whatsapp", sentiment: "negative", online: false, avatar: "IF" },
];

export const chatMessages = [
  { id: 1, from: "customer", text: "Bonjour, je n'ai toujours pas reçu ma facture corrigée pour la commande #8821", time: "10:30" },
  { id: 2, from: "ai", text: "Bonjour Fatima 👋 Je suis l'assistant IA de Nexora. Je consulte votre dossier...", time: "10:30" },
  { id: 3, from: "ai", text: "J'ai trouvé votre commande #8821. La facture corrigée a été générée le 14/05 mais n'a pas été envoyée à cause d'un problème système. Je la renvoie immédiatement à votre email fatima.b@email.com — pouvez-vous confirmer ?", time: "10:31" },
  { id: 4, from: "customer", text: "Oui c'est bien mon email, merci", time: "10:35" },
  { id: 5, from: "ai", text: "Parfait ✅ Facture envoyée. Vous devriez la recevoir dans les 2 minutes. Y a-t-il autre chose ?", time: "10:35" },
  { id: 6, from: "customer", text: "Je ne reçois rien dans ma boîte mail...", time: "10:38" },
];

export const knowledgeArticles = [
  { id: 1, title: "Politique de retours et remboursements", category: "Commercial", views: 2840, updated: "il y a 2 jours" },
  { id: 2, title: "Comment réinitialiser mon mot de passe", category: "Technique", views: 1920, updated: "il y a 5 jours" },
  { id: 3, title: "Tarification entreprise et plans", category: "Commercial", views: 1654, updated: "il y a 1 semaine" },
  { id: 4, title: "Suivi de commande et livraison", category: "Logistique", views: 3210, updated: "il y a 3 jours" },
  { id: 5, title: "Configuration WhatsApp Business API", category: "Technique", views: 980, updated: "il y a 2 semaines" },
  { id: 6, title: "Annulation et modification d'abonnement", category: "Commercial", views: 1430, updated: "il y a 4 jours" },
];

export const aiInsights = [
  { title: "Pic de demandes prédites demain", desc: "L'IA prévoit +34% de tickets entre 14h-17h. Pensez à augmenter les agents disponibles.", severity: "warning" },
  { title: "Top intent émergent : 'Livraison retardée'", desc: "+82% sur 7 jours. Recommandation : créer une réponse automatisée dédiée.", severity: "info" },
  { title: "Sentiment client en amélioration", desc: "Score moyen +12 pts cette semaine grâce aux réponses plus rapides.", severity: "success" },
  { title: "Article RAG manquant", desc: "47 questions sans réponse sur 'Programme fidélité'. Créer un article ?", severity: "info" },
];
