// =============================================================================
// Nexora AI — API Client (Integration Stubs)
// -----------------------------------------------------------------------------
// This file is the SINGLE source of truth for every call the frontend will
// eventually make to the backend. Today every method returns mock data after a
// simulated network delay. Tomorrow, swap the body of each method with a real
// `fetch()` call to your backend (FastAPI / Node / Supabase Edge Functions) —
// the rest of the app will keep working without changes.
//
// Conventions:
//   - All methods return `Promise<T>` (never throw mock data synchronously).
//   - All methods accept a typed input and return a typed output.
//   - Endpoints are listed in comments above each method so the backend team
//     knows exactly what to implement (REST contract).
//   - Auth: every authenticated call expects `Authorization: Bearer <jwt>`.
// =============================================================================

import {
  kpis,
  activityFeed,
  recentTickets,
  ticketVolumeData,
  costSavingsData,
} from "./mock-data";

// ---------- Config ----------------------------------------------------------

export const API_BASE_URL =
  (typeof import.meta !== "undefined" && (import.meta as any).env?.VITE_API_BASE_URL) ||
  "https://api.nexora-ai.ma/v1";

const USE_MOCK = false; // flip to `true` to use mock data without a backend

// ---------- Internal helpers ------------------------------------------------

const delay = (ms = 400) => new Promise((r) => setTimeout(r, ms));

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const token =
    typeof localStorage !== "undefined" ? localStorage.getItem("nexora_token") : null;

  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init?.headers || {}),
    },
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`[API ${res.status}] ${path} — ${body}`);
  }
  return res.json() as Promise<T>;
}

// ---------- Types -----------------------------------------------------------

export type Channel = "whatsapp" | "web" | "voice" | "facebook" | "instagram";
export type TicketStatus = "open" | "progress" | "resolved" | "escalated";
export type Priority = "low" | "medium" | "high";
export type Sentiment = "positive" | "neutral" | "negative";

export type PresenceStatus = "online" | "offline";

export interface AuthSession {
  token: string;
  user: { id: string; name: string; email: string; role: "admin" | "agent"; status: PresenceStatus };
}

export interface AgentProfile {
  id: string;
  name: string;
  email: string;
  role: "admin" | "agent";
  status: PresenceStatus;
  resolvedCount: number;
  openCount: number;
  escalatedCount: number;
}

export interface KPIs {
  conversations: number;
  autoResolvedRate: number;
  activeTickets: number;
  avgResponseTime: number;
  costSaved: number;
  conversationsDelta: number;
  resolvedDelta: number;
  ticketsDelta: number;
  responseDelta: number;
  costDelta: number;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: "user" | "ai" | "agent";
  content: string;
  createdAt: string;
  sentiment?: Sentiment;
}

export interface Conversation {
  id: string;
  customer: string;
  channel: Channel;
  lastMessage: string;
  unread: number;
  takeover: "ai" | "human";
  sentiment: Sentiment;
}

export interface Ticket {
  id: string;
  customer: string;
  intent: string;
  priority: Priority;
  status: TicketStatus;
  agent: string;
  agentId?: string | null;
  channel: string;
  conversationId?: string | null;
}

export interface KnowledgeDoc {
  id: string;
  title: string;
  source: "pdf" | "url" | "manual";
  chunks: number;
  updatedAt: string;
}

// =============================================================================
//  AUTH  —  POST /auth/login | POST /auth/logout | GET /auth/me
// =============================================================================
export const auth = {
  async login(email: string, password: string): Promise<AuthSession> {
    if (!USE_MOCK) {
      const session = await request<AuthSession>("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
      if (typeof localStorage !== "undefined") localStorage.setItem("nexora_token", session.token);
      return session;
    }
    await delay();
    const session: AuthSession = {
      token: "mock_jwt_token_" + Date.now(),
      user: { id: "u_001", name: "Yassine Sinif", email, role: "admin", status: "offline" },
    };
    if (typeof localStorage !== "undefined") localStorage.setItem("nexora_token", session.token);
    return session;
  },

  async logout(): Promise<void> {
    if (!USE_MOCK) await request("/auth/logout", { method: "POST" });
    if (typeof localStorage !== "undefined") localStorage.removeItem("nexora_token");
  },

  async me(): Promise<AuthSession["user"]> {
    if (!USE_MOCK) return request("/auth/me");
    await delay(150);
    return { id: "u_001", name: "Yassine Sinif", email: "yassine@nexora.ma", role: "admin", status: "offline" };
  },
};

// =============================================================================
//  AGENTS  —  GET /agents/me | PATCH /agents/me/status | GET /agents/me/tickets | GET /agents
// =============================================================================
export const agents = {
  async me(): Promise<AgentProfile> {
    if (!USE_MOCK) return request("/agents/me");
    await delay(150);
    return { id: "u_001", name: "Yassine Sinif", email: "yassine@nexora.ma", role: "admin", status: "offline", resolvedCount: 0, openCount: 0, escalatedCount: 0 };
  },

  async updateStatus(status: PresenceStatus): Promise<AuthSession["user"]> {
    if (!USE_MOCK) return request("/agents/me/status", { method: "PATCH", body: JSON.stringify({ status }) });
    await delay(150);
    return { id: "u_001", name: "Yassine Sinif", email: "yassine@nexora.ma", role: "admin", status };
  },

  async myTickets(status?: TicketStatus): Promise<Ticket[]> {
    if (!USE_MOCK) {
      const qs = status ? `?status=${status}` : "";
      return request(`/agents/me/tickets${qs}`);
    }
    await delay(200);
    return recentTickets as Ticket[];
  },

  async list(): Promise<AgentProfile[]> {
    if (!USE_MOCK) return request("/agents");
    await delay(200);
    return [];
  },
};

// =============================================================================
//  DASHBOARD  —  GET /dashboard/kpis | GET /dashboard/activity
// =============================================================================
export const dashboard = {
  async getKPIs(): Promise<KPIs> {
    if (!USE_MOCK) return request("/dashboard/kpis");
    await delay(200);
    return kpis;
  },

  async getActivityFeed(limit = 20): Promise<typeof activityFeed> {
    if (!USE_MOCK) return request(`/dashboard/activity?limit=${limit}`);
    await delay(200);
    return activityFeed.slice(0, limit);
  },
};

// =============================================================================
//  CONVERSATIONS  —  /conversations
//   GET    /conversations                  → list
//   GET    /conversations/:id/messages     → messages
//   POST   /conversations/:id/messages     → send (AI or human)
//   POST   /conversations/:id/takeover     → switch AI ↔ human
//   POST   /conversations/:id/summarize    → AI-generated summary
// =============================================================================
export const conversations = {
  async list(): Promise<Conversation[]> {
    if (!USE_MOCK) return request("/conversations");
    await delay(250);
    return [
      { id: "c1", customer: "Karim El Idrissi", channel: "whatsapp", lastMessage: "Merci pour votre aide !", unread: 0, takeover: "ai", sentiment: "positive" },
      { id: "c2", customer: "Fatima Benali", channel: "web", lastMessage: "Je n'ai toujours pas reçu ma commande...", unread: 2, takeover: "human", sentiment: "negative" },
      { id: "c3", customer: "Yassir Lamrini", channel: "whatsapp", lastMessage: "Quels sont vos horaires ?", unread: 1, takeover: "ai", sentiment: "neutral" },
    ];
  },

  async getMessages(conversationId: string): Promise<ChatMessage[]> {
    if (!USE_MOCK) return request(`/conversations/${conversationId}/messages`);
    await delay(200);
    return [
      { id: "m1", conversationId, role: "user", content: "Bonjour, où en est ma commande ?", createdAt: new Date().toISOString(), sentiment: "neutral" },
      { id: "m2", conversationId, role: "ai", content: "Bonjour Karim 👋 Votre commande #4821 est en cours de livraison, arrivée prévue demain.", createdAt: new Date().toISOString() },
    ];
  },

  async sendMessage(conversationId: string, content: string, as: "ai" | "agent" = "agent"): Promise<ChatMessage> {
    if (!USE_MOCK) return request(`/conversations/${conversationId}/messages`, { method: "POST", body: JSON.stringify({ content, as }) });
    await delay(600);
    return { id: "m_" + Date.now(), conversationId, role: as, content, createdAt: new Date().toISOString() };
  },

  async takeover(conversationId: string, mode: "ai" | "human"): Promise<{ ok: true }> {
    if (!USE_MOCK) return request(`/conversations/${conversationId}/takeover`, { method: "POST", body: JSON.stringify({ mode }) });
    await delay(150);
    return { ok: true };
  },

  async summarize(conversationId: string): Promise<{ summary: string; intents: string[]; sentiment: Sentiment }> {
    if (!USE_MOCK) return request(`/conversations/${conversationId}/summarize`, { method: "POST" });
    await delay(800);
    return {
      summary: "Le client demande le statut de sa commande. L'IA a fourni le numéro de suivi et la date de livraison estimée.",
      intents: ["order_tracking", "delivery_eta"],
      sentiment: "positive",
    };
  },
};

// =============================================================================
//  TICKETS  —  /tickets
// =============================================================================
export const tickets = {
  async list(filter?: { status?: TicketStatus; priority?: Priority }): Promise<Ticket[]> {
    if (!USE_MOCK) {
      const qs = new URLSearchParams(filter as any).toString();
      return request(`/tickets?${qs}`);
    }
    await delay(200);
    return recentTickets as Ticket[];
  },

  async update(id: string, patch: Partial<Ticket>): Promise<Ticket> {
    if (!USE_MOCK) return request(`/tickets/${id}`, { method: "PATCH", body: JSON.stringify(patch) });
    await delay(200);
    return { ...(recentTickets.find((t) => t.id === id) as Ticket), ...patch };
  },

  async assign(id: string, agentId: string): Promise<{ ok: true }> {
    if (!USE_MOCK) return request(`/tickets/${id}/assign`, { method: "POST", body: JSON.stringify({ agentId }) });
    await delay(150);
    return { ok: true };
  },
};

// =============================================================================
//  ANALYTICS  —  /analytics
// =============================================================================
export const analytics = {
  async ticketVolume(range: "7d" | "30d" | "90d" = "7d"): Promise<{ day: string; total: number; ai: number; human: number }[]> {
    if (!USE_MOCK) return request(`/analytics/ticket-volume?range=${range}`);
    await delay(200);
    return ticketVolumeData;
  },

  async costSavings(range: "6m" | "12m" = "6m"): Promise<{ month: string; saved: number }[]> {
    if (!USE_MOCK) return request(`/analytics/cost-savings?range=${range}`);
    await delay(200);
    return costSavingsData;
  },
};

// =============================================================================
//  KNOWLEDGE BASE (RAG)  —  /knowledge
//   GET    /knowledge/documents
//   POST   /knowledge/documents          (multipart upload)
//   DELETE /knowledge/documents/:id
//   POST   /knowledge/reindex
//   POST   /knowledge/query              { query: string } → top-k chunks
// =============================================================================
export const knowledge = {
  async listDocuments(): Promise<KnowledgeDoc[]> {
    if (!USE_MOCK) return request("/knowledge/documents");
    await delay(250);
    return [
      { id: "d1", title: "Politique de retour 2026.pdf", source: "pdf", chunks: 42, updatedAt: "2026-06-01" },
      { id: "d2", title: "FAQ Livraison Maroc", source: "manual", chunks: 18, updatedAt: "2026-06-10" },
      { id: "d3", title: "https://nexora.ma/tarifs", source: "url", chunks: 7, updatedAt: "2026-06-12" },
    ];
  },

  async uploadDocument(file: File): Promise<KnowledgeDoc> {
    if (!USE_MOCK) {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch(`${API_BASE_URL}/knowledge/documents`, { method: "POST", body: form });
      return res.json();
    }
    await delay(1200);
    return { id: "d_" + Date.now(), title: file.name, source: "pdf", chunks: 0, updatedAt: new Date().toISOString() };
  },

  async deleteDocument(id: string): Promise<{ ok: true }> {
    if (!USE_MOCK) return request(`/knowledge/documents/${id}`, { method: "DELETE" });
    await delay(200);
    return { ok: true };
  },

  async query(query: string): Promise<{ chunks: { text: string; score: number; source: string }[] }> {
    if (!USE_MOCK) return request("/knowledge/query", { method: "POST", body: JSON.stringify({ query }) });
    await delay(500);
    return {
      chunks: [
        { text: "Les retours sont acceptés sous 14 jours...", score: 0.92, source: "Politique de retour 2026.pdf" },
        { text: "Livraison gratuite dès 300 MAD au Maroc.", score: 0.81, source: "FAQ Livraison Maroc" },
      ],
    };
  },
};

// =============================================================================
//  SETTINGS  —  /settings
// =============================================================================
export interface CompanySettings {
  name: string;
  sector: string;
  country: string;
  timezone: string;
}

export interface AISettings {
  model: string;
  temperature: number;
  systemPrompt: string;
}

export interface IntegrationSummary {
  id: string;
  name: string;
  connected: boolean;
}

export const settings = {
  async getCompany(): Promise<CompanySettings> {
    if (!USE_MOCK) return request("/settings/company");
    await delay(150);
    return { name: "Nexora AI Demo", sector: "E-commerce", country: "Maroc", timezone: "Africa/Casablanca" };
  },
  async updateCompany(patch: Partial<CompanySettings>): Promise<CompanySettings> {
    if (!USE_MOCK) return request("/settings/company", { method: "PATCH", body: JSON.stringify(patch) });
    await delay(300);
    return { name: "Nexora AI Demo", sector: "E-commerce", country: "Maroc", timezone: "Africa/Casablanca", ...patch };
  },

  async getAIConfig(): Promise<AISettings> {
    if (!USE_MOCK) return request("/settings/ai");
    await delay(150);
    return { model: "gpt-4", temperature: 0.3, systemPrompt: "Tu es l'assistant IA de Nexora..." };
  },
  async updateAIConfig(patch: Partial<AISettings>): Promise<AISettings> {
    if (!USE_MOCK) return request("/settings/ai", { method: "PATCH", body: JSON.stringify(patch) });
    await delay(300);
    return { model: "gpt-4", temperature: 0.3, systemPrompt: "Tu es l'assistant IA de Nexora...", ...patch };
  },

  async listIntegrations(): Promise<IntegrationSummary[]> {
    if (!USE_MOCK) return request("/settings/integrations");
    await delay(200);
    return [
      { id: "whatsapp", name: "WhatsApp Business API", connected: true },
      { id: "hubspot", name: "HubSpot CRM", connected: true },
      { id: "salesforce", name: "Salesforce", connected: false },
    ];
  },
  async connectIntegration(id: string, credentials: Record<string, any>): Promise<{ ok: boolean }> {
    if (!USE_MOCK) return request(`/settings/integrations/${id}/connect`, { method: "POST", body: JSON.stringify(credentials) });
    await delay(800);
    return { ok: true };
  },
};

// =============================================================================
//  WEBHOOKS (incoming — backend implements; documented here for completeness)
// -----------------------------------------------------------------------------
//   POST /webhooks/whatsapp     ← Meta WhatsApp Business API
//   POST /webhooks/voice        ← Twilio / Genesys voice events
//   POST /webhooks/crm/:vendor  ← HubSpot / Salesforce sync
// =============================================================================

// ---------- Export aggregate ------------------------------------------------
export const api = { auth, agents, dashboard, conversations, tickets, analytics, knowledge, settings };
export default api;
