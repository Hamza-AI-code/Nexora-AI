import { Outlet, createFileRoute, redirect } from "@tanstack/react-router";
import { DashboardSidebar } from "@/components/dashboard/sidebar";

export const Route = createFileRoute("/dashboard")({
  beforeLoad: () => {
    if (typeof localStorage !== "undefined" && !localStorage.getItem("nexora_token")) {
      throw redirect({ to: "/login" });
    }
  },
  component: DashboardLayout,
});

function DashboardLayout() {
  return (
    <div className="min-h-screen flex bg-background text-foreground">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Outlet />
      </div>
    </div>
  );
}
