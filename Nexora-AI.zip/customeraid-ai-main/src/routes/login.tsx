import { createFileRoute, useNavigate, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { Bot, Loader2 } from "lucide-react";
import { api } from "@/lib/api";

export const Route = createFileRoute("/login")({
  beforeLoad: () => {
    if (typeof localStorage !== "undefined" && localStorage.getItem("nexora_token")) {
      throw redirect({ to: "/dashboard" });
    }
  },
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@nexora.ma");
  const [password, setPassword] = useState("admin123");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await api.auth.login(email, password);
      navigate({ to: "/dashboard" });
    } catch (err) {
      setError("Email ou mot de passe incorrect.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 hero-bg">
      <div className="w-full max-w-sm glass rounded-2xl p-8">
        <div className="flex flex-col items-center mb-6">
          <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center shadow-glow mb-3">
            <Bot className="w-6 h-6 text-primary-foreground" />
          </div>
          <h1 className="text-xl font-semibold">Connexion à Nexora AI</h1>
          <p className="text-xs text-muted-foreground mt-1">Accédez à votre espace d'administration</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-medium" htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-10 px-3.5 rounded-lg bg-secondary border border-border text-sm outline-none focus:border-primary transition-colors"
              placeholder="admin@nexora.ma"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium" htmlFor="password">Mot de passe</label>
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full h-10 px-3.5 rounded-lg bg-secondary border border-border text-sm outline-none focus:border-primary transition-colors"
              placeholder="••••••••"
            />
          </div>

          {error && <p className="text-xs text-destructive">{error}</p>}

          <p className="text-[11px] text-muted-foreground">
            Compte de démo : <span className="font-mono">admin@nexora.ma</span> / <span className="font-mono">admin123</span>
          </p>

          <button
            type="submit"
            disabled={loading}
            className="w-full h-10 rounded-lg gradient-primary text-primary-foreground text-sm font-medium shadow-glow flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform disabled:opacity-60"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            Se connecter
          </button>
        </form>
      </div>
    </div>
  );
}
