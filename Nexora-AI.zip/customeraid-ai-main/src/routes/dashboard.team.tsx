import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard/header";
import { ShieldAlert, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { api } from "@/lib/api";

export const Route = createFileRoute("/dashboard/team")({
  component: TeamPage,
});

function TeamPage() {
  const { data: me } = useQuery({
    queryKey: ["auth", "me"],
    queryFn: () => api.auth.me(),
  });

  const { data: agentsData } = useQuery({
    queryKey: ["agents", "list"],
    queryFn: () => api.agents.list(),
    enabled: me?.role === "admin",
  });

  if (me && me.role !== "admin") {
    return (
      <>
        <DashboardHeader title="Équipe" subtitle="Suivi des agents" />
        <main className="flex-1 p-6">
          <div className="glass rounded-2xl p-10 flex flex-col items-center text-center gap-2">
            <ShieldAlert className="w-8 h-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Cette page est réservée aux administrateurs.</p>
          </div>
        </main>
      </>
    );
  }

  const team = agentsData ?? [];

  return (
    <>
      <DashboardHeader title="Équipe" subtitle="Disponibilité et performance des agents" />
      <main className="flex-1 p-6 space-y-5 overflow-x-hidden">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="glass rounded-2xl p-4">
            <div className="text-xl font-bold">{team.length}</div>
            <div className="text-xs text-muted-foreground">Agents au total</div>
          </div>
          <div className="glass rounded-2xl p-4">
            <div className="text-xl font-bold">{team.filter((a) => a.status === "online").length}</div>
            <div className="text-xs text-muted-foreground">En ligne maintenant</div>
          </div>
          <div className="glass rounded-2xl p-4">
            <div className="text-xl font-bold">{team.reduce((sum, a) => sum + a.openCount, 0)}</div>
            <div className="text-xs text-muted-foreground">Tickets en cours (équipe)</div>
          </div>
        </div>

        <div className="glass rounded-2xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground border-b border-border bg-surface/50">
                <th className="font-medium px-5 py-3.5">Agent</th>
                <th className="font-medium px-5 py-3.5">Statut</th>
                <th className="font-medium px-5 py-3.5">Résolus</th>
                <th className="font-medium px-5 py-3.5">En cours</th>
                <th className="font-medium px-5 py-3.5">Escaladés</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {team.map((agent) => (
                <tr key={agent.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-primary/15 text-primary text-[10px] font-semibold flex items-center justify-center">
                        {agent.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium">{agent.name}</div>
                        <div className="text-[11px] text-muted-foreground">{agent.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <span className="inline-flex items-center gap-1.5 text-xs">
                      <span className={cn("w-2 h-2 rounded-full", agent.status === "online" ? "bg-success" : "bg-muted-foreground/40")} />
                      {agent.status === "online" ? "En ligne" : "Hors ligne"}
                    </span>
                  </td>
                  <td className="px-5 py-4 font-medium">{agent.resolvedCount}</td>
                  <td className="px-5 py-4 text-muted-foreground">{agent.openCount}</td>
                  <td className="px-5 py-4 text-muted-foreground">{agent.escalatedCount}</td>
                </tr>
              ))}
              {team.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-10 text-center text-sm text-muted-foreground">
                    <Users className="w-6 h-6 mx-auto mb-2 opacity-50" />
                    Aucun agent pour le moment.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </main>
    </>
  );
}
