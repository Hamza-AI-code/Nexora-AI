import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard/header";
import {
  MessagesSquare, CheckCircle2, Ticket, Clock, DollarSign,
  TrendingUp, TrendingDown, Sparkles, ArrowUpRight, Bot, UserCircle2, BookOpen,
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import { api } from "@/lib/api";
import { motion } from "framer-motion";

export const Route = createFileRoute("/dashboard/")({
  component: DashboardIndex,
});

function DashboardIndex() {
  const { data: kpis } = useQuery({ queryKey: ["dashboard", "kpis"], queryFn: () => api.dashboard.getKPIs() });
  const { data: activityFeed } = useQuery({ queryKey: ["dashboard", "activity"], queryFn: () => api.dashboard.getActivityFeed() });
  const { data: recentTickets } = useQuery({ queryKey: ["tickets", "recent"], queryFn: () => api.tickets.list() });
  const { data: ticketVolumeData } = useQuery({ queryKey: ["analytics", "ticket-volume"], queryFn: () => api.analytics.ticketVolume() });

  return (
    <>
      <DashboardHeader title="Vue d'ensemble" subtitle="Activité temps réel" />
      <main className="flex-1 p-6 space-y-6 overflow-x-hidden">
        {/* KPIs */}
        {kpis && (
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
            <KpiCard icon={MessagesSquare} label="Conversations" value={kpis.conversations.toLocaleString("fr")} delta={kpis.conversationsDelta} />
            <KpiCard icon={CheckCircle2} label="Auto-résolu" value={`${kpis.autoResolvedRate}%`} delta={kpis.resolvedDelta} highlight />
            <KpiCard icon={Ticket} label="Tickets actifs" value={kpis.activeTickets.toString()} delta={kpis.ticketsDelta} invert />
            <KpiCard icon={Clock} label="Temps réponse" value={`${kpis.avgResponseTime}s`} delta={kpis.responseDelta} invert />
            <KpiCard icon={DollarSign} label="Économisé (MAD)" value={`${(kpis.costSaved/1000).toFixed(0)}k`} delta={kpis.costDelta} />
          </div>
        )}

        {/* Chart + Activity feed */}
        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 glass rounded-2xl p-6">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="font-semibold">Volume de conversations</h2>
                <p className="text-xs text-muted-foreground">7 derniers jours · IA vs Humain</p>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-primary" /> IA</span>
                <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-muted-foreground" /> Humain</span>
              </div>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={ticketVolumeData ?? []}>
                  <defs>
                    <linearGradient id="ai" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.62 0.21 263)" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="oklch(0.62 0.21 263)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="hum" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.68 0.02 260)" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="oklch(0.68 0.02 260)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.06)" />
                  <XAxis dataKey="day" stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                  <YAxis stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "oklch(0.22 0.025 265)", border: "1px solid oklch(1 0 0 / 0.08)", borderRadius: 12, fontSize: 12 }} />
                  <Area type="monotone" dataKey="human" stroke="oklch(0.68 0.02 260)" strokeWidth={2} fill="url(#hum)" />
                  <Area type="monotone" dataKey="ai" stroke="oklch(0.62 0.21 263)" strokeWidth={2.5} fill="url(#ai)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass rounded-2xl p-6 flex flex-col">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="font-semibold flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inset-0 rounded-full bg-success animate-ping" />
                    <span className="relative rounded-full h-2 w-2 bg-success" />
                  </span>
                  Flux IA en direct
                </h2>
                <p className="text-xs text-muted-foreground">Mise à jour temps réel</p>
              </div>
            </div>
            <div className="space-y-3 flex-1 overflow-y-auto -mr-2 pr-2 max-h-[280px]">
              {(activityFeed ?? []).map((a, i) => (
                <motion.div
                  key={a.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex gap-3 items-start text-sm"
                >
                  <ActivityIcon type={a.type} />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs leading-relaxed">{a.text}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5 flex items-center gap-2">
                      <span>{a.time}</span>
                      <span className="w-0.5 h-0.5 rounded-full bg-muted-foreground" />
                      <span>{a.channel}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent tickets */}
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="font-semibold">Tickets récents</h2>
              <p className="text-xs text-muted-foreground">Mise à jour il y a quelques secondes</p>
            </div>
            <Link to="/dashboard/tickets" className="text-xs text-primary font-medium flex items-center gap-1 hover:underline">
              Voir tous <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground border-b border-border">
                  <th className="font-medium pb-3 pr-4">ID</th>
                  <th className="font-medium pb-3 pr-4">Client</th>
                  <th className="font-medium pb-3 pr-4">Intent</th>
                  <th className="font-medium pb-3 pr-4">Priorité</th>
                  <th className="font-medium pb-3 pr-4">Statut</th>
                  <th className="font-medium pb-3">Agent</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {(recentTickets ?? []).slice(0, 6).map((t) => (
                  <tr key={t.id} className="hover:bg-secondary/30 transition-colors">
                    <td className="py-3.5 pr-4 font-mono text-xs text-muted-foreground">{t.id}</td>
                    <td className="py-3.5 pr-4 font-medium">{t.customer}</td>
                    <td className="py-3.5 pr-4 text-muted-foreground">{t.intent}</td>
                    <td className="py-3.5 pr-4"><PriorityBadge p={t.priority} /></td>
                    <td className="py-3.5 pr-4"><StatusBadge s={t.status} /></td>
                    <td className="py-3.5 text-muted-foreground text-xs">{t.agent}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </>
  );
}

function KpiCard({ icon: Icon, label, value, delta, invert, highlight }: any) {
  const positive = invert ? delta < 0 : delta > 0;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`relative rounded-2xl p-5 overflow-hidden ${highlight ? "" : "glass"}`}
    >
      {highlight && (
        <>
          <div className="absolute inset-0 gradient-primary opacity-20" />
          <div className="absolute inset-0 glass" />
        </>
      )}
      <div className="relative">
        <div className="flex items-start justify-between mb-3">
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${highlight ? "gradient-primary shadow-glow" : "bg-primary/10"}`}>
            <Icon className={`w-4.5 h-4.5 ${highlight ? "text-primary-foreground" : "text-primary"}`} />
          </div>
          <span className={`text-[11px] font-semibold flex items-center gap-0.5 ${positive ? "text-success" : "text-destructive"}`}>
            {positive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(delta)}%
          </span>
        </div>
        <div className="text-2xl font-bold tracking-tight">{value}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
      </div>
    </motion.div>
  );
}

function ActivityIcon({ type }: { type: string }) {
  const map: any = {
    intent: { icon: Sparkles, color: "text-primary bg-primary/10" },
    resolved: { icon: CheckCircle2, color: "text-success bg-success/10" },
    escalation: { icon: UserCircle2, color: "text-warning bg-warning/10" },
    knowledge: { icon: BookOpen, color: "text-muted-foreground bg-secondary" },
  };
  const { icon: I, color } = map[type] || map.intent;
  return <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${color}`}><I className="w-3.5 h-3.5" /></div>;
}

export function PriorityBadge({ p }: { p: string }) {
  const map: any = {
    low: "bg-muted-foreground/15 text-muted-foreground",
    medium: "bg-warning/15 text-warning",
    high: "bg-destructive/15 text-destructive",
  };
  const labels: any = { low: "Basse", medium: "Moyenne", high: "Haute" };
  return <span className={`text-[10px] font-semibold px-2 py-1 rounded-md ${map[p]}`}>{labels[p]}</span>;
}

export function StatusBadge({ s }: { s: string }) {
  const map: any = {
    open: "bg-primary/15 text-primary",
    progress: "bg-warning/15 text-warning",
    resolved: "bg-success/15 text-success",
  };
  const labels: any = { open: "Ouvert", progress: "En cours", resolved: "Résolu" };
  return <span className={`text-[10px] font-semibold px-2 py-1 rounded-md ${map[s]}`}>{labels[s]}</span>;
}
