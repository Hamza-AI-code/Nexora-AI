import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Bot, MessageSquare, Ticket, Brain, FileText, BookOpen, LayoutDashboard,
  ArrowRight, Check, Sparkles, Zap, Globe, Shield, TrendingDown, Clock,
  CircleDot, Mail, ArrowUpRight,
} from "lucide-react";
import { motion } from "framer-motion";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nexora AI — Automatisation Intelligente des Centres d'Appels" },
      { name: "description", content: "Plateforme IA pour centres d'appels au Maroc & MENA. Chatbot 24/7 WhatsApp, ticketing intelligent, RAG, analytics. Réduisez vos coûts de 35%." },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: Bot, title: "Chatbot IA WhatsApp & Web", desc: "Conversationnel 24/7 en Arabe, Français, Anglais et Darija. Réponses instantanées contextualisées." },
  { icon: Ticket, title: "Ticketing Intelligent", desc: "Création, priorisation et routage automatiques. Escalade vers agents humains au bon moment." },
  { icon: Brain, title: "NLP & Détection d'Intention", desc: "Comprend ce que veulent vos clients — réclamations, support, ventes — dès le premier message." },
  { icon: FileText, title: "Résumés Automatiques", desc: "Chaque conversation est résumée instantanément pour vos agents. Plus de relecture interminable." },
  { icon: BookOpen, title: "Base RAG Auto-Alimentée", desc: "Connecte vos documents, FAQ, CRM. L'IA puise dans votre connaissance pour répondre juste." },
  { icon: LayoutDashboard, title: "Dashboard Agents", desc: "Supervision temps réel, sentiment client, KPIs, escalade en un clic. Pensé pour la productivité." },
];

const metrics = [
  { icon: TrendingDown, value: "-80%", label: "tickets répétitifs" },
  { icon: TrendingDown, value: "-35%", label: "coût opérationnel" },
  { icon: Clock, value: "24/7", label: "disponibilité" },
  { icon: Zap, value: "<2s", label: "temps de réponse" },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-background/70 border-b border-border">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl gradient-primary flex items-center justify-center shadow-glow">
              <Bot className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <div className="font-bold text-sm leading-tight">Nexora AI</div>
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Call Center OS</div>
            </div>
          </Link>
          <div className="hidden md:flex items-center gap-8 text-sm">
            <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">Fonctionnalités</a>
            <a href="#solution" className="text-muted-foreground hover:text-foreground transition-colors">Solution</a>
            <a href="#marche" className="text-muted-foreground hover:text-foreground transition-colors">Marché MENA</a>
            <a href="#contact" className="text-muted-foreground hover:text-foreground transition-colors">Contact</a>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/dashboard" className="hidden sm:inline-flex text-sm text-muted-foreground hover:text-foreground transition-colors">
              Se connecter
            </Link>
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-1.5 gradient-primary text-primary-foreground text-sm font-medium px-4 py-2 rounded-lg shadow-glow hover:scale-[1.02] transition-transform"
            >
              Voir la démo <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden hero-bg">
        <div className="absolute inset-0 grid-pattern opacity-40 [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_70%)]" />
        <div className="relative max-w-7xl mx-auto px-6 pt-20 pb-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs font-medium mb-7"
          >
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inset-0 rounded-full bg-success animate-ping" />
              <span className="relative rounded-full h-1.5 w-1.5 bg-success" />
            </span>
            En production · WhatsApp Business · GPT-4 & Llama 3
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl md:text-7xl font-bold tracking-tight max-w-4xl mx-auto leading-[1.05]"
          >
            <span className="text-gradient">Automatisation intelligente</span><br />
            des centres d'appels avec l'IA
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed"
          >
            Réduisez les coûts, améliorez les temps de réponse,
            <br className="hidden sm:block" />
            automatisez <span className="text-foreground font-semibold">80% des demandes</span> client.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-8 flex flex-col sm:flex-row gap-3 items-center justify-center"
          >
            <a href="#contact" className="inline-flex items-center gap-2 gradient-primary text-primary-foreground px-6 py-3 rounded-xl font-medium shadow-glow hover:scale-[1.02] transition-transform">
              Demander une démo <ArrowRight className="w-4 h-4" />
            </a>
            <Link to="/dashboard" className="inline-flex items-center gap-2 glass-strong px-6 py-3 rounded-xl font-medium hover:bg-secondary transition-colors">
              Voir la plateforme <ArrowUpRight className="w-4 h-4" />
            </Link>
          </motion.div>

          {/* Chatbot preview */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative mt-20 max-w-4xl mx-auto"
          >
            <div className="absolute -inset-4 gradient-primary opacity-20 blur-3xl rounded-full" />
            <div className="relative glass-strong rounded-2xl p-2 shadow-elegant">
              <div className="rounded-xl bg-surface overflow-hidden">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-destructive/60" />
                    <div className="w-2.5 h-2.5 rounded-full bg-warning/60" />
                    <div className="w-2.5 h-2.5 rounded-full bg-success/60" />
                  </div>
                  <div className="flex-1 text-center text-xs text-muted-foreground">nexora.ai / dashboard</div>
                </div>
                <ChatPreview />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Metrics bar */}
      <section className="border-y border-border bg-surface/50">
        <div className="max-w-7xl mx-auto px-6 py-10 grid grid-cols-2 md:grid-cols-4 gap-6">
          {metrics.map((m) => (
            <div key={m.label} className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <m.icon className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold tracking-tight">{m.value}</div>
                <div className="text-xs text-muted-foreground">{m.label}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Problem / Solution */}
      <section id="solution" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="inline-block text-xs font-semibold text-primary uppercase tracking-wider mb-3">Le problème</div>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Les centres d'appels traditionnels sont à bout</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="glass rounded-2xl p-8">
              <div className="text-xs font-semibold text-destructive uppercase tracking-wider mb-4">Avant</div>
              <h3 className="text-xl font-semibold mb-6">Centre d'appel traditionnel</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {[
                  "60% des appels sont des questions répétitives",
                  "Temps d'attente moyen : 8 à 15 minutes",
                  "Turnover agents > 40% par an",
                  "Coûts opérationnels élevés en MAD",
                  "Pas de support 24/7",
                  "Manque d'analytics actionnables",
                ].map((t) => (
                  <li key={t} className="flex gap-2.5">
                    <CircleDot className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="relative rounded-2xl p-8 overflow-hidden">
              <div className="absolute inset-0 gradient-primary opacity-15" />
              <div className="absolute inset-0 glass" />
              <div className="relative">
                <div className="text-xs font-semibold text-primary uppercase tracking-wider mb-4">Avec Nexora AI</div>
                <h3 className="text-xl font-semibold mb-6">Centre d'appel augmenté par l'IA</h3>
                <ul className="space-y-3 text-sm">
                  {[
                    "80% des demandes auto-résolues par l'IA",
                    "Réponse instantanée (< 2 secondes)",
                    "Agents concentrés sur les cas à valeur",
                    "-35% de coûts opérationnels",
                    "Disponibilité 24/7 sur tous canaux",
                    "Insights IA en temps réel",
                  ].map((t) => (
                    <li key={t} className="flex gap-2.5">
                      <Check className="w-4 h-4 text-success shrink-0 mt-0.5" />
                      <span>{t}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 border-t border-border">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="inline-block text-xs font-semibold text-primary uppercase tracking-wider mb-3">Plateforme complète</div>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Tout ce qu'il faut pour automatiser votre service client</h2>
            <p className="mt-4 text-muted-foreground">Une suite intégrée, pensée pour les opérations à grande échelle au Maroc et en MENA.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                className="group glass rounded-2xl p-6 hover:border-primary/40 transition-all hover:-translate-y-1"
              >
                <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:gradient-primary group-hover:shadow-glow transition-all">
                  <f.icon className="w-5 h-5 text-primary group-hover:text-primary-foreground transition-colors" />
                </div>
                <h3 className="font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Market */}
      <section id="marche" className="py-24 border-t border-border">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-block text-xs font-semibold text-primary uppercase tracking-wider mb-3">Marché Maroc & MENA</div>
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Un marché de 80 000 agents qui se transforme</h2>
            <p className="mt-5 text-muted-foreground leading-relaxed">
              Le Maroc abrite plus de <span className="text-foreground font-semibold">700 centres d'appels</span> et reste le hub francophone du nearshore en Afrique. Avec la pression sur les marges et la demande client en explosion, l'automatisation par l'IA n'est plus une option — c'est un impératif compétitif.
            </p>

            <div className="mt-8 grid grid-cols-2 gap-5">
              <div className="glass rounded-xl p-5">
                <div className="text-3xl font-bold text-gradient">3,2 Md€</div>
                <div className="text-xs text-muted-foreground mt-1">Marché BPO Maroc</div>
              </div>
              <div className="glass rounded-xl p-5">
                <div className="text-3xl font-bold text-gradient">+12%</div>
                <div className="text-xs text-muted-foreground mt-1">Croissance annuelle MENA</div>
              </div>
              <div className="glass rounded-xl p-5">
                <div className="text-3xl font-bold text-gradient">80k+</div>
                <div className="text-xs text-muted-foreground mt-1">Agents au Maroc</div>
              </div>
              <div className="glass rounded-xl p-5">
                <div className="text-3xl font-bold text-gradient">4 langues</div>
                <div className="text-xs text-muted-foreground mt-1">AR · FR · EN · Darija</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-6 gradient-primary opacity-20 blur-3xl rounded-full" />
            <div className="relative glass-strong rounded-2xl p-8 space-y-4">
              {[
                { icon: Globe, title: "Multilingue natif", desc: "Comprend le Darija marocain, l'Arabe Standard, le Français et l'Anglais sans configuration." },
                { icon: Shield, title: "Conformité RGPD & CNDP", desc: "Hébergement souverain, données chiffrées, conforme à la loi 09-08." },
                { icon: Zap, title: "Intégration en 48h", desc: "WhatsApp Business API, HubSpot, Salesforce, Zoho, CRM internes via API." },
                { icon: Sparkles, title: "Modèles fine-tunés MENA", desc: "Optimisés sur des millions de conversations en contexte marocain et maghrébin." },
              ].map((item) => (
                <div key={item.title} className="flex gap-4 p-3 rounded-xl hover:bg-secondary/50 transition-colors">
                  <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-medium">{item.title}</div>
                    <div className="text-sm text-muted-foreground mt-0.5">{item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="contact" className="py-24 border-t border-border">
        <div className="max-w-4xl mx-auto px-6">
          <div className="relative overflow-hidden rounded-3xl p-12 text-center">
            <div className="absolute inset-0 gradient-primary opacity-20" />
            <div className="absolute inset-0 grid-pattern opacity-30 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" />
            <div className="relative">
              <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Prêt à transformer votre centre d'appels ?</h2>
              <p className="mt-4 text-lg text-muted-foreground max-w-xl mx-auto">
                Démo personnalisée en 30 minutes. Setup en 48h. ROI mesurable dès le premier mois.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-3 items-center justify-center">
                <a href="mailto:hello@nexora.ai" className="inline-flex items-center gap-2 gradient-primary text-primary-foreground px-6 py-3 rounded-xl font-medium shadow-glow hover:scale-[1.02] transition-transform">
                  <Mail className="w-4 h-4" /> Demander une démo
                </a>
                <Link to="/dashboard" className="inline-flex items-center gap-2 glass-strong px-6 py-3 rounded-xl font-medium hover:bg-secondary transition-colors">
                  Explorer le produit <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg gradient-primary flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-semibold">Nexora AI</span>
            <span className="text-muted-foreground">© 2026</span>
          </div>
          <div className="text-muted-foreground text-center">
            Conçu par <span className="text-foreground font-medium">Yassine Sinif</span> &amp; <span className="text-foreground font-medium">Hamza Zaidi</span> · PFA 2025–2026
          </div>
          <div className="flex gap-5 text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">Confidentialité</a>
            <a href="#" className="hover:text-foreground transition-colors">CGU</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function ChatPreview() {
  const msgs = [
    { from: "bot", text: "Bonjour 👋 Je suis l'assistant IA. Comment puis-je vous aider ?" },
    { from: "user", text: "Bonjour, où en est ma commande #4821 ?" },
    { from: "bot", text: "Je consulte votre dossier... Votre colis est en route, livraison prévue demain entre 14h-17h 📦" },
  ];
  return (
    <div className="grid md:grid-cols-[280px_1fr] h-[420px]">
      <div className="border-r border-border p-3 space-y-1 bg-surface/30 hidden md:block">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground px-2 py-1.5 font-semibold">Conversations</div>
        {[
          { n: "Karim El Idrissi", m: "Merci 🙏", a: "KE", on: true },
          { n: "Fatima Benali", m: "Je n'ai pas reçu...", a: "FB", on: true, active: true },
          { n: "Yassir Lamrini", m: "Bonjour, je souhaite...", a: "YL" },
          { n: "Salma Tazi", m: "Parfait !", a: "ST" },
        ].map((c) => (
          <div key={c.n} className={`flex items-center gap-2.5 p-2 rounded-lg text-left ${c.active ? "bg-secondary" : ""}`}>
            <div className="relative">
              <div className="w-8 h-8 rounded-full bg-primary/20 text-primary text-[10px] font-semibold flex items-center justify-center">{c.a}</div>
              {c.on && <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-success border-2 border-surface" />}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-medium truncate">{c.n}</div>
              <div className="text-[10px] text-muted-foreground truncate">{c.m}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="flex flex-col">
        <div className="flex items-center gap-3 px-5 py-3 border-b border-border">
          <div className="w-8 h-8 rounded-full bg-primary/20 text-primary text-[10px] font-semibold flex items-center justify-center">FB</div>
          <div className="flex-1 text-left">
            <div className="text-sm font-medium">Fatima Benali</div>
            <div className="text-[10px] text-success flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-success" /> En ligne · WhatsApp</div>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-md bg-warning/15 text-warning font-semibold">Sentiment: Neutre</span>
        </div>
        <div className="flex-1 p-5 space-y-3 overflow-hidden text-left">
          {msgs.map((m, i) => (
            <div key={i} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] px-3.5 py-2 rounded-2xl text-xs ${m.from === "user" ? "gradient-primary text-primary-foreground rounded-br-sm" : "bg-secondary rounded-bl-sm"}`}>
                {m.text}
              </div>
            </div>
          ))}
          <div className="flex justify-start">
            <div className="bg-secondary rounded-2xl rounded-bl-sm px-3 py-2.5 flex gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0ms" }} />
              <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "150ms" }} />
              <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
