import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard/header";
import { Search, Send, Paperclip, Smile, MoreVertical, Bot, Sparkles, UserCircle2, Phone, FileText, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { api, type Conversation, type ChatMessage } from "@/lib/api";

export const Route = createFileRoute("/dashboard/conversations")({
  component: ConversationsPage,
});

function initials(name: string) {
  return name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString("fr", { hour: "2-digit", minute: "2-digit" });
}

function ConversationsPage() {
  const queryClient = useQueryClient();
  const [selected, setSelected] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [summary, setSummary] = useState<{ summary: string; intents: string[]; sentiment: string } | null>(null);

  const { data: conversations } = useQuery({
    queryKey: ["conversations"],
    queryFn: () => api.conversations.list(),
  });

  useEffect(() => {
    if (!selected && conversations && conversations.length > 0) {
      setSelected(conversations[0].id);
    }
  }, [conversations, selected]);

  useEffect(() => {
    setSummary(null);
  }, [selected]);

  const { data: messages, isLoading: messagesLoading } = useQuery({
    queryKey: ["conversations", selected, "messages"],
    queryFn: () => api.conversations.getMessages(selected!),
    enabled: !!selected,
  });

  const sendMutation = useMutation({
    mutationFn: (content: string) => api.conversations.sendMessage(selected!, content, "agent"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["conversations", selected, "messages"] });
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
      setDraft("");
    },
  });

  const takeoverMutation = useMutation({
    mutationFn: (mode: "ai" | "human") => api.conversations.takeover(selected!, mode),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["conversations"] }),
  });

  const summarizeMutation = useMutation({
    mutationFn: () => api.conversations.summarize(selected!),
    onSuccess: (data) => setSummary(data),
  });

  const conv = (conversations ?? []).find((c) => c.id === selected) as Conversation | undefined;
  const aiMode = conv?.takeover === "ai";

  function handleSend() {
    if (!draft.trim() || !selected) return;
    sendMutation.mutate(draft.trim());
  }

  return (
    <>
      <DashboardHeader title="Conversations" subtitle={`${conversations?.length ?? 0} conversations actives`} />
      <main className="flex-1 grid md:grid-cols-[320px_1fr_320px] min-h-0 overflow-hidden">
        {/* List */}
        <div className="border-r border-border bg-surface/30 flex flex-col">
          <div className="p-4 border-b border-border">
            <div className="flex items-center gap-2 px-3 h-9 rounded-lg bg-secondary border border-border">
              <Search className="w-4 h-4 text-muted-foreground" />
              <input placeholder="Rechercher..." className="bg-transparent text-sm outline-none flex-1 placeholder:text-muted-foreground" />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {(conversations ?? []).map((c) => (
              <button
                key={c.id}
                onClick={() => setSelected(c.id)}
                className={cn(
                  "w-full p-4 flex gap-3 border-b border-border/50 hover:bg-secondary/40 transition-colors text-left",
                  selected === c.id && "bg-secondary/60"
                )}
              >
                <div className="relative shrink-0">
                  <div className="w-10 h-10 rounded-full bg-primary/15 text-primary text-xs font-semibold flex items-center justify-center">{initials(c.customer)}</div>
                  <div className={cn(
                    "absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-surface flex items-center justify-center text-[7px]",
                    c.channel === "whatsapp" ? "bg-success" : "bg-primary"
                  )}>
                    {c.channel === "whatsapp" ? "W" : "•"}
                  </div>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <div className="text-sm font-medium truncate">{c.customer}</div>
                  </div>
                  <div className="flex items-center justify-between gap-2 mt-0.5">
                    <div className="text-xs text-muted-foreground truncate">{c.lastMessage}</div>
                    {c.unread > 0 && (
                      <span className="text-[10px] font-bold w-4 h-4 rounded-full gradient-primary text-primary-foreground flex items-center justify-center shrink-0">
                        {c.unread}
                      </span>
                    )}
                  </div>
                  <SentimentTag s={c.sentiment} />
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Chat */}
        <div className="flex flex-col min-h-0">
          {conv ? (
            <>
              {/* Chat header */}
              <div className="h-16 px-5 border-b border-border flex items-center justify-between bg-background/60 backdrop-blur-xl">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative">
                    <div className="w-10 h-10 rounded-full bg-primary/15 text-primary text-xs font-semibold flex items-center justify-center">{initials(conv.customer)}</div>
                  </div>
                  <div className="min-w-0">
                    <div className="font-medium truncate">{conv.customer}</div>
                    <div className="text-[11px] text-muted-foreground truncate capitalize">{conv.channel}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => takeoverMutation.mutate(aiMode ? "human" : "ai")}
                    disabled={takeoverMutation.isPending}
                    className={cn(
                      "flex items-center gap-2 px-3 h-9 rounded-lg text-xs font-medium transition-all",
                      aiMode ? "gradient-primary text-primary-foreground shadow-glow" : "bg-secondary border border-border"
                    )}
                  >
                    {aiMode ? <Bot className="w-3.5 h-3.5" /> : <UserCircle2 className="w-3.5 h-3.5" />}
                    {aiMode ? "Mode IA actif" : "Reprise humaine"}
                  </button>
                  <button className="w-9 h-9 rounded-lg bg-secondary/50 border border-border flex items-center justify-center hover:bg-secondary"><Phone className="w-4 h-4" /></button>
                  <button className="w-9 h-9 rounded-lg bg-secondary/50 border border-border flex items-center justify-center hover:bg-secondary"><MoreVertical className="w-4 h-4" /></button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 p-6 overflow-y-auto bg-[radial-gradient(ellipse_at_top,oklch(0.62_0.21_263/0.05),transparent_50%)]">
                <div className="space-y-3 max-w-2xl mx-auto">
                  {messagesLoading && <p className="text-center text-xs text-muted-foreground">Chargement...</p>}
                  {(messages ?? []).map((m: ChatMessage) => (
                    <div key={m.id} className={cn("flex gap-2", m.role === "user" ? "justify-start" : "justify-end")}>
                      {m.role === "user" && (
                        <div className="w-7 h-7 rounded-full bg-primary/15 text-primary text-[10px] font-semibold flex items-center justify-center shrink-0 mt-auto">{initials(conv.customer)}</div>
                      )}
                      <div className={cn(
                        "max-w-[75%] px-4 py-2.5 rounded-2xl text-sm relative",
                        m.role === "user" ? "bg-secondary rounded-bl-md" : "gradient-primary text-primary-foreground rounded-br-md shadow-sm"
                      )}>
                        {m.role === "ai" && (
                          <div className="text-[9px] uppercase tracking-wider font-bold mb-1 flex items-center gap-1 opacity-80">
                            <Sparkles className="w-2.5 h-2.5" /> IA Nexora
                          </div>
                        )}
                        {m.content}
                        <div className={cn("text-[10px] mt-1", m.role === "user" ? "text-muted-foreground" : "text-primary-foreground/70")}>{formatTime(m.createdAt)}</div>
                      </div>
                    </div>
                  ))}
                  {sendMutation.isPending && (
                    <div className="flex gap-2 justify-start">
                      <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center"></div>
                      <div className="bg-secondary rounded-2xl rounded-bl-md px-4 py-3 flex gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce" />
                        <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "150ms" }} />
                        <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "300ms" }} />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Input */}
              <div className="p-4 border-t border-border bg-background/60 backdrop-blur-xl">
                <div className="flex items-end gap-2 max-w-2xl mx-auto">
                  <button className="w-10 h-10 rounded-lg bg-secondary/50 border border-border flex items-center justify-center"><Paperclip className="w-4 h-4" /></button>
                  <div className="flex-1 glass rounded-xl flex items-end">
                    <textarea
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSend();
                        }
                      }}
                      placeholder="Écrire un message en tant qu'agent..."
                      rows={1}
                      className="flex-1 bg-transparent px-4 py-2.5 outline-none text-sm resize-none placeholder:text-muted-foreground"
                    />
                    <button className="p-2 text-muted-foreground hover:text-foreground"><Smile className="w-4 h-4" /></button>
                  </div>
                  <button
                    onClick={handleSend}
                    disabled={sendMutation.isPending || !draft.trim()}
                    className="w-10 h-10 rounded-lg gradient-primary text-primary-foreground shadow-glow flex items-center justify-center hover:scale-105 transition-transform disabled:opacity-50"
                  >
                    {sendMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground">
              {conversations ? "Aucune conversation" : "Chargement..."}
            </div>
          )}
        </div>

        {/* Right panel — Summary */}
        <div className="border-l border-border bg-surface/30 hidden md:flex flex-col overflow-y-auto">
          <div className="p-5 border-b border-border">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                <Sparkles className="w-3.5 h-3.5 text-primary" />
                Résumé IA
              </div>
              <button
                onClick={() => summarizeMutation.mutate()}
                disabled={!selected || summarizeMutation.isPending}
                className="text-xs text-primary font-medium hover:underline disabled:opacity-50 flex items-center gap-1"
              >
                {summarizeMutation.isPending && <Loader2 className="w-3 h-3 animate-spin" />}
                Générer
              </button>
            </div>
            <p className="text-sm leading-relaxed">
              {summary?.summary ?? "Cliquez sur \"Générer\" pour obtenir un résumé IA de cette conversation."}
            </p>
          </div>

          <div className="p-5 border-b border-border">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Intents détectés</div>
            <div className="flex flex-wrap gap-1.5">
              {(summary?.intents ?? []).length === 0 && <span className="text-xs text-muted-foreground">—</span>}
              {(summary?.intents ?? []).map((t) => (
                <span key={t} className="text-[10px] font-medium px-2 py-1 rounded-md bg-primary/10 text-primary border border-primary/20">{t}</span>
              ))}
            </div>
          </div>

          <div className="p-5">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Articles RAG suggérés</div>
            <div className="space-y-2">
              {["Re-envoi de facture", "Problème email non reçu", "Politique facturation"].map((t) => (
                <button key={t} className="w-full text-left p-2.5 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-xs flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

function SentimentTag({ s }: { s: string }) {
  const map: any = {
    positive: { c: "text-success bg-success/10", l: "😊 Positif" },
    neutral: { c: "text-muted-foreground bg-secondary", l: "😐 Neutre" },
    negative: { c: "text-destructive bg-destructive/10", l: "😟 Négatif" },
  };
  return <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded mt-1 inline-block ${map[s].c}`}>{map[s].l}</span>;
}
