import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard/header";
import { BookOpen, Plus, Search, FileText, Upload, Sparkles, Trash2, Loader2 } from "lucide-react";
import { useRef } from "react";
import { api } from "@/lib/api";

export const Route = createFileRoute("/dashboard/knowledge")({
  component: KnowledgePage,
});

const categories = [
  { name: "Tous", count: 47 },
  { name: "Commercial", count: 18 },
  { name: "Technique", count: 14 },
  { name: "Logistique", count: 9 },
  { name: "Facturation", count: 6 },
];

function KnowledgePage() {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: documents, isLoading } = useQuery({
    queryKey: ["knowledge", "documents"],
    queryFn: () => api.knowledge.listDocuments(),
  });

  const uploadMutation = useMutation({
    mutationFn: (file: File) => api.knowledge.uploadDocument(file),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["knowledge", "documents"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.knowledge.deleteDocument(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["knowledge", "documents"] }),
  });

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) uploadMutation.mutate(file);
    e.target.value = "";
  }

  return (
    <>
      <DashboardHeader title="Base de connaissances" subtitle={`${documents?.length ?? 0} documents indexés · RAG actif`} />
      <main className="flex-1 p-6 grid lg:grid-cols-[240px_1fr] gap-6">
        {/* Sidebar */}
        <aside className="space-y-4">
          <input ref={fileInputRef} type="file" accept=".pdf,.txt,.md" className="hidden" onChange={handleFileChange} />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadMutation.isPending}
            className="w-full h-10 rounded-lg gradient-primary text-primary-foreground text-sm font-medium flex items-center justify-center gap-1.5 shadow-glow hover:scale-[1.02] transition-transform disabled:opacity-60"
          >
            {uploadMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {uploadMutation.isPending ? "Import en cours..." : "Importer un document"}
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full h-10 rounded-lg bg-secondary border border-border text-sm flex items-center justify-center gap-1.5 hover:bg-secondary/70"
          >
            <Upload className="w-4 h-4" /> Importer PDF
          </button>

          <div className="glass rounded-xl p-2 space-y-0.5">
            {categories.map((c) => (
              <button key={c.name} className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-secondary text-sm transition-colors">
                <span>{c.name}</span>
                <span className="text-[10px] text-muted-foreground bg-secondary px-1.5 py-0.5 rounded">{c.count}</span>
              </button>
            ))}
          </div>

          <div className="glass rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-xs font-semibold">Suggestion IA</span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              47 questions sans réponse sur "Programme fidélité". Créer un article ?
            </p>
            <button className="mt-3 text-xs text-primary font-medium hover:underline">Générer →</button>
          </div>
        </aside>

        {/* Content */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 px-3 h-10 rounded-lg glass">
            <Search className="w-4 h-4 text-muted-foreground" />
            <input placeholder="Rechercher dans la base de connaissances..." className="bg-transparent text-sm outline-none flex-1 placeholder:text-muted-foreground" />
          </div>

          {isLoading && <p className="text-sm text-muted-foreground">Chargement...</p>}
          {!isLoading && (documents?.length ?? 0) === 0 && (
            <div className="glass rounded-xl p-8 text-center text-sm text-muted-foreground">
              Aucun document indexé. Importez un PDF pour commencer.
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-3">
            {(documents ?? []).map((a) => (
              <div key={a.id} className="glass rounded-xl p-5 hover:border-primary/30 transition-colors group relative">
                <button
                  onClick={() => deleteMutation.mutate(a.id)}
                  className="absolute top-3 right-3 w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                  aria-label="Supprimer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 group-hover:gradient-primary group-hover:shadow-glow transition-all">
                    <FileText className="w-4 h-4 text-primary group-hover:text-primary-foreground transition-colors" />
                  </div>
                  <div className="flex-1 min-w-0 pr-6">
                    <div className="font-medium text-sm leading-snug">{a.title}</div>
                    <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-secondary text-muted-foreground mt-1.5 inline-block">{a.source}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[11px] text-muted-foreground pt-3 border-t border-border">
                  <span className="flex items-center gap-1"><BookOpen className="w-3 h-3" /> {a.chunks} chunks</span>
                  <span>{new Date(a.updatedAt).toLocaleDateString("fr")}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </>
  );
}
