import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard/header";
import { Building2, Plug, Bot, Globe, Bell, Shield, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { api } from "@/lib/api";

export const Route = createFileRoute("/dashboard/settings")({
  component: SettingsPage,
});

const tabs = [
  { id: "company", label: "Entreprise", icon: Building2 },
  { id: "integrations", label: "Intégrations", icon: Plug },
  { id: "ai", label: "Modèle IA", icon: Bot },
  { id: "language", label: "Langues", icon: Globe },
  { id: "sla", label: "SLA", icon: Bell },
  { id: "security", label: "Sécurité", icon: Shield },
];

function SettingsPage() {
  const [tab, setTab] = useState("company");
  return (
    <>
      <DashboardHeader title="Paramètres" subtitle="Configuration de votre espace Nexora AI" />
      <main className="flex-1 p-6 grid lg:grid-cols-[220px_1fr] gap-6">
        <aside className="space-y-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-all",
                tab === t.id ? "glass text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
              )}
            >
              <t.icon className="w-4 h-4" />
              {t.label}
            </button>
          ))}
        </aside>

        <div className="space-y-5">
          {tab === "company" && <CompanyPanel />}
          {tab === "integrations" && <IntegrationsPanel />}
          {tab === "ai" && <AIPanel />}
          {tab === "language" && <LanguagePanel />}
          {tab === "sla" && <SLAPanel />}
          {tab === "security" && <SecurityPanel />}
        </div>
      </main>
    </>
  );
}

function Panel({ title, desc, children }: any) {
  return (
    <div className="glass rounded-2xl p-6">
      <div className="mb-6">
        <h2 className="text-lg font-semibold">{title}</h2>
        {desc && <p className="text-xs text-muted-foreground mt-1">{desc}</p>}
      </div>
      {children}
    </div>
  );
}

function Field({ label, children, hint }: any) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium">{label}</label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}

const inputCls = "w-full h-10 px-3.5 rounded-lg bg-secondary border border-border text-sm outline-none focus:border-primary transition-colors";

function CompanyPanel() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["settings", "company"], queryFn: () => api.settings.getCompany() });
  const [form, setForm] = useState({ name: "", sector: "", country: "", timezone: "" });

  useEffect(() => {
    if (data) setForm({ name: data.name, sector: data.sector, country: data.country, timezone: data.timezone });
  }, [data]);

  const mutation = useMutation({
    mutationFn: () => api.settings.updateCompany(form),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["settings", "company"] }),
  });

  if (isLoading) return <Panel title="Profil de l'entreprise"><p className="text-sm text-muted-foreground">Chargement...</p></Panel>;

  return (
    <Panel title="Profil de l'entreprise" desc="Informations affichées dans vos communications">
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label="Nom de l'entreprise"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
        <Field label="Secteur"><input className={inputCls} value={form.sector} onChange={(e) => setForm({ ...form, sector: e.target.value })} /></Field>
        <Field label="Pays"><input className={inputCls} value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></Field>
        <Field label="Fuseau horaire"><input className={inputCls} value={form.timezone} onChange={(e) => setForm({ ...form, timezone: e.target.value })} /></Field>
      </div>
      <div className="mt-6 flex items-center gap-2 justify-end">
        {mutation.isSuccess && <span className="text-xs text-success">Enregistré ✓</span>}
        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending}
          className="h-9 px-4 rounded-lg gradient-primary text-primary-foreground text-sm font-medium shadow-glow flex items-center gap-2 disabled:opacity-60"
        >
          {mutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
          Enregistrer
        </button>
      </div>
    </Panel>
  );
}

function IntegrationsPanel() {
  const queryClient = useQueryClient();
  const { data: integrations, isLoading } = useQuery({ queryKey: ["settings", "integrations"], queryFn: () => api.settings.listIntegrations() });

  const connectMutation = useMutation({
    mutationFn: (id: string) => api.settings.connectIntegration(id, {}),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["settings", "integrations"] }),
  });

  const descriptions: Record<string, string> = {
    Whatsapp: "Recevez et envoyez des messages WhatsApp",
    Hubspot: "Synchronisation bidirectionnelle des contacts",
    Salesforce: "Création automatique d'opportunités",
    Zendesk: "Import des tickets historiques",
    Slack: "Notifications d'escalade en temps réel",
  };

  if (isLoading) return <Panel title="Intégrations"><p className="text-sm text-muted-foreground">Chargement...</p></Panel>;

  return (
    <Panel title="Intégrations" desc="Connectez Nexora à vos outils existants">
      <div className="space-y-2.5">
        {(integrations ?? []).map((i) => (
          <div key={i.id} className="flex items-center gap-4 p-4 rounded-xl bg-secondary/40 border border-border">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center"><Plug className="w-4 h-4 text-primary" /></div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm">{i.name}</div>
              <div className="text-xs text-muted-foreground">{descriptions[i.name] ?? ""}</div>
            </div>
            <span className={cn("text-[10px] font-semibold px-2 py-1 rounded-md", i.connected ? "bg-success/10 text-success" : "bg-secondary text-muted-foreground")}>
              {i.connected ? "Connecté" : "Disponible"}
            </span>
            <button
              onClick={() => !i.connected && connectMutation.mutate(i.id)}
              disabled={connectMutation.isPending}
              className={cn("h-8 px-3 rounded-lg text-xs font-medium", i.connected ? "bg-secondary hover:bg-secondary/70" : "gradient-primary text-primary-foreground shadow-glow")}
            >
              {i.connected ? "Configurer" : "Connecter"}
            </button>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function AIPanel() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["settings", "ai"], queryFn: () => api.settings.getAIConfig() });
  const [temperature, setTemperature] = useState(0.3);
  const [systemPrompt, setSystemPrompt] = useState("");

  useEffect(() => {
    if (data) {
      setTemperature(data.temperature);
      setSystemPrompt(data.systemPrompt);
    }
  }, [data]);

  const mutation = useMutation({
    mutationFn: () => api.settings.updateAIConfig({ temperature, systemPrompt }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["settings", "ai"] }),
  });

  if (isLoading) return <Panel title="Configuration du modèle IA"><p className="text-sm text-muted-foreground">Chargement...</p></Panel>;

  return (
    <Panel title="Configuration du modèle IA" desc="Choisissez le moteur d'IA qui alimente vos conversations">
      <div className="mb-6 p-4 rounded-xl border border-primary bg-primary/5 shadow-glow flex items-center justify-between">
        <div>
          <div className="font-semibold text-sm">Modèle actif</div>
          <p className="text-xs text-muted-foreground mt-1">Configuré côté serveur via les variables d'environnement</p>
        </div>
        <div className="font-mono text-xs px-3 py-1.5 rounded-lg bg-secondary">{data?.model}</div>
      </div>

      <div className="space-y-4">
        <Field label="Température" hint="Plus la valeur est haute, plus les réponses sont créatives (0 = factuel, 1 = créatif)">
          <input
            type="range" min="0" max="1" step="0.1"
            value={temperature}
            onChange={(e) => setTemperature(parseFloat(e.target.value))}
            className="w-full accent-primary"
          />
          <div className="flex justify-between text-[10px] text-muted-foreground"><span>0 — Factuel</span><span>{temperature}</span><span>1 — Créatif</span></div>
        </Field>
        <Field label="Prompt système" hint="Définit le comportement de base de l'IA">
          <textarea
            rows={4}
            value={systemPrompt}
            onChange={(e) => setSystemPrompt(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-lg bg-secondary border border-border text-sm outline-none focus:border-primary resize-none"
          />
        </Field>
      </div>

      <div className="mt-6 flex items-center gap-2 justify-end">
        {mutation.isSuccess && <span className="text-xs text-success">Enregistré ✓</span>}
        <button
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending}
          className="h-9 px-4 rounded-lg gradient-primary text-primary-foreground text-sm font-medium shadow-glow flex items-center gap-2 disabled:opacity-60"
        >
          {mutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
          Enregistrer
        </button>
      </div>
    </Panel>
  );
}

function LanguagePanel() {
  const langs = [
    { code: "fr", name: "Français", flag: "🇫🇷", active: true },
    { code: "ar", name: "العربية (Arabe Standard)", flag: "🇲🇦", active: true },
    { code: "darija", name: "Darija (الدارجة)", flag: "🇲🇦", active: true },
    { code: "en", name: "English", flag: "🇬🇧", active: true },
    { code: "es", name: "Español", flag: "🇪🇸", active: false },
  ];
  return (
    <Panel title="Langues supportées" desc="L'IA détecte automatiquement la langue et répond en conséquence">
      <div className="space-y-2">
        {langs.map((l) => (
          <div key={l.code} className="flex items-center gap-3 p-3.5 rounded-xl bg-secondary/40 border border-border">
            <span className="text-2xl">{l.flag}</span>
            <div className="flex-1 font-medium text-sm">{l.name}</div>
            <Toggle defaultChecked={l.active} />
          </div>
        ))}
      </div>
    </Panel>
  );
}

function SLAPanel() {
  return (
    <Panel title="Configuration SLA" desc="Engagement de niveau de service par priorité">
      <div className="space-y-4">
        {[
          { p: "Haute", color: "destructive", first: "5 min", resolve: "1h" },
          { p: "Moyenne", color: "warning", first: "30 min", resolve: "4h" },
          { p: "Basse", color: "muted-foreground", first: "2h", resolve: "24h" },
        ].map((s) => (
          <div key={s.p} className="flex items-center gap-4 p-4 rounded-xl bg-secondary/40 border border-border">
            <div className="w-20">
              <span className={`text-[10px] font-semibold px-2 py-1 rounded-md bg-${s.color}/15 text-${s.color}`}>{s.p}</span>
            </div>
            <div className="flex-1 grid grid-cols-2 gap-3">
              <Field label="Première réponse"><input className={inputCls} defaultValue={s.first} /></Field>
              <Field label="Résolution cible"><input className={inputCls} defaultValue={s.resolve} /></Field>
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function SecurityPanel() {
  return (
    <Panel title="Sécurité & conformité" desc="Protection des données et conformité réglementaire">
      <div className="space-y-3">
        {[
          { t: "Authentification à deux facteurs", d: "Sécurise l'accès à votre espace", on: true },
          { t: "Conformité CNDP (Loi 09-08)", d: "Hébergement données au Maroc", on: true },
          { t: "Chiffrement bout-en-bout", d: "AES-256 sur toutes les conversations", on: true },
          { t: "Logs d'audit", d: "Traçabilité complète des actions", on: false },
        ].map((s) => (
          <div key={s.t} className="flex items-center gap-4 p-4 rounded-xl bg-secondary/40 border border-border">
            <Shield className="w-5 h-5 text-primary shrink-0" />
            <div className="flex-1">
              <div className="font-medium text-sm">{s.t}</div>
              <div className="text-xs text-muted-foreground">{s.d}</div>
            </div>
            <Toggle defaultChecked={s.on} />
          </div>
        ))}
      </div>
    </Panel>
  );
}

function Toggle({ defaultChecked }: { defaultChecked: boolean }) {
  const [on, setOn] = useState(defaultChecked);
  return (
    <button
      onClick={() => setOn(!on)}
      className={cn(
        "w-11 h-6 rounded-full p-0.5 transition-colors shrink-0",
        on ? "gradient-primary" : "bg-secondary border border-border"
      )}
    >
      <div className={cn("w-5 h-5 rounded-full bg-white shadow-sm transition-transform", on && "translate-x-5")} />
    </button>
  );
}
