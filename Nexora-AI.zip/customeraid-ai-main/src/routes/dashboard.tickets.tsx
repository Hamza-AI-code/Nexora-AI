import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard/header";
import { PriorityBadge, StatusBadge } from "./dashboard.index";
import { Filter, Plus, Search, Download } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { api } from "@/lib/api";

export const Route = createFileRoute("/dashboard/tickets")({
  component: TicketsPage,
});

const filters = ["Tous", "Ouverts", "En cours", "Résolus", "Haute priorité"];
const filterStatus: Record<string, string | undefined> = {
  "Tous": undefined,
  "Ouverts": "open",
  "En cours": "progress",
  "Résolus": "resolved",
  "Haute priorité": undefined,
};

function TicketsPage() {
  const [filter, setFilter] = useState("Tous");
  const status = filterStatus[filter];
  const priority = filter === "Haute priorité" ? "high" : undefined;
  const { data: tickets } = useQuery({
    queryKey: ["tickets", status, priority],
    queryFn: () => api.tickets.list({ status: status as any, priority: priority as any }),
  });
  const recentTickets = tickets ?? [];
  return (
    <>
      <DashboardHeader title="Tickets" subtitle="Gestion centralisée de tous les tickets clients" />
      <main className="flex-1 p-6 space-y-5 overflow-x-hidden">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  "px-3.5 h-9 rounded-lg text-xs font-medium transition-all",
                  filter === f
                    ? "gradient-primary text-primary-foreground shadow-glow"
                    : "bg-secondary border border-border hover:bg-secondary/70"
                )}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 h-9 rounded-lg bg-secondary border border-border w-60">
              <Search className="w-3.5 h-3.5 text-muted-foreground" />
              <input placeholder="ID, client, intent..." className="bg-transparent text-xs outline-none flex-1 placeholder:text-muted-foreground" />
            </div>
            <button className="h-9 px-3 rounded-lg bg-secondary border border-border text-xs flex items-center gap-1.5 hover:bg-secondary/70"><Filter className="w-3.5 h-3.5" /> Filtres</button>
            <button className="h-9 px-3 rounded-lg bg-secondary border border-border text-xs flex items-center gap-1.5 hover:bg-secondary/70"><Download className="w-3.5 h-3.5" /> Export</button>
            <button className="h-9 px-3.5 rounded-lg gradient-primary text-primary-foreground text-xs font-medium flex items-center gap-1.5 shadow-glow hover:scale-[1.02] transition-transform">
              <Plus className="w-3.5 h-3.5" /> Nouveau ticket
            </button>
          </div>
        </div>

        <div className="glass rounded-2xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground border-b border-border bg-surface/50">
                <th className="font-medium px-5 py-3.5">ID</th>
                <th className="font-medium px-5 py-3.5">Client</th>
                <th className="font-medium px-5 py-3.5">Intent</th>
                <th className="font-medium px-5 py-3.5">Canal</th>
                <th className="font-medium px-5 py-3.5">Priorité</th>
                <th className="font-medium px-5 py-3.5">Statut</th>
                <th className="font-medium px-5 py-3.5">Agent assigné</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {recentTickets.map((t) => (
                <tr key={t.id} className="hover:bg-secondary/30 cursor-pointer transition-colors">
                  <td className="px-5 py-4 font-mono text-xs text-muted-foreground">{t.id}</td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-primary/15 text-primary text-[10px] font-semibold flex items-center justify-center">
                        {t.customer.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                      </div>
                      <span className="font-medium">{t.customer}</span>
                    </div>
                  </td>
                  <td className="px-5 py-4 text-muted-foreground">{t.intent}</td>
                  <td className="px-5 py-4">
                    <span className={cn(
                      "text-[10px] font-medium px-2 py-1 rounded-md",
                      t.channel === "WhatsApp" ? "bg-success/10 text-success" : "bg-primary/10 text-primary"
                    )}>{t.channel}</span>
                  </td>
                  <td className="px-5 py-4"><PriorityBadge p={t.priority} /></td>
                  <td className="px-5 py-4"><StatusBadge s={t.status} /></td>
                  <td className="px-5 py-4 text-muted-foreground text-xs">{t.agent}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="px-5 py-3.5 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
            <span>Affichage de 1-8 sur 142 tickets</span>
            <div className="flex items-center gap-1">
              <button className="px-2.5 py-1 rounded-md bg-secondary hover:bg-secondary/70">Précédent</button>
              <button className="px-2.5 py-1 rounded-md gradient-primary text-primary-foreground">1</button>
              <button className="px-2.5 py-1 rounded-md hover:bg-secondary">2</button>
              <button className="px-2.5 py-1 rounded-md hover:bg-secondary">3</button>
              <button className="px-2.5 py-1 rounded-md bg-secondary hover:bg-secondary/70">Suivant</button>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
