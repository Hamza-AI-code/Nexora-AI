import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard/header";
import { PriorityBadge, StatusBadge } from "./dashboard.index";
import { CheckCircle2, Ticket as TicketIcon, Clock, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { api, type TicketStatus } from "@/lib/api";

export const Route = createFileRoute("/dashboard/my-tickets")({
  component: MyTicketsPage,
});

const filters: { label: string; value: TicketStatus | undefined }[] = [
  { label: "Tous", value: undefined },
  { label: "Ouverts", value: "open" },
  { label: "En cours", value: "progress" },
  { label: "Résolus", value: "resolved" },
];

function MyTicketsPage() {
  const [filter, setFilter] = useState<TicketStatus | undefined>(undefined);
  const queryClient = useQueryClient();

  const { data: profile } = useQuery({
    queryKey: ["agents", "me"],
    queryFn: () => api.agents.me(),
  });

  const { data: ticketsData } = useQuery({
    queryKey: ["agents", "me", "tickets", filter],
    queryFn: () => api.agents.myTickets(filter),
  });

  const resolveMutation = useMutation({
    mutationFn: (id: string) => api.tickets.update(id, { status: "resolved" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["agents", "me", "tickets"] });
      queryClient.invalidateQueries({ queryKey: ["agents", "me"] });
    },
  });

  const myTickets = ticketsData ?? [];
  const initials = profile?.name
    ? profile.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()
    : "..";

  return (
    <>
      <DashboardHeader title="Mon espace" subtitle="Vos tickets, votre historique et votre score" />
      <main className="flex-1 p-6 space-y-5 overflow-x-hidden">
        {/* Profile card */}
        <div className="glass rounded-2xl p-5 flex flex-wrap items-center gap-5">
          <div className="w-14 h-14 rounded-full gradient-primary flex items-center justify-center text-lg font-semibold text-primary-foreground shrink-0">
            {initials}
          </div>
          <div className="min-w-0">
            <div className="font-semibold">{profile?.name ?? "..."}</div>
            <div className="text-xs text-muted-foreground">{profile?.email}</div>
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <span className={cn("w-2 h-2 rounded-full", profile?.status === "online" ? "bg-success" : "bg-muted-foreground/40")} />
            <span className="text-xs text-muted-foreground capitalize">
              {profile?.status === "online" ? "En ligne" : "Hors ligne"}
            </span>
            <span className="text-[10px] font-semibold px-2 py-1 rounded-md bg-primary/15 text-primary capitalize">
              {profile?.role}
            </span>
          </div>
        </div>

        {/* Score cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="glass rounded-2xl p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-success/15 text-success flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="text-xl font-bold">{profile?.resolvedCount ?? 0}</div>
              <div className="text-xs text-muted-foreground">Tickets résolus</div>
            </div>
          </div>
          <div className="glass rounded-2xl p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-warning/15 text-warning flex items-center justify-center shrink-0">
              <Clock className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="text-xl font-bold">{profile?.openCount ?? 0}</div>
              <div className="text-xs text-muted-foreground">En cours / ouverts</div>
            </div>
          </div>
          <div className="glass rounded-2xl p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-destructive/15 text-destructive flex items-center justify-center shrink-0">
              <AlertTriangle className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="text-xl font-bold">{profile?.escalatedCount ?? 0}</div>
              <div className="text-xs text-muted-foreground">Escaladés</div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          {filters.map((f) => (
            <button
              key={f.label}
              onClick={() => setFilter(f.value)}
              className={cn(
                "px-3.5 h-9 rounded-lg text-xs font-medium transition-all",
                filter === f.value
                  ? "gradient-primary text-primary-foreground shadow-glow"
                  : "bg-secondary border border-border hover:bg-secondary/70"
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Tickets table */}
        <div className="glass rounded-2xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-muted-foreground border-b border-border bg-surface/50">
                <th className="font-medium px-5 py-3.5">ID</th>
                <th className="font-medium px-5 py-3.5">Client</th>
                <th className="font-medium px-5 py-3.5">Intent</th>
                <th className="font-medium px-5 py-3.5">Canal</th>
                <th className="font-medium px-5 py-3.5">Priorité</th>
                <th className="font-medium px-5 py-3.5">Statut</th>
                <th className="font-medium px-5 py-3.5">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {myTickets.map((t) => (
                <tr key={t.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-5 py-4 font-mono text-xs text-muted-foreground">{t.id.slice(0, 8)}</td>
                  <td className="px-5 py-4 font-medium">{t.customer}</td>
                  <td className="px-5 py-4 text-muted-foreground">{t.intent}</td>
                  <td className="px-5 py-4">
                    <span className="text-[10px] font-medium px-2 py-1 rounded-md bg-primary/10 text-primary">{t.channel}</span>
                  </td>
                  <td className="px-5 py-4"><PriorityBadge p={t.priority} /></td>
                  <td className="px-5 py-4"><StatusBadge s={t.status} /></td>
                  <td className="px-5 py-4">
                    {t.status !== "resolved" ? (
                      <button
                        onClick={() => resolveMutation.mutate(t.id)}
                        disabled={resolveMutation.isPending}
                        className="text-xs font-medium px-3 py-1.5 rounded-lg bg-success/15 text-success hover:bg-success/25 transition-colors disabled:opacity-50"
                      >
                        Marquer résolu
                      </button>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </td>
                </tr>
              ))}
              {myTickets.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-5 py-10 text-center text-sm text-muted-foreground">
                    <TicketIcon className="w-6 h-6 mx-auto mb-2 opacity-50" />
                    Aucun ticket pour le moment.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </main>
    </>
  );
}
