import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard/header";
import {
  ResponsiveContainer, LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend,
} from "recharts";
import { handlingTimeData } from "@/lib/mock-data";
import { api } from "@/lib/api";

export const Route = createFileRoute("/dashboard/analytics")({
  component: AnalyticsPage,
});

const COLORS = ["oklch(0.62 0.21 263)", "oklch(0.27 0.03 265)"];

const tooltipStyle = {
  background: "oklch(0.22 0.025 265)",
  border: "1px solid oklch(1 0 0 / 0.08)",
  borderRadius: 12,
  fontSize: 12,
};

function AnalyticsPage() {
  const { data: kpis } = useQuery({ queryKey: ["dashboard", "kpis"], queryFn: () => api.dashboard.getKPIs() });
  const { data: ticketVolumeData } = useQuery({ queryKey: ["analytics", "ticket-volume"], queryFn: () => api.analytics.ticketVolume() });
  const { data: costSavingsData } = useQuery({ queryKey: ["analytics", "cost-savings"], queryFn: () => api.analytics.costSavings() });

  const automationDonut = kpis
    ? [
        { name: "Auto-résolu IA", value: kpis.autoResolvedRate },
        { name: "Agent humain", value: 100 - kpis.autoResolvedRate },
      ]
    : [];

  return (
    <>
      <DashboardHeader title="Analytics" subtitle="Performance, économies & impact IA" />
      <main className="flex-1 p-6 space-y-5">
        <div className="grid lg:grid-cols-3 gap-4">
          <SummaryCard title="Conversations traitées" value={kpis ? kpis.conversations.toLocaleString("fr") : "—"} sub={kpis ? `${kpis.conversationsDelta > 0 ? "+" : ""}${kpis.conversationsDelta}% vs période précédente` : ""} />
          <SummaryCard title="Taux d'automatisation" value={kpis ? `${kpis.autoResolvedRate}%` : "—"} sub={kpis ? `${kpis.resolvedDelta > 0 ? "+" : ""}${kpis.resolvedDelta} pts vs période précédente` : ""} highlight />
          <SummaryCard title="Coût économisé" value={kpis ? `${kpis.costSaved.toLocaleString("fr")} MAD` : "—"} sub={kpis ? `${kpis.costDelta > 0 ? "+" : ""}${kpis.costDelta}% vs période précédente` : ""} />
        </div>

        <div className="grid lg:grid-cols-3 gap-4">
          {/* Volume */}
          <div className="lg:col-span-2 glass rounded-2xl p-6">
            <div className="mb-5">
              <h3 className="font-semibold">Volume de tickets dans le temps</h3>
              <p className="text-xs text-muted-foreground">Évolution hebdomadaire</p>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ticketVolumeData ?? []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.05)" />
                  <XAxis dataKey="day" stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                  <YAxis stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Line type="monotone" dataKey="total" stroke="oklch(0.62 0.21 263)" strokeWidth={2.5} dot={{ fill: "oklch(0.62 0.21 263)", r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Donut */}
          <div className="glass rounded-2xl p-6">
            <div className="mb-5">
              <h3 className="font-semibold">Taux d'automatisation</h3>
              <p className="text-xs text-muted-foreground">Répartition IA / humain</p>
            </div>
            <div className="h-72 flex items-center justify-center relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={automationDonut} dataKey="value" innerRadius={70} outerRadius={100} paddingAngle={2}>
                    {automationDonut.map((_, i) => <Cell key={i} fill={COLORS[i]} stroke="none" />)}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <div className="text-3xl font-bold">{kpis ? `${Math.round(kpis.autoResolvedRate)}%` : "—"}</div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Auto-résolu</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-primary" /> IA {kpis ? `${kpis.autoResolvedRate}%` : "—"}</div>
              <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-secondary" /> Humain {kpis ? `${(100 - kpis.autoResolvedRate).toFixed(1)}%` : "—"}</div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-4">
          {/* Cost savings */}
          <div className="glass rounded-2xl p-6">
            <div className="mb-5">
              <h3 className="font-semibold">Économies réalisées (MAD)</h3>
              <p className="text-xs text-muted-foreground">6 derniers mois</p>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={costSavingsData ?? []}>
                  <defs>
                    <linearGradient id="bar" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="oklch(0.72 0.18 263)" />
                      <stop offset="100%" stopColor="oklch(0.55 0.20 263)" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.05)" />
                  <XAxis dataKey="month" stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                  <YAxis stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => `${v.toLocaleString("fr")} MAD`} />
                  <Bar dataKey="saved" fill="url(#bar)" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Handling time */}
          <div className="glass rounded-2xl p-6">
            <div className="mb-5">
              <h3 className="font-semibold">Temps de traitement moyen</h3>
              <p className="text-xs text-muted-foreground">Avant vs après IA (minutes)</p>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={handlingTimeData}>
                  <defs>
                    <linearGradient id="before" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.62 0.22 25)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.62 0.22 25)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="after" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.70 0.16 155)" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="oklch(0.70 0.16 155)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.05)" />
                  <XAxis dataKey="week" stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                  <YAxis stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Area type="monotone" dataKey="before" name="Avant IA" stroke="oklch(0.62 0.22 25)" fill="url(#before)" strokeWidth={2} />
                  <Area type="monotone" dataKey="after" name="Avec IA" stroke="oklch(0.70 0.16 155)" fill="url(#after)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* AI vs Human */}
        <div className="glass rounded-2xl p-6">
          <div className="mb-5">
            <h3 className="font-semibold">IA vs Humain — Résolution comparée</h3>
            <p className="text-xs text-muted-foreground">7 derniers jours</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ticketVolumeData ?? []}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.05)" />
                <XAxis dataKey="day" stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                <YAxis stroke="oklch(0.68 0.02 260)" fontSize={11} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="ai" name="IA" stackId="a" fill="oklch(0.62 0.21 263)" radius={[0, 0, 0, 0]} />
                <Bar dataKey="human" name="Humain" stackId="a" fill="oklch(0.68 0.02 260)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </main>
    </>
  );
}

function SummaryCard({ title, value, sub, highlight }: any) {
  return (
    <div className={`relative rounded-2xl p-5 overflow-hidden ${highlight ? "" : "glass"}`}>
      {highlight && <><div className="absolute inset-0 gradient-primary opacity-20" /><div className="absolute inset-0 glass" /></>}
      <div className="relative">
        <div className="text-xs text-muted-foreground">{title}</div>
        <div className="text-3xl font-bold tracking-tight mt-2">{value}</div>
        <div className="text-[11px] text-success mt-1">{sub}</div>
      </div>
    </div>
  );
}
