import { createFileRoute } from "@tanstack/react-router";
import { DashboardHeader } from "@/components/dashboard/header";
import { aiInsights } from "@/lib/mock-data";
import { AlertTriangle, Info, CheckCircle2, Sparkles, TrendingUp, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dashboard/insights")({
  component: InsightsPage,
});

function InsightsPage() {
  return (
    <>
      <DashboardHeader title="AI Insights" subtitle="Recommandations & prédictions générées par l'IA" />
      <main className="flex-1 p-6 space-y-6">
        {/* Hero insight */}
        <div className="relative overflow-hidden rounded-2xl p-7">
          <div className="absolute inset-0 gradient-primary opacity-20" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          <div className="relative flex items-start gap-5">
            <div className="w-12 h-12 rounded-xl gradient-primary shadow-glow flex items-center justify-center shrink-0">
              <Sparkles className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="flex-1">
              <div className="text-[10px] font-semibold uppercase tracking-wider text-primary mb-1">Insight de la semaine</div>
              <h2 className="text-2xl font-bold tracking-tight">Vous avez économisé 247 500 MAD ce mois</h2>
              <p className="text-sm text-muted-foreground mt-2 max-w-2xl">
                C'est <span className="text-success font-semibold">+18.7%</span> par rapport au mois dernier. L'IA a traité 81.3% des conversations sans intervention humaine, libérant vos agents pour les cas à forte valeur ajoutée.
              </p>
              <div className="mt-5 flex flex-wrap gap-4 text-sm">
                <Stat label="Heures agent économisées" value="1,247h" />
                <Stat label="Conversations automatisées" value="10,447" />
                <Stat label="ROI sur 6 mois" value="324%" />
              </div>
            </div>
          </div>
        </div>

        {/* Insights grid */}
        <div>
          <h3 className="text-sm font-semibold mb-3">Recommandations actionnables</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {aiInsights.map((i) => (
              <InsightCard key={i.title} {...i} />
            ))}
          </div>
        </div>

        {/* Top intents */}
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="glass rounded-2xl p-6">
            <h3 className="font-semibold mb-1">Top intents cette semaine</h3>
            <p className="text-xs text-muted-foreground mb-5">Distribution des demandes clients</p>
            <div className="space-y-3.5">
              {[
                { name: "Suivi de commande", v: 32, c: 4108 },
                { name: "Information produit", v: 24, c: 3081 },
                { name: "Facturation", v: 18, c: 2312 },
                { name: "Retour / Remboursement", v: 14, c: 1798 },
                { name: "Support technique", v: 8, c: 1027 },
                { name: "Autre", v: 4, c: 521 },
              ].map((i) => (
                <div key={i.name}>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-medium">{i.name}</span>
                    <span className="text-muted-foreground">{i.c.toLocaleString("fr")} · {i.v}%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full gradient-primary rounded-full" style={{ width: `${i.v * 3}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="glass rounded-2xl p-6">
            <h3 className="font-semibold mb-1">Analyse de sentiment</h3>
            <p className="text-xs text-muted-foreground mb-5">Tendance sur 30 jours</p>
            <div className="grid grid-cols-3 gap-3 mb-5">
              <SentimentCard label="Positif" value={62} color="text-success bg-success/10" emoji="😊" />
              <SentimentCard label="Neutre" value={28} color="text-muted-foreground bg-secondary" emoji="😐" />
              <SentimentCard label="Négatif" value={10} color="text-destructive bg-destructive/10" emoji="😟" />
            </div>
            <div className="p-3.5 rounded-xl bg-success/5 border border-success/20 flex gap-3">
              <TrendingUp className="w-4 h-4 text-success shrink-0 mt-0.5" />
              <div className="text-xs">
                <div className="font-semibold text-success">Sentiment en amélioration</div>
                <div className="text-muted-foreground mt-0.5">+12 points vs mois dernier. Les réponses plus rapides de l'IA y contribuent fortement.</div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

function InsightCard({ title, desc, severity }: any) {
  const map: any = {
    info: { i: Info, c: "text-primary bg-primary/10 border-primary/20" },
    warning: { i: AlertTriangle, c: "text-warning bg-warning/10 border-warning/20" },
    success: { i: CheckCircle2, c: "text-success bg-success/10 border-success/20" },
  };
  const { i: I, c } = map[severity];
  return (
    <div className="glass rounded-2xl p-5 group hover:border-primary/30 transition-colors">
      <div className="flex items-start gap-4">
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center shrink-0 border", c)}>
          <I className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-semibold">{title}</div>
          <p className="text-sm text-muted-foreground mt-1.5 leading-relaxed">{desc}</p>
          <button className="mt-3 text-xs text-primary font-medium flex items-center gap-1 hover:underline">
            Voir détails <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-lg px-3.5 py-2">
      <div className="text-lg font-bold tracking-tight">{value}</div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</div>
    </div>
  );
}

function SentimentCard({ label, value, color, emoji }: any) {
  return (
    <div className={cn("rounded-xl p-3.5 text-center", color)}>
      <div className="text-2xl mb-1">{emoji}</div>
      <div className="text-xl font-bold">{value}%</div>
      <div className="text-[10px] uppercase tracking-wider mt-0.5">{label}</div>
    </div>
  );
}
