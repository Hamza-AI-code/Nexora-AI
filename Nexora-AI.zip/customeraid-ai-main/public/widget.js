/*!
 * Nexora AI - Embeddable Chat Widget
 *
 * Usage:
 *   <script
 *     src="https://your-nexora-domain/widget.js"
 *     data-company="acme-corp"
 *     data-api="https://your-nexora-domain/v1"
 *     data-title="Acme Support"
 *     data-color="#5b63d3"
 *     data-greeting="Bonjour ! Comment puis-je vous aider ?"
 *     async
 *   ></script>
 *
 * Only data-company is required to tell Nexora which conversation bucket
 * this site belongs to. data-api should point at the Nexora backend.
 */
(function () {
  "use strict";

  if (window.__nexoraWidgetLoaded) return;
  window.__nexoraWidgetLoaded = true;

  var currentScript =
    document.currentScript ||
    (function () {
      var scripts = document.getElementsByTagName("script");
      return scripts[scripts.length - 1];
    })();

  function attr(name, fallback) {
    var value = currentScript.getAttribute(name);
    return value === null || value === undefined || value === "" ? fallback : value;
  }

  var config = {
    company: attr("data-company", "default"),
    apiBase: attr("data-api", "http://localhost:8010/v1").replace(/\/$/, ""),
    title: attr("data-title", "Nexora Assistant"),
    subtitle: attr("data-subtitle", "Generalement en ligne"),
    color: attr("data-color", "#5b63d3"),
    greeting: attr(
      "data-greeting",
      "Bonjour ! Comment puis-je vous aider aujourd'hui ?"
    ),
    position: attr("data-position", "right"),
  };

  var STORAGE_KEY = "nexora_widget_conversation_" + config.company;

  function uuidv4() {
    if (window.crypto && window.crypto.randomUUID) {
      return window.crypto.randomUUID();
    }
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
      var r = (Math.random() * 16) | 0;
      var v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  var conversationId = localStorage.getItem(STORAGE_KEY);
  if (!conversationId) {
    conversationId = uuidv4();
    localStorage.setItem(STORAGE_KEY, conversationId);
  }

  var renderedIds = {};
  var isPanelOpen = false;
  var hasLoadedHistory = false;
  var pollTimer = null;
  var sideProp = config.position === "left" ? "left" : "right";

  // ---------------------------------------------------------------------
  // Styles (scoped under #nexora-widget so the host page is never touched)
  // ---------------------------------------------------------------------
  var style = document.createElement("style");
  style.textContent =
    "#nexora-widget *{box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;}" +
    "#nexora-widget{position:fixed;bottom:20px;" + sideProp + ":20px;z-index:2147483000;}" +
    "#nexora-widget .nx-launcher{width:60px;height:60px;border-radius:50%;border:none;cursor:pointer;" +
    "background:#5b63d3;background:" + config.color + ";box-shadow:0 6px 24px rgba(0,0,0,.2);display:flex;align-items:center;justify-content:center;" +
    "transition:transform .15s ease;color:#fff;}" +
    "#nexora-widget .nx-launcher:hover{transform:scale(1.06);}" +
    "#nexora-widget .nx-launcher svg{width:26px;height:26px;}" +
    "#nexora-widget .nx-badge{position:absolute;top:-4px;" + sideProp + ":-4px;background:#ef4444;color:#fff;border-radius:50%;" +
    "min-width:18px;height:18px;font-size:11px;line-height:18px;text-align:center;padding:0 4px;font-weight:600;}" +
    "#nexora-widget .nx-panel{position:absolute;bottom:74px;" + sideProp + ":0;width:360px;max-width:calc(100vw - 24px);height:520px;max-height:calc(100vh - 110px);" +
    "background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.25);display:flex;flex-direction:column;overflow:hidden;" +
    "opacity:0;transform:translateY(16px) scale(.98);pointer-events:none;transition:opacity .18s ease,transform .18s ease;}" +
    "#nexora-widget .nx-panel.nx-open{opacity:1;transform:translateY(0) scale(1);pointer-events:auto;}" +
    "#nexora-widget .nx-header{background:#5b63d3;background:" + config.color + ";color:#fff;padding:16px 18px;display:flex;flex-direction:column;gap:2px;flex-shrink:0;}" +
    "#nexora-widget .nx-header-row{display:flex;align-items:center;justify-content:space-between;}" +
    "#nexora-widget .nx-title{font-size:15px;font-weight:600;margin:0;}" +
    "#nexora-widget .nx-subtitle{font-size:12px;opacity:.85;display:flex;align-items:center;gap:6px;}" +
    "#nexora-widget .nx-dot{width:7px;height:7px;border-radius:50%;background:#4ade80;display:inline-block;}" +
    "#nexora-widget .nx-close{background:rgba(255,255,255,.15);border:none;color:#fff;border-radius:8px;width:28px;height:28px;cursor:pointer;display:flex;align-items:center;justify-content:center;}" +
    "#nexora-widget .nx-close:hover{background:rgba(255,255,255,.28);}" +
    "#nexora-widget .nx-body{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;background:#f7f7fb;}" +
    "#nexora-widget .nx-msg{max-width:80%;padding:9px 13px;border-radius:14px;font-size:13.5px;line-height:1.45;white-space:pre-wrap;word-wrap:break-word;}" +
    "#nexora-widget .nx-msg.nx-user{align-self:flex-end;background:#5b63d3;background:" + config.color + ";color:#fff;border-bottom-right-radius:4px;}" +
    "#nexora-widget .nx-msg.nx-bot{align-self:flex-start;background:#fff;color:#1f2230;border:1px solid #e6e6ef;border-bottom-left-radius:4px;}" +
    "#nexora-widget .nx-msg.nx-error{align-self:center;background:#fee2e2;color:#991b1b;font-size:12px;}" +
    "#nexora-widget .nx-typing{align-self:flex-start;display:flex;gap:4px;padding:10px 13px;background:#fff;border:1px solid #e6e6ef;border-radius:14px;border-bottom-left-radius:4px;}" +
    "#nexora-widget .nx-typing span{width:6px;height:6px;border-radius:50%;background:#b5b8c9;animation:nx-bounce 1.2s infinite ease-in-out;}" +
    "#nexora-widget .nx-typing span:nth-child(2){animation-delay:.15s;}" +
    "#nexora-widget .nx-typing span:nth-child(3){animation-delay:.3s;}" +
    "@keyframes nx-bounce{0%,80%,100%{transform:translateY(0);opacity:.5;}40%{transform:translateY(-4px);opacity:1;}}" +
    "#nexora-widget .nx-footer{display:flex;gap:8px;padding:12px;border-top:1px solid #ececf3;background:#fff;flex-shrink:0;}" +
    "#nexora-widget .nx-input{flex:1;border:1px solid #dcdce6;border-radius:10px;padding:10px 12px;font-size:13.5px;resize:none;max-height:80px;outline:none;color:#1f2230;background:#fff;}" +
    "#nexora-widget .nx-input:focus{border-color:" + config.color + ";}" +
    "#nexora-widget .nx-send{background:#5b63d3;background:" + config.color + ";border:none;color:#fff;border-radius:10px;width:40px;flex-shrink:0;cursor:pointer;display:flex;align-items:center;justify-content:center;}" +
    "#nexora-widget .nx-send:disabled{opacity:.5;cursor:default;}" +
    "#nexora-widget .nx-send svg{width:18px;height:18px;}" +
    "#nexora-widget .nx-powered{text-align:center;font-size:10.5px;color:#9a9aab;padding:6px 0 10px;background:#fff;}" +
    "@media (max-width:480px){#nexora-widget .nx-panel{width:calc(100vw - 24px);height:calc(100vh - 110px);}}";
  document.head.appendChild(style);

  // ---------------------------------------------------------------------
  // DOM structure
  // ---------------------------------------------------------------------
  var root = document.createElement("div");
  root.id = "nexora-widget";

  var chatIcon =
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 3C7.03 3 3 6.58 3 11c0 2.39 1.19 4.53 3.08 6.02L5.5 21l4.18-1.67c.74.15 1.51.23 2.32.23 4.97 0 9-3.58 9-8s-4.03-8-9-8z" fill="currentColor"/></svg>';
  var closeIcon =
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>';
  var sendIcon =
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 11l18-7-7 18-2.5-7L3 11z" fill="currentColor"/></svg>';

  root.innerHTML =
    '<div class="nx-panel" id="nx-panel">' +
    '  <div class="nx-header">' +
    '    <div class="nx-header-row">' +
    '      <p class="nx-title"></p>' +
    '      <button class="nx-close" id="nx-close" aria-label="Fermer" type="button">' + closeIcon + "</button>" +
    "    </div>" +
    '    <div class="nx-subtitle"><span class="nx-dot"></span><span></span></div>' +
    "  </div>" +
    '  <div class="nx-body" id="nx-body"></div>' +
    '  <div class="nx-footer">' +
    '    <textarea class="nx-input" id="nx-input" rows="1" placeholder="Ecrivez votre message..."></textarea>' +
    '    <button class="nx-send" id="nx-send" type="button">' + sendIcon + "</button>" +
    "  </div>" +
    '  <div class="nx-powered">Propulse par Nexora AI</div>' +
    "</div>" +
    '<button class="nx-launcher" id="nx-launcher" type="button" aria-label="Ouvrir le chat">' + chatIcon + "</button>";

  document.body.appendChild(root);

  // Fill in text content safely (avoid innerHTML for user-controlled config)
  root.querySelector(".nx-title").textContent = config.title;
  root.querySelector(".nx-subtitle span:last-child").textContent = config.subtitle;

  var launcher = root.querySelector("#nx-launcher");
  var panel = root.querySelector("#nx-panel");
  var closeBtn = root.querySelector("#nx-close");
  var body = root.querySelector("#nx-body");
  var input = root.querySelector("#nx-input");
  var sendBtn = root.querySelector("#nx-send");

  // ---------------------------------------------------------------------
  // Rendering helpers
  // ---------------------------------------------------------------------
  function scrollToBottom() {
    body.scrollTop = body.scrollHeight;
  }

  function addMessage(role, content, id) {
    if (id) {
      if (renderedIds[id]) return;
      renderedIds[id] = true;
    }
    var bubble = document.createElement("div");
    bubble.className = "nx-msg " + (role === "user" ? "nx-user" : role === "error" ? "nx-error" : "nx-bot");
    bubble.textContent = content;
    body.appendChild(bubble);
    scrollToBottom();
    return bubble;
  }

  var typingEl = null;
  function showTyping() {
    if (typingEl) return;
    typingEl = document.createElement("div");
    typingEl.className = "nx-typing";
    typingEl.innerHTML = "<span></span><span></span><span></span>";
    body.appendChild(typingEl);
    scrollToBottom();
  }
  function hideTyping() {
    if (typingEl) {
      typingEl.remove();
      typingEl = null;
    }
  }

  // ---------------------------------------------------------------------
  // API calls
  // ---------------------------------------------------------------------
  function fetchHistory() {
    return fetch(config.apiBase + "/conversations/" + conversationId + "/messages", {
      headers: { Accept: "application/json" },
    })
      .then(function (res) {
        if (!res.ok) throw new Error("history_failed");
        return res.json();
      })
      .then(function (messages) {
        if (!messages || !messages.length) {
          if (!hasLoadedHistory) {
            addMessage("ai", config.greeting);
          }
        } else {
          messages.forEach(function (m) {
            addMessage(m.role === "user" ? "user" : "ai", m.content, m.id);
          });
        }
        hasLoadedHistory = true;
      })
      .catch(function () {
        if (!hasLoadedHistory) {
          addMessage("ai", config.greeting);
          hasLoadedHistory = true;
        }
      });
  }

  function pollForReplies() {
    fetch(config.apiBase + "/conversations/" + conversationId + "/messages", {
      headers: { Accept: "application/json" },
    })
      .then(function (res) {
        if (!res.ok) throw new Error("poll_failed");
        return res.json();
      })
      .then(function (messages) {
        messages.forEach(function (m) {
          if (m.role !== "user") {
            addMessage("ai", m.content, m.id);
          }
        });
      })
      .catch(function () {
        /* silent retry on next interval */
      });
  }

  function startPolling() {
    if (pollTimer) return;
    pollTimer = window.setInterval(pollForReplies, 5000);
  }
  function stopPolling() {
    if (pollTimer) {
      window.clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  function sendMessage(text) {
    addMessage("user", text);
    input.value = "";
    input.style.height = "auto";
    sendBtn.disabled = true;
    showTyping();

    fetch(config.apiBase + "/conversations/" + conversationId + "/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ content: text, as: "user" }),
    })
      .then(function (res) {
        if (!res.ok) throw new Error("send_failed");
        return res.json();
      })
      .then(function (message) {
        hideTyping();
        if (message && message.role && message.role !== "user") {
          addMessage("ai", message.content, message.id);
        } else if (message && message.id) {
          renderedIds[message.id] = true;
        }
      })
      .catch(function () {
        hideTyping();
        addMessage("error", "Connexion impossible. Veuillez reessayer dans un instant.");
      })
      .finally(function () {
        sendBtn.disabled = false;
        input.focus();
      });
  }

  // ---------------------------------------------------------------------
  // Events
  // ---------------------------------------------------------------------
  function openPanel() {
    isPanelOpen = true;
    panel.classList.add("nx-open");
    launcher.innerHTML = closeIcon;
    var badge = root.querySelector(".nx-badge");
    if (badge) badge.remove();
    if (!hasLoadedHistory) {
      fetchHistory();
    }
    startPolling();
    setTimeout(function () {
      input.focus();
    }, 200);
  }

  function closePanel() {
    isPanelOpen = false;
    panel.classList.remove("nx-open");
    launcher.innerHTML = chatIcon;
    stopPolling();
  }

  launcher.addEventListener("click", function () {
    if (isPanelOpen) {
      closePanel();
    } else {
      openPanel();
    }
  });

  closeBtn.addEventListener("click", closePanel);

  sendBtn.addEventListener("click", function () {
    var text = input.value.trim();
    if (!text) return;
    sendMessage(text);
  });

  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      var text = input.value.trim();
      if (text) sendMessage(text);
    }
  });

  input.addEventListener("input", function () {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 80) + "px";
  });
})();
