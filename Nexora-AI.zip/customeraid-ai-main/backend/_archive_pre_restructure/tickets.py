from typing import Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.models.ticket import Ticket as TicketModel
from app.schemas.ticket import Ticket, TicketUpdate

router = APIRouter()

@router.get("", response_model=List[Ticket])
async def read_tickets(
    db: AsyncSession = Depends(get_db),
    status: Optional[str] = None,
    priority: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
) -> Any:
    stmt = select(TicketModel)
    if status:
        stmt = stmt.filter(TicketModel.status == status)
    if priority:
        stmt = stmt.filter(TicketModel.priority == priority)
    
    result = await db.execute(stmt.offset(skip).limit(limit))
    return result.scalars().all()

@router.patch("/{id}", response_model=Ticket)
async def update_ticket(
    id: str,
    ticket_in: TicketUpdate,
    db: AsyncSession = Depends(get_db),
) -> Any:
    result = await db.execute(select(TicketModel).filter(TicketModel.id == id))
    ticket = result.scalars().first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    update_data = ticket_in.dict(exclude_unset=True)
    for field in update_data:
        setattr(ticket, field, update_data[field])
    
    await db.commit()
    await db.refresh(ticket)
    return ticket

@router.post("/{id}/assign")
async def assign_ticket(
    id: str,
    assign_in: dict, # {"agentId": "..."}
    db: AsyncSession = Depends(get_db),
) -> Any:
    result = await db.execute(select(TicketModel).filter(TicketModel.id == id))
    ticket = result.scalars().first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    ticket.agent = assign_in.get("agentId")
    await db.commit()
    return {"ok": True}
