from sqlalchemy import Column, String, DateTime, Enum
from sqlalchemy.sql import func
import uuid
from app.db.base_class import Base

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(Enum("admin", "agent", name="user_role"), default="agent")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
