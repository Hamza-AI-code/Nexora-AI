from sqlalchemy import Column, String, DateTime, Enum, JSON
from sqlalchemy.sql import func
import uuid
from app.db.base_class import Base

class Ticket(Base):
    __tablename__ = "tickets"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    customer = Column(String, index=True)
    intent = Column(String)
    priority = Column(Enum("low", "medium", "high", name="priority_type"), default="medium")
    status = Column(Enum("open", "progress", "resolved", "escalated", name="ticket_status"), default="open")
    agent = Column(String)
    channel = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    type = Column(Enum("intent", "resolved", "escalation", "knowledge", name="activity_type"))
    payload = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
