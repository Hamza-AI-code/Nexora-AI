from sqlalchemy import Column, String, DateTime, Enum, Integer, ForeignKey, JSON
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import uuid
from app.db.base_class import Base

class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    customer = Column(String, index=True)
    channel = Column(Enum("whatsapp", "web", "voice", "facebook", "instagram", name="channel_type"), default="web")
    last_message = Column(String)
    unread = Column(Integer, default=0)
    takeover = Column(Enum("ai", "human", name="takeover_mode"), default="ai")
    sentiment = Column(Enum("positive", "neutral", "negative", name="sentiment_type"), default="neutral")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    messages = relationship("Message", back_populates="conversation")

class Message(Base):
    __tablename__ = "messages"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    conversation_id = Column(String, ForeignKey("conversations.id"))
    role = Column(Enum("user", "ai", "agent", name="message_role"))
    content = Column(String, nullable=False)
    sentiment = Column(Enum("positive", "neutral", "negative", name="sentiment_type"), default="neutral")
    metadata = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    conversation = relationship("Conversation", back_populates="messages")
