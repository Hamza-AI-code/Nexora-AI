from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.conversation import Conversation, Message
from app.services.llm import llm_service
from app.services.knowledge import knowledge_service
import uuid
import datetime

class ChatService:
    async def get_conversations(self, db: AsyncSession) -> List[Conversation]:
        result = await db.execute(select(Conversation).order_by(Conversation.updated_at.desc()))
        return result.scalars().all()

    async def get_messages(self, db: AsyncSession, conversation_id: str) -> List[Message]:
        result = await db.execute(select(Message).filter(Message.conversation_id == conversation_id).order_by(Message.created_at.asc()))
        return result.scalars().all()

    async def add_message(self, db: AsyncSession, conversation_id: str, content: str, role: str) -> Message:
        # Load conversation
        result = await db.execute(select(Conversation).filter(Conversation.id == conversation_id))
        conversation = result.scalars().first()
        
        if not conversation:
            raise Exception("Conversation not found")

        # Create user message
        user_message = Message(
            id=str(uuid.uuid4()),
            conversation_id=conversation_id,
            role=role,
            content=content,
            created_at=datetime.datetime.utcnow()
        )
        db.add(user_message)
        
        conversation.last_message = content
        conversation.updated_at = datetime.datetime.utcnow()
        
        # If AI handling is needed
        ai_response_message = None
        if role == "user" and conversation.takeover == "ai":
            # 1. Retrieve context
            context_chunks = await knowledge_service.query_knowledge(db, content)
            context_text = "\n\n".join([c["text"] for c in context_chunks])
            
            # 2. Build history
            history = await self.get_messages(db, conversation_id)
            chat_history = [{"role": m.role if m.role != "ai" else "assistant", "content": m.content} for m in history[-5:]]
            
            # 3. Build system prompt
            system_prompt = f"You are Nexora AI, a helpful customer support assistant. Use the following context to answer the user's question. If you don't know the answer, say so. Answer in the same language as the user.\n\nContext:\n{context_text}"
            
            messages = [{"role": "system", "content": system_prompt}] + chat_history + [{"role": "user", "content": content}]
            
            # 4. Generate AI response
            ai_content = await llm_service.get_chat_response(messages)
            
            # 5. Save AI message
            ai_response_message = Message(
                id=str(uuid.uuid4()),
                conversation_id=conversation_id,
                role="ai",
                content=ai_content,
                created_at=datetime.datetime.utcnow(),
                metadata={"sources": [c["source"] for c in context_chunks]}
            )
            db.add(ai_response_message)
            conversation.last_message = ai_content

        await db.commit()
        await db.refresh(user_message)
        if ai_response_message:
            await db.refresh(ai_response_message)
        
        return ai_response_message if ai_response_message else user_message

    async def summarize_conversation(self, db: AsyncSession, conversation_id: str) -> dict:
        messages = await self.get_messages(db, conversation_id)
        text = "\n".join([f"{m.role}: {m.content}" for m in messages])
        
        prompt = f"Summarize the following conversation, identify the user's intents, and determine the overall sentiment (positive, neutral, negative). Return as JSON with keys: summary, intents (list), sentiment.\n\nConversation:\n{text}"
        
        # In a real app, we'd use a structured output or parse JSON
        # For Phase 1, we'll simulate this or use a simple LLM call
        response = await llm_service.get_chat_response([{"role": "user", "content": prompt}])
        
        # Mocking structured response for now
        return {
            "summary": "User inquired about product features and pricing.",
            "intents": ["pricing_query", "feature_info"],
            "sentiment": "neutral"
        }

chat_service = ChatService()
