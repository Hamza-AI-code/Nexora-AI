from sqlalchemy import Column, String, DateTime, Float, Boolean, JSON
from sqlalchemy.sql import func
import uuid
from app.db.base_class import Base

class CompanySettings(Base):
    __tablename__ = "company_settings"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    name = Column(String)
    sector = Column(String)
    country = Column(String)
    timezone = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

class AISettings(Base):
    __tablename__ = "ai_settings"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    model = Column(String, default="gpt-4o")
    temperature = Column(Float, default=0.7)
    system_prompt = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

class Integration(Base):
    __tablename__ = "integrations"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    vendor = Column(String, unique=True)
    connected = Column(Boolean, default=False)
    credentials_metadata = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
