# Initial main.py for FastAPI application
# Nexora AI Backend

from fastapi import FastAPI, HTTPException
from sqlalchemy import text
from app.db.session import get_db

from app.api.api_v1.api import api_router

app = FastAPI(title="Nexora AI API")

app.include_router(api_router)

@app.get("/health")
async def health_check():
    return {"status": "ok"}

@app.get("/ready")
async def readiness_check():
    try:
        async with get_db() as db:
            await db.execute(text("SELECT 1"))
        return {"status": "ok", "database": "connected"}
    except Exception:
        raise HTTPException(status_code=500, detail="Database connection failed")
