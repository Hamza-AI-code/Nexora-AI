from typing import Any, List
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.schemas.dashboard import TicketVolumePoint, CostSavingsPoint

router = APIRouter()

@router.get("/ticket-volume", response_model=List[TicketVolumePoint])
async def get_ticket_volume(
    db: AsyncSession = Depends(get_db),
    range: str = "7d"
) -> Any:
    # Mocking for Phase 1
    return [
        {"day": "Mon", "total": 120, "ai": 100, "human": 20},
        {"day": "Tue", "total": 150, "ai": 130, "human": 20},
        {"day": "Wed", "total": 110, "ai": 95, "human": 15},
    ]

@router.get("/cost-savings", response_model=List[CostSavingsPoint])
async def get_cost_savings(
    db: AsyncSession = Depends(get_db),
    range: str = "6m"
) -> Any:
    # Mocking for Phase 1
    return [
        {"month": "Jan", "saved": 1200.0},
        {"month": "Feb", "saved": 1500.0},
        {"month": "Mar", "saved": 1800.0},
    ]
