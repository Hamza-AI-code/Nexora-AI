import asyncio
import datetime
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import SessionLocal
from app.models.user import User
from app.models.conversation import Conversation, Message
from app.models.knowledge import KnowledgeDocument, KnowledgeChunk
from app.models.settings import CompanySettings, AISettings, Integration
from app.models.ticket import Ticket, ActivityLog
from app.core.security import get_password_hash

async def seed_data():
    async with SessionLocal() as db:
        # Seed Users
        admin_user = User(
            id=str(uuid.uuid4()),
            name="Admin User",
            email="admin@nexora.ai",
            password_hash=get_password_hash("adminpass"),
            role="admin",
            created_at=datetime.datetime.utcnow()
        )
        agent_user = User(
            id=str(uuid.uuid4()),
            name="Agent User",
            email="agent@nexora.ai",
            password_hash=get_password_hash("agentpass"),
            role="agent",
            created_at=datetime.datetime.utcnow()
        )
        db.add(admin_user)
        db.add(agent_user)

        # Seed Company Settings
        company_settings = CompanySettings(
            id=str(uuid.uuid4()),
            name="Nexora Inc.",
            sector="AI SaaS",
            country="Morocco",
            timezone="Africa/Casablanca",
            created_at=datetime.datetime.utcnow()
        )
        db.add(company_settings)

        # Seed AI Settings
        ai_settings = AISettings(
            id=str(uuid.uuid4()),
            model="gpt-4o",
            temperature=0.7,
            system_prompt="You are Nexora AI, a helpful customer support assistant.",
            created_at=datetime.datetime.utcnow()
        )
        db.add(ai_settings)

        # Seed Integrations
        integration_openai = Integration(
            id=str(uuid.uuid4()),
            vendor="OpenAI",
            connected=True,
            credentials_metadata={"api_key_set": True},
            created_at=datetime.datetime.utcnow()
        )
        db.add(integration_openai)

        # Seed Knowledge Documents and Chunks
        doc1 = KnowledgeDocument(
            id=str(uuid.uuid4()),
            title="Nexora AI Product Features",
            source="manual",
            content="Nexora AI offers automated customer support, RAG capabilities, and multi-channel integration.",
            chunks=1,
            indexed_at=datetime.datetime.utcnow(),
            created_at=datetime.datetime.utcnow()
        )
        chunk1 = KnowledgeChunk(
            id=str(uuid.uuid4()),
            document_id=doc1.id,
            chunk_index=0,
            content="Nexora AI offers automated customer support, RAG capabilities, and multi-channel integration.",
            embedding=[0.1]*1536, # Mock embedding
            created_at=datetime.datetime.utcnow()
        )
        db.add(doc1)
        db.add(chunk1)

        # Seed Conversations and Messages
        conv1 = Conversation(
            id=str(uuid.uuid4()),
            customer="Alice Smith",
            channel="web",
            last_message="What are your pricing plans?",
            unread=1,
            takeover="ai",
            sentiment="neutral",
            created_at=datetime.datetime.utcnow(),
            updated_at=datetime.datetime.utcnow()
        )
        msg1_user = Message(
            id=str(uuid.uuid4()),
            conversation_id=conv1.id,
            role="user",
            content="Hello, I'm interested in your services.",
            created_at=datetime.datetime.utcnow()
        )
        msg1_ai = Message(
            id=str(uuid.uuid4()),
            conversation_id=conv1.id,
            role="ai",
            content="Welcome to Nexora AI! How can I assist you today?",
            created_at=datetime.datetime.utcnow()
        )
        msg1_user2 = Message(
            id=str(uuid.uuid4()),
            conversation_id=conv1.id,
            role="user",
            content="What are your pricing plans?",
            created_at=datetime.datetime.utcnow()
        )
        db.add(conv1)
        db.add(msg1_user)
        db.add(msg1_ai)
        db.add(msg1_user2)

        # Seed Tickets
        ticket1 = Ticket(
            id=str(uuid.uuid4()),
            customer="Alice Smith",
            intent="Pricing Inquiry",
            priority="high",
            status="open",
            agent="agent@nexora.ai",
            channel="web",
            created_at=datetime.datetime.utcnow()
        )
        db.add(ticket1)

        # Seed Activity Logs
        activity1 = ActivityLog(
            id=str(uuid.uuid4()),
            type="intent",
            payload={"conversation_id": conv1.id, "intent": "Pricing Inquiry"},
            created_at=datetime.datetime.utcnow()
        )
        db.add(activity1)

        await db.commit()
        print("Seed data added successfully!")

if __name__ == "__main__":
    asyncio.run(seed_data())
