from sqlalchemy import Column, String, DateTime, Enum, Integer, ForeignKey, JSON
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import uuid
from app.db.base_class import Base
from pgvector.sqlalchemy import Vector

class KnowledgeDocument(Base):
    __tablename__ = "knowledge_documents"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, index=True)
    source = Column(Enum("pdf", "url", "manual", name="source_type"))
    source_url = Column(String)
    storage_path = Column(String)
    chunks = Column(Integer, default=0)
    indexed_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    chunks_rel = relationship("KnowledgeChunk", back_populates="document", cascade="all, delete-orphan")

class KnowledgeChunk(Base):
    __tablename__ = "knowledge_chunks"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    document_id = Column(String, ForeignKey("knowledge_documents.id"))
    chunk_index = Column(Integer)
    content = Column(String, nullable=False)
    embedding = Column(Vector(1536))  # Assuming OpenAI embeddings
    metadata = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    document = relationship("KnowledgeDocument", back_populates="chunks_rel")
