from typing import List, Optional
import numpy as np
from openai import OpenAI
from app.core.config import settings

class LLMService:
    def __init__(self):
        self.client = None
        if settings.OPENAI_API_KEY:
            self.client = OpenAI(api_key=settings.OPENAI_API_KEY)

    async def get_embedding(self, text: str) -> List[float]:
        if not self.client:
            # Mock embedding for local development
            return [0.0] * 1536
        
        response = self.client.embeddings.create(
            input=text,
            model="text-embedding-3-small"
        )
        return response.data[0].embedding

    async def get_chat_response(self, messages: List[dict], model: str = "gpt-4o", temperature: float = 0.7) -> str:
        if not self.client:
            # Mock response for local development
            return "This is a mock response from Nexora AI. Please provide an OpenAI API key for real answers."
        
        response = self.client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature
        )
        return response.choices[0].message.content

llm_service = LLMService()
