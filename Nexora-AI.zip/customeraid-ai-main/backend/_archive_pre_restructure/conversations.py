from typing import Any, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.api import deps
from app.db.session import get_db
from app.models.conversation import Conversation as ConversationModel
from app.schemas.conversation import Conversation, Message, MessageCreate, SummarizeResponse
from app.services.chat import chat_service

router = APIRouter()

@router.get("", response_model=List[Conversation])
async def read_conversations(
    db: AsyncSession = Depends(get_db),
    skip: int = 0,
    limit: int = 100,
) -> Any:
    return await chat_service.get_conversations(db)

@router.get("/{id}/messages", response_model=List[Message])
async def read_messages(
    id: str,
    db: AsyncSession = Depends(get_db),
) -> Any:
    return await chat_service.get_messages(db, id)

@router.post("/{id}/messages", response_model=Message)
async def create_message(
    id: str,
    message_in: MessageCreate,
    db: AsyncSession = Depends(get_db),
) -> Any:
    role = message_in.as_role or "user"
    return await chat_service.add_message(db, id, message_in.content, role)

@router.post("/{id}/takeover")
async def takeover_conversation(
    id: str,
    mode: dict, # {"mode": "ai" | "human"}
    db: AsyncSession = Depends(get_db),
) -> Any:
    result = await db.execute(select(ConversationModel).filter(ConversationModel.id == id))
    conversation = result.scalars().first()
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    conversation.takeover = mode.get("mode", "ai")
    await db.commit()
    return {"ok": True}

@router.post("/{id}/summarize", response_model=SummarizeResponse)
async def summarize_conversation(
    id: str,
    db: AsyncSession = Depends(get_db),
) -> Any:
    return await chat_service.summarize_conversation(db, id)
