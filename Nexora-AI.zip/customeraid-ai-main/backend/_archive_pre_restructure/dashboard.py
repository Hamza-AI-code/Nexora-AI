from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class KPIs(BaseModel):
    conversations: int
    autoResolvedRate: float
    activeTickets: int
    avgResponseTime: float
    costSaved: float
    conversationsDelta: float
    resolvedDelta: float
    ticketsDelta: float
    responseDelta: float
    costDelta: float

class ActivityItem(BaseModel):
    id: str
    type: str
    text: str
    time: datetime
    channel: str

class TicketVolumePoint(BaseModel):
    day: str
    total: int
    ai: int
    human: int

class CostSavingsPoint(BaseModel):
    month: str
    saved: float
