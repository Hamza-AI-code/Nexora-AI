import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.security import get_password_hash
from app.models.user import User
import uuid
from sqlalchemy import select

@pytest.mark.asyncio
async def test_create_user(db_session: AsyncSession):
    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash("testpassword")
    user = User(
        id=user_id,
        name="Test User",
        email="test@example.com",
        password_hash=hashed_password,
        role="admin"
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    assert user.email == "test@example.com"

@pytest.mark.asyncio
async def test_login_success(client: AsyncClient, db_session: AsyncSession):
    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash("testpassword")
    user = User(
        id=user_id,
        name="Test User",
        email="test_login@example.com",
        password_hash=hashed_password,
        role="admin"
    )
    db_session.add(user)
    await db_session.commit()

    response = await client.post(
        "/v1/auth/login",
        json={
            "email": "test_login@example.com",
            "password": "testpassword"
        }
    )
    assert response.status_code == 200
    assert "token" in response.json()
    assert response.json()["user"]["email"] == "test_login@example.com"

@pytest.mark.asyncio
async def test_login_fail_wrong_password(client: AsyncClient, db_session: AsyncSession):
    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash("testpassword")
    user = User(
        id=user_id,
        name="Test User",
        email="test_wrong_pass@example.com",
        password_hash=hashed_password,
        role="admin"
    )
    db_session.add(user)
    await db_session.commit()

    response = await client.post(
        "/v1/auth/login",
        json={
            "email": "test_wrong_pass@example.com",
            "password": "wrongpassword"
        }
    )
    assert response.status_code == 400
    assert response.json()["detail"] == "Incorrect email or password"

@pytest.mark.asyncio
async def test_login_fail_user_not_found(client: AsyncClient):
    response = await client.post(
        "/v1/auth/login",
        json={
            "email": "nonexistent@example.com",
            "password": "password"
        }
    )
    assert response.status_code == 400
    assert response.json()["detail"] == "Incorrect email or password"

@pytest.mark.asyncio
async def test_get_me(client: AsyncClient, db_session: AsyncSession):
    user_id = str(uuid.uuid4())
    hashed_password = get_password_hash("testpassword")
    user = User(
        id=user_id,
        name="Test User",
        email="test_me@example.com",
        password_hash=hashed_password,
        role="admin"
    )
    db_session.add(user)
    await db_session.commit()

    login_response = await client.post(
        "/v1/auth/login",
        json={
            "email": "test_me@example.com",
            "password": "testpassword"
        }
    )
    token = login_response.json()["token"]

    response = await client.get(
        "/v1/auth/me",
        headers={
            "Authorization": f"Bearer {token}"
        }
    )
    assert response.status_code == 200
    assert response.json()["email"] == "test_me@example.com"

@pytest.mark.asyncio
async def test_get_me_unauthorized(client: AsyncClient):
    response = await client.get(
        "/v1/auth/me",
        headers={
            "Authorization": "Bearer invalid_token"
        }
    )
    assert response.status_code == 403
    assert response.json()["detail"] == "Could not validate credentials"
