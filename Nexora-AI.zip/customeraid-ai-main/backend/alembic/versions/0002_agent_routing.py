"""Agent presence + ticket assignment routing.

Revision ID: 0002_agent_routing
Revises: 0001_phase1_initial
Create Date: 2026-06-14
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "0002_agent_routing"
down_revision = "0001_phase1_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    presence_status = sa.Enum("online", "offline", name="presence_status")
    presence_status.create(op.get_bind(), checkfirst=True)

    op.add_column(
        "users",
        sa.Column("status", presence_status, nullable=False, server_default="offline"),
    )
    op.add_column(
        "tickets",
        sa.Column("agent_id", sa.String(), sa.ForeignKey("users.id"), nullable=True),
    )
    op.create_index("ix_tickets_agent_id", "tickets", ["agent_id"])


def downgrade() -> None:
    op.drop_index("ix_tickets_agent_id", table_name="tickets")
    op.drop_column("tickets", "agent_id")
    op.drop_column("users", "status")
    op.execute(sa.text("DROP TYPE IF EXISTS presence_status"))
