"""Phase 1 initial schema.

Revision ID: 0001_phase1_initial
Revises:
Create Date: 2026-06-13
"""

from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from pgvector.sqlalchemy import Vector


# revision identifiers, used by Alembic.
revision = "0001_phase1_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")

    user_role = sa.Enum("admin", "agent", name="user_role")
    channel_type = sa.Enum("whatsapp", "web", "voice", "facebook", "instagram", name="channel_type")
    takeover_mode = sa.Enum("ai", "human", name="takeover_mode")
    sentiment_type = sa.Enum("positive", "neutral", "negative", name="sentiment_type")
    message_role = sa.Enum("user", "ai", "agent", name="message_role")
    source_type = sa.Enum("pdf", "url", "manual", name="source_type")
    priority_type = sa.Enum("low", "medium", "high", name="priority_type")
    ticket_status = sa.Enum("open", "progress", "resolved", "escalated", name="ticket_status")
    activity_type = sa.Enum("intent", "resolved", "escalation", "knowledge", name="activity_type")
    message_sentiment = sa.Enum("positive", "neutral", "negative", name="message_sentiment")

    op.create_table(
        "users",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("email", sa.String(), nullable=False, unique=True, index=True),
        sa.Column("password_hash", sa.String(), nullable=False),
        sa.Column("role", user_role, nullable=False, server_default="agent"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )

    op.create_table(
        "conversations",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("customer", sa.String(), nullable=False, index=True),
        sa.Column("channel", channel_type, nullable=False, server_default="web"),
        sa.Column("last_message", sa.Text(), nullable=True),
        sa.Column("unread", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("takeover", takeover_mode, nullable=False, server_default="ai"),
        sa.Column("sentiment", sentiment_type, nullable=False, server_default="neutral"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "knowledge_documents",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("title", sa.String(), nullable=False, index=True),
        sa.Column("source", source_type, nullable=False),
        sa.Column("source_url", sa.String(), nullable=True),
        sa.Column("storage_path", sa.String(), nullable=True),
        sa.Column("content", sa.Text(), nullable=True),
        sa.Column("chunks", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("indexed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "company_settings",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("sector", sa.String(), nullable=False),
        sa.Column("country", sa.String(), nullable=False),
        sa.Column("timezone", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "ai_settings",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("model", sa.String(), nullable=False, server_default="gpt-4o-mini"),
        sa.Column("temperature", sa.Float(), nullable=False, server_default="0.3"),
        sa.Column("system_prompt", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "integrations",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("vendor", sa.String(), nullable=False, unique=True, index=True),
        sa.Column("connected", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("credentials_metadata", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "tickets",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("customer", sa.String(), nullable=False, index=True),
        sa.Column("intent", sa.String(), nullable=False),
        sa.Column("priority", priority_type, nullable=False, server_default="medium"),
        sa.Column("status", ticket_status, nullable=False, server_default="open"),
        sa.Column("agent", sa.String(), nullable=False, server_default="Unassigned"),
        sa.Column("channel", sa.String(), nullable=False),
        sa.Column("conversation_id", sa.String(), nullable=True, index=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "activity_logs",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("type", activity_type, nullable=False),
        sa.Column("payload", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )

    op.create_table(
        "messages",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("conversation_id", sa.String(), sa.ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("role", message_role, nullable=False),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("sentiment", message_sentiment, nullable=False, server_default="neutral"),
        sa.Column("metadata", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )

    op.create_table(
        "knowledge_chunks",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("document_id", sa.String(), sa.ForeignKey("knowledge_documents.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("chunk_index", sa.Integer(), nullable=False),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("embedding", Vector(1536), nullable=False),
        sa.Column("metadata", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("knowledge_chunks")
    op.drop_table("messages")
    op.drop_table("activity_logs")
    op.drop_table("tickets")
    op.drop_table("integrations")
    op.drop_table("ai_settings")
    op.drop_table("company_settings")
    op.drop_table("knowledge_documents")
    op.drop_table("conversations")
    op.drop_table("users")

    for type_name in [
        "message_sentiment",
        "activity_type",
        "ticket_status",
        "priority_type",
        "source_type",
        "message_role",
        "sentiment_type",
        "takeover_mode",
        "channel_type",
        "user_role",
    ]:
        op.execute(sa.text(f"DROP TYPE IF EXISTS {type_name}"))
