from __future__ import annotations

import os

# Tests rely on the mock LLM provider, regardless of any OPENAI_API_KEY configured
# in the developer's .env for running the app itself.
os.environ["OPENAI_API_KEY"] = ""

import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from app.core.config import settings
from app.db.base import Base
from app.db.session import get_db
from app.main import app

# Tests run against a dedicated database so drop_all/create_all never touches
# the developer's dev/seed data living in the main DATABASE_URL database.
_base_url, _, _db_name = settings.DATABASE_URL.rpartition("/")
TEST_DATABASE_URL = f"{_base_url}/{_db_name}_test"


@pytest_asyncio.fixture(scope="function")
async def db_session() -> AsyncSession:
    admin_engine = create_async_engine(_base_url + "/postgres", isolation_level="AUTOCOMMIT")
    async with admin_engine.connect() as conn:
        exists = await conn.scalar(text("SELECT 1 FROM pg_database WHERE datname = :name"), {"name": f"{_db_name}_test"})
        if not exists:
            await conn.execute(text(f'CREATE DATABASE "{_db_name}_test"'))
    await admin_engine.dispose()

    engine = create_async_engine(TEST_DATABASE_URL, echo=False, poolclass=NullPool)

    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)

    async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    async with async_session() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)

    await engine.dispose()


@pytest_asyncio.fixture(scope="function")
async def client(db_session: AsyncSession):
    async def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client
    app.dependency_overrides.clear()
