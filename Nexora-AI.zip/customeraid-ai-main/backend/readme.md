# Nexora AI Backend - Phase 1

This repository contains the backend for Nexora AI, a B2B AI call-center automation SaaS. This is Phase 1 of the product roadmap, focusing on a minimal but functional intelligence loop.

## Features

- Web chat and conversation persistence
- RAG (Retrieval Augmented Generation) for AI answer generation
- Basic knowledge base ingestion (PDF, text, markdown, simple URLs)
- JWT authentication with admin/agent roles
- Stable REST API
- Minimal dashboard, analytics, tickets, and settings endpoints
- Seed/demo data for immediate use
- Health and readiness checks

## Technology Stack

- Python 3.11+
- FastAPI
- PostgreSQL with pgvector extension
- SQLAlchemy 2.x
- Alembic for database migrations
- OpenAI API for chat and embeddings (with mock provider for local dev/tests)
- Pydantic for data validation and settings
- pytest for testing
- Docker and Docker Compose for containerization

## Repository Layout

```
backend/
	app/
		main.py
		core/             # Core application logic, configuration, utilities
		api/              # API routers and endpoint definitions
		db/               # Database session management, engine
		models/           # SQLAlchemy ORM models
		schemas/          # Pydantic schemas for request/response validation
		services/         # Business logic and complex operations
		repositories/     # Database interaction logic
		utils/            # Helper functions and common utilities
		seeds/            # Seed data for initial setup
	tests/            # Unit and integration tests
	alembic/          # Alembic migration scripts
	storage/          # Local storage for uploaded knowledge documents
	Dockerfile
	docker-compose.yml
	.env.example
	README.md
```

## Setup and Local Development

### Prerequisites

- Docker and Docker Compose
- Python 3.11+

### 1. Clone the repository

```bash
git clone <your-repo-url>
cd backend
```

### 2. Environment Variables

Copy the example environment file and fill in your details:

```bash
cp .env.example .env
```

Edit the `.env` file and provide values for:

- `DATABASE_URL`: PostgreSQL connection string (already configured for Docker Compose)
- `OPENAI_API_KEY`: Your OpenAI API key. If not provided, a mock provider will be used for local development and testing.
- `SECRET_KEY`: A strong secret key for JWT token generation.

### 3. Run with Docker Compose

Build and start the services:

```bash
docker-compose up --build -d
```

This will:
- Start a PostgreSQL database with `pgvector`.
- Build the backend application image.
- Start the FastAPI application.

### 4. Database Migrations

Once the services are up, you'll need to apply database migrations. You can exec into the backend container to run Alembic commands:

```bash
docker-compose exec backend alembic upgrade head
```

### 5. Seed Data

To populate the database with demo data, run the seed script:

```bash
docker-compose exec backend python -m app.seeds.run_seeds
```

(Note: The seed script `app.seeds.run_seeds` will be created in a later step.)

### 6. Access the API

The API will be available at `http://localhost:8000`.

You-can-access-the-API-documentation-at-`http://localhost:8000/docs`-(Swagger-UI)-or-`http://localhost:8000/redoc`-(ReDoc).

## Running Tests

To run tests, you can exec into the backend container:

```bash
docker-compose exec backend pytest
```

(Note: Tests will be implemented in a later step.)

## Linting and Formatting

(To be added later)

## Contributing

(To be added later)

## License

(To be added later)
