import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.knowledge import KnowledgeDocument, KnowledgeChunk
from app.services.llm import llm_service
from sqlalchemy import select

@pytest.mark.asyncio
async def test_ingest_document(client: AsyncClient, db_session: AsyncSession):
    # Ensure mock embedding is used
    assert llm_service.client is None

    response = await client.post(
        "/v1/knowledge/documents",
        data={
            "title": "Test Document",
            "source": "manual",
            "content": "This is a test document content for ingestion."
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Test Document"
    assert data["chunks"] == 1

    # Verify document and chunk in DB
    doc = await db_session.get(KnowledgeDocument, data["id"])
    assert doc is not None
    assert doc.title == "Test Document"

    chunks_result = await db_session.execute(select(KnowledgeChunk).where(KnowledgeChunk.document_id == doc.id))
    chunks = list(chunks_result.scalars().all())
    assert len(chunks) == 1
    assert chunks[0].content == "This is a test document content for ingestion."
    assert len(chunks[0].embedding) == 1536 # Check if mock embedding is applied

@pytest.mark.asyncio
async def test_query_knowledge(client: AsyncClient, db_session: AsyncSession):
    # Ingest a document first
    await client.post(
        "/v1/knowledge/documents",
        data={
            "title": "Query Test Doc",
            "source": "manual",
            "content": "This document talks about Nexora AI features and benefits."
        }
    )

    response = await client.post(
        "/v1/knowledge/query",
        json={
            "query": "What are the features of Nexora AI?"
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert "chunks" in data
    assert len(data["chunks"]) > 0
    assert data["chunks"][0]["source"] == "Query Test Doc"
    assert "Nexora AI features" in data["chunks"][0]["text"]

@pytest.mark.asyncio
async def test_delete_document(client: AsyncClient, db_session: AsyncSession):
    # Ingest a document to delete
    response_create = await client.post(
        "/v1/knowledge/documents",
        data={
            "title": "Document to Delete",
            "source": "manual",
            "content": "This document will be deleted."
        }
    )
    doc_id = response_create.json()["id"]

    response_delete = await client.delete(f"/v1/knowledge/documents/{doc_id}")
    assert response_delete.status_code == 200
    assert response_delete.json() == {"ok": True}

    # Verify document is deleted from DB
    doc = await db_session.get(KnowledgeDocument, doc_id)
    assert doc is None

    # Verify chunks are also deleted (cascade)
    chunks_result = await db_session.execute(select(KnowledgeChunk).where(KnowledgeChunk.document_id == doc_id))
    chunks = list(chunks_result.scalars().all())
    assert len(chunks) == 0
