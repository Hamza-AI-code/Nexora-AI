"""Pydantic schemas for Nexora AI API contracts."""
