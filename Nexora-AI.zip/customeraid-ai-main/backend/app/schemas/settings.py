from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class CompanySettings(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    name: str
    sector: str
    country: str
    timezone: str


class CompanySettingsUpdate(BaseModel):
    name: str | None = None
    sector: str | None = None
    country: str | None = None
    timezone: str | None = None


class AISettings(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    model: str
    temperature: float
    system_prompt: str = Field(alias="systemPrompt")


class AISettingsUpdate(BaseModel):
    model: str | None = None
    temperature: float | None = None
    systemPrompt: str | None = None


class IntegrationSummary(BaseModel):
    id: str
    name: str
    connected: bool


class IntegrationConnectRequest(BaseModel):
    credentials: dict | None = None
