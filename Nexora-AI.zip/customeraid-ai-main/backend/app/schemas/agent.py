from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class AgentProfile(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    email: str
    role: str
    status: Literal["online", "offline"]
    resolved_count: int = Field(alias="resolvedCount")
    open_count: int = Field(alias="openCount")
    escalated_count: int = Field(alias="escalatedCount")
