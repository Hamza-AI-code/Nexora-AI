from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class Conversation(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: str
    customer: str
    channel: str
    last_message: str | None = Field(default=None, alias="lastMessage")
    unread: int
    takeover: Literal["ai", "human"]
    sentiment: Literal["positive", "neutral", "negative"]


class Message(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: str
    conversation_id: str = Field(alias="conversationId")
    role: Literal["user", "ai", "agent"]
    content: str
    created_at: datetime = Field(alias="createdAt")
    sentiment: Literal["positive", "neutral", "negative"] | None = None


class MessageCreate(BaseModel):
    content: str
    as_role: Literal["user", "ai", "agent"] = Field(default="agent", alias="as")

    model_config = ConfigDict(populate_by_name=True)


class TakeoverRequest(BaseModel):
    mode: Literal["ai", "human"]


class SummarizeResponse(BaseModel):
    summary: str
    intents: list[str]
    sentiment: Literal["positive", "neutral", "negative"]
