from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, EmailStr


class User(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    email: EmailStr
    role: str
    status: Literal["online", "offline"]


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserStatusUpdate(BaseModel):
    status: Literal["online", "offline"]


class AuthSession(BaseModel):
    token: str
    user: User


class TokenPayload(BaseModel):
    sub: str
    exp: int | None = None
