from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, model_validator


class KnowledgeDoc(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: str
    title: str
    source: str
    chunks: int
    updated_at: datetime = Field(alias="updatedAt")

    @model_validator(mode="before")
    @classmethod
    def _default_updated_at(cls, data: object) -> object:
        if hasattr(data, "updated_at") and getattr(data, "updated_at", None) is None:
            return {
                "id": data.id,
                "title": data.title,
                "source": data.source,
                "chunks": data.chunks,
                "updatedAt": getattr(data, "indexed_at", None) or data.created_at,
            }
        return data


class KnowledgeDocumentCreate(BaseModel):
    title: str | None = None
    source: str = "manual"
    content: str | None = None
    source_url: str | None = None


class KnowledgeReindexRequest(BaseModel):
    document_id: str | None = Field(default=None, alias="documentId")

    model_config = ConfigDict(populate_by_name=True)


class KnowledgeQueryRequest(BaseModel):
    query: str


class KnowledgeChunkResult(BaseModel):
    text: str
    score: float
    source: str


class KnowledgeQueryResponse(BaseModel):
    chunks: list[KnowledgeChunkResult]
