from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class KPIs(BaseModel):
    conversations: int
    autoResolvedRate: float
    activeTickets: int
    avgResponseTime: float
    costSaved: float
    conversationsDelta: float
    resolvedDelta: float
    ticketsDelta: float
    responseDelta: float
    costDelta: float


class ActivityItem(BaseModel):
    id: str | int
    type: str
    text: str
    time: str
    channel: str


class TicketVolumePoint(BaseModel):
    day: str
    total: int
    ai: int
    human: int


class CostSavingsPoint(BaseModel):
    month: str
    saved: float
