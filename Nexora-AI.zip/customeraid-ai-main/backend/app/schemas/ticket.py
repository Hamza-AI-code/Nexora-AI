from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class Ticket(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: str
    customer: str
    intent: str
    priority: Literal["low", "medium", "high"]
    status: Literal["open", "progress", "resolved", "escalated"]
    agent: str
    agent_id: str | None = Field(default=None, alias="agentId")
    channel: str
    conversation_id: str | None = Field(default=None, alias="conversationId")


class TicketUpdate(BaseModel):
    customer: str | None = None
    intent: str | None = None
    priority: Literal["low", "medium", "high"] | None = None
    status: Literal["open", "progress", "resolved", "escalated"] | None = None
    agent: str | None = None
    agent_id: str | None = Field(default=None, alias="agentId")
    channel: str | None = None

    model_config = ConfigDict(populate_by_name=True)


class TicketAssignRequest(BaseModel):
    agent_id: str = Field(alias="agentId")
