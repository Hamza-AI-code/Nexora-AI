from app.db.base_class import Base
from app.models.user import User
from app.models.conversation import Conversation, Message
from app.models.knowledge import KnowledgeDocument, KnowledgeChunk
from app.models.settings import CompanySettings, AISettings, Integration
from app.models.ticket import Ticket, ActivityLog
