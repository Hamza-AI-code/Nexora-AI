"""API layer and dependency helpers."""
