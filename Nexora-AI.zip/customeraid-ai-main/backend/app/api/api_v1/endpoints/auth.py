from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api import deps
from app.core.config import settings
from app.core.security import create_access_token, verify_password
from app.db.session import get_db
from app.models.user import User as UserModel
from app.schemas.user import AuthSession, LoginRequest, User


router = APIRouter()


@router.post("/login", response_model=AuthSession)
async def login(payload: LoginRequest, db: AsyncSession = Depends(get_db)) -> AuthSession:
    result = await db.execute(select(UserModel).where(UserModel.email == payload.email))
    user = result.scalars().first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Incorrect email or password")

    token = create_access_token(user.id, expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    return AuthSession(token=token, user=User.model_validate(user))


@router.get("/me", response_model=User)
async def me(current_user: UserModel = Depends(deps.get_current_user)) -> UserModel:
    return current_user


@router.post("/logout")
async def logout() -> dict[str, bool]:
    return {"ok": True}
