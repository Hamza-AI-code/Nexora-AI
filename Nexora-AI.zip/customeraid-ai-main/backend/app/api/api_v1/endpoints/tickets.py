from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.models.ticket import Ticket as TicketModel
from app.schemas.ticket import Ticket, TicketAssignRequest, TicketUpdate


router = APIRouter()


@router.get("", response_model=List[Ticket])
async def read_tickets(
    db: AsyncSession = Depends(get_db),
    status_filter: str | None = Query(default=None, alias="status"),
    priority: str | None = None,
) -> List[Ticket]:
    stmt = select(TicketModel)
    if status_filter:
        stmt = stmt.where(TicketModel.status == status_filter)
    if priority:
        stmt = stmt.where(TicketModel.priority == priority)
    result = await db.execute(stmt.order_by(TicketModel.created_at.desc()))
    return list(result.scalars().all())


@router.patch("/{ticket_id}", response_model=Ticket)
async def update_ticket(ticket_id: str, ticket_in: TicketUpdate, db: AsyncSession = Depends(get_db)) -> TicketModel:
    ticket = await db.get(TicketModel, ticket_id)
    if not ticket:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket not found")

    for field, value in ticket_in.model_dump(exclude_unset=True).items():
        setattr(ticket, field, value)
    await db.commit()
    await db.refresh(ticket)
    return ticket


@router.post("/{ticket_id}/assign")
async def assign_ticket(ticket_id: str, payload: TicketAssignRequest, db: AsyncSession = Depends(get_db)) -> dict[str, bool]:
    ticket = await db.get(TicketModel, ticket_id)
    if not ticket:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket not found")

    ticket.agent = payload.agent_id
    await db.commit()
    return {"ok": True}
