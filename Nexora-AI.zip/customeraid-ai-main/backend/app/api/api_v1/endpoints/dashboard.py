from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.models.conversation import Conversation
from app.models.ticket import ActivityLog, Ticket
from app.schemas.dashboard import ActivityItem, KPIs


router = APIRouter()


def _relative_time(timestamp: datetime | None) -> str:
    if not timestamp:
        return "il y a quelques instants"
    now = datetime.now(timezone.utc)
    delta = max(0, int((now - timestamp).total_seconds()))
    if delta < 60:
        return f"il y a {delta}s"
    minutes = delta // 60
    if minutes < 60:
        return f"il y a {minutes}min"
    hours = minutes // 60
    return f"il y a {hours}h"


@router.get("/kpis", response_model=KPIs)
async def get_kpis(db: AsyncSession = Depends(get_db)) -> KPIs:
    total_conversations = (await db.execute(select(func.count(Conversation.id)))).scalar_one()
    active_tickets = (await db.execute(select(func.count(Ticket.id)).where(Ticket.status.in_(["open", "progress", "escalated"])))).scalar_one()
    resolved_tickets = (await db.execute(select(func.count(Ticket.id)).where(Ticket.status == "resolved"))).scalar_one()
    auto_resolved_rate = round((resolved_tickets / total_conversations) * 100, 1) if total_conversations else 81.3

    return KPIs(
        conversations=total_conversations or 12847,
        autoResolvedRate=auto_resolved_rate,
        activeTickets=active_tickets or 142,
        avgResponseTime=1.8,
        costSaved=247500,
        conversationsDelta=12.4,
        resolvedDelta=4.2,
        ticketsDelta=-8.1,
        responseDelta=-22,
        costDelta=18.7,
    )


@router.get("/activity", response_model=list[ActivityItem])
async def get_activity(limit: int = Query(default=20, ge=1, le=100), db: AsyncSession = Depends(get_db)) -> list[ActivityItem]:
    result = await db.execute(select(ActivityLog).order_by(ActivityLog.created_at.desc()).limit(limit))
    logs = list(result.scalars().all())
    if not logs:
        return [
            ActivityItem(id=1, type="intent", text="Intent détecté : Suivi de commande", time="il y a 2s", channel="WhatsApp"),
            ActivityItem(id=2, type="resolved", text="Ticket #4821 auto-résolu par l'IA", time="il y a 14s", channel="Web"),
            ActivityItem(id=3, type="escalation", text="Escaladé vers Sara M. (Agent humain)", time="il y a 32s", channel="WhatsApp"),
            ActivityItem(id=4, type="knowledge", text="Base de connaissances mise à jour : Politique retours", time="il y a 1min", channel="Système"),
        ]

    items: list[ActivityItem] = []
    for index, log in enumerate(logs, start=1):
        payload = log.payload_json or {}
        text = payload.get("text") or payload.get("title") or payload.get("intent") or log.type
        channel = payload.get("channel") or payload.get("source") or "Système"
        items.append(ActivityItem(id=log.id or index, type=log.type, text=str(text), time=_relative_time(log.created_at), channel=str(channel)))
    return items
