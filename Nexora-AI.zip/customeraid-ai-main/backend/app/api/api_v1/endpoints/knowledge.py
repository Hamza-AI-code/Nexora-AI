from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.session import get_db
from app.schemas.knowledge import KnowledgeChunkResult, KnowledgeDoc, KnowledgeDocumentCreate, KnowledgeQueryRequest, KnowledgeQueryResponse, KnowledgeReindexRequest
from app.services.knowledge import knowledge_service


router = APIRouter()


@router.get("/documents", response_model=list[KnowledgeDoc])
async def list_documents(db: AsyncSession = Depends(get_db)) -> list[KnowledgeDoc]:
    documents = await knowledge_service.list_documents(db)
    return [KnowledgeDoc.model_validate(document) for document in documents]


@router.post("/documents", response_model=KnowledgeDoc)
async def upload_document(
    db: AsyncSession = Depends(get_db),
    file: UploadFile | None = File(default=None),
    title: str | None = Form(default=None),
    source: str = Form(default="manual"),
    content: str | None = Form(default=None),
    source_url: str | None = Form(default=None),
) -> KnowledgeDoc:
    upload_dir = Path(settings.UPLOAD_DIR)
    upload_dir.mkdir(parents=True, exist_ok=True)

    storage_path: str | None = None
    if file is not None:
        safe_name = file.filename or "upload"
        storage_path = str(upload_dir / safe_name)
        with open(storage_path, "wb") as buffer:
            buffer.write(await file.read())
        if title is None:
            title = safe_name

    document = await knowledge_service.ingest_document(
        db,
        title=title or source_url or "Untitled document",
        source=source,
        content=content,
        source_url=source_url,
        storage_path=storage_path,
    )
    return KnowledgeDoc.model_validate(document)


@router.delete("/documents/{document_id}")
async def delete_document(document_id: str, db: AsyncSession = Depends(get_db)) -> dict[str, bool]:
    deleted = await knowledge_service.delete_document(db, document_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    return {"ok": True}


@router.post("/query", response_model=KnowledgeQueryResponse)
async def query_knowledge(payload: KnowledgeQueryRequest, db: AsyncSession = Depends(get_db)) -> KnowledgeQueryResponse:
    chunks = await knowledge_service.query_knowledge(db, payload.query)
    return KnowledgeQueryResponse(chunks=[KnowledgeChunkResult(**chunk) for chunk in chunks])


@router.post("/reindex")
async def reindex_knowledge(payload: KnowledgeReindexRequest | None = None, db: AsyncSession = Depends(get_db)) -> dict[str, int | bool]:
    reindexed = await knowledge_service.reindex_document(db, payload.document_id if payload else None)
    return {"ok": True, "reindexed": reindexed}
