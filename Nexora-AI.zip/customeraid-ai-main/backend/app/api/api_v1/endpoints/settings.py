from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.session import get_db
from app.models.settings import AISettings as AISettingsModel, CompanySettings as CompanySettingsModel, Integration as IntegrationModel
from app.schemas.settings import AISettings, AISettingsUpdate, CompanySettings, CompanySettingsUpdate, IntegrationConnectRequest, IntegrationSummary


router = APIRouter()


async def _get_or_create_company(db: AsyncSession) -> CompanySettingsModel:
    result = await db.execute(select(CompanySettingsModel).limit(1))
    company = result.scalars().first()
    if company:
        return company
    company = CompanySettingsModel(name="Nexora AI Demo", sector="E-commerce", country="Maroc", timezone="Africa/Casablanca")
    db.add(company)
    await db.commit()
    await db.refresh(company)
    return company


async def _get_or_create_ai(db: AsyncSession) -> AISettingsModel:
    result = await db.execute(select(AISettingsModel).limit(1))
    ai_settings = result.scalars().first()
    if ai_settings:
        return ai_settings
    ai_settings = AISettingsModel(model=settings.OPENAI_CHAT_MODEL, temperature=0.3, system_prompt="Tu es l'assistant IA de Nexora.")
    db.add(ai_settings)
    await db.commit()
    await db.refresh(ai_settings)
    return ai_settings


async def _get_or_create_integrations(db: AsyncSession) -> list[IntegrationModel]:
    result = await db.execute(select(IntegrationModel).order_by(IntegrationModel.vendor.asc()))
    integrations = list(result.scalars().all())
    if integrations:
        return integrations
    defaults = [
        IntegrationModel(vendor="whatsapp", connected=True, credentials_metadata_json={"enabled": True}),
        IntegrationModel(vendor="hubspot", connected=True, credentials_metadata_json={"enabled": True}),
        IntegrationModel(vendor="salesforce", connected=False, credentials_metadata_json={"enabled": False}),
    ]
    db.add_all(defaults)
    await db.commit()
    return defaults


@router.get("/company", response_model=CompanySettings)
async def get_company_settings(db: AsyncSession = Depends(get_db)) -> CompanySettings:
    company = await _get_or_create_company(db)
    return CompanySettings.model_validate(company)


@router.patch("/company", response_model=CompanySettings)
async def update_company_settings(payload: CompanySettingsUpdate, db: AsyncSession = Depends(get_db)) -> CompanySettings:
    company = await _get_or_create_company(db)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(company, field, value)
    await db.commit()
    await db.refresh(company)
    return CompanySettings.model_validate(company)


@router.get("/ai", response_model=AISettings)
async def get_ai_settings(db: AsyncSession = Depends(get_db)) -> AISettings:
    ai_settings = await _get_or_create_ai(db)
    return AISettings.model_validate(ai_settings)


@router.patch("/ai", response_model=AISettings)
async def update_ai_settings(payload: AISettingsUpdate, db: AsyncSession = Depends(get_db)) -> AISettings:
    ai_settings = await _get_or_create_ai(db)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(ai_settings, field, value)
    await db.commit()
    await db.refresh(ai_settings)
    return AISettings.model_validate(ai_settings)


@router.get("/integrations", response_model=list[IntegrationSummary])
async def list_integrations(db: AsyncSession = Depends(get_db)) -> list[IntegrationSummary]:
    integrations = await _get_or_create_integrations(db)
    return [IntegrationSummary(id=integration.id, name=integration.vendor.title(), connected=integration.connected) for integration in integrations]


@router.post("/integrations/{integration_id}/connect")
async def connect_integration(integration_id: str, payload: IntegrationConnectRequest, db: AsyncSession = Depends(get_db)) -> dict[str, bool]:
    integration = await db.get(IntegrationModel, integration_id)
    if not integration:
        result = await db.execute(select(IntegrationModel).where(IntegrationModel.vendor == integration_id))
        integration = result.scalars().first()
    if not integration:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Integration not found")

    integration.connected = True
    integration.credentials_metadata_json = payload.credentials or {"connected": True}
    await db.commit()
    return {"ok": True}
