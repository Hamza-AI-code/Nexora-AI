from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.models.conversation import Conversation as ConversationModel
from app.schemas.conversation import Conversation, Message, MessageCreate, SummarizeResponse, TakeoverRequest
from app.services.chat import chat_service


router = APIRouter()


def _to_conversation_schema(conversation: ConversationModel) -> Conversation:
    return Conversation.model_validate(conversation)


def _to_message_schema(message) -> Message:
    return Message.model_validate(message)


@router.get("", response_model=List[Conversation])
async def read_conversations(db: AsyncSession = Depends(get_db)) -> List[Conversation]:
    conversations = await chat_service.get_conversations(db)
    return [_to_conversation_schema(conversation) for conversation in conversations]


@router.get("/{conversation_id}/messages", response_model=List[Message])
async def read_messages(conversation_id: str, db: AsyncSession = Depends(get_db)) -> List[Message]:
    messages = await chat_service.get_messages(db, conversation_id)
    return [_to_message_schema(message) for message in messages]


@router.post("/{conversation_id}/messages", response_model=Message)
async def create_message(conversation_id: str, message_in: MessageCreate, db: AsyncSession = Depends(get_db)) -> Message:
    return _to_message_schema(await chat_service.add_message(db, conversation_id, message_in.content, message_in.as_role))


@router.post("/{conversation_id}/takeover")
async def takeover_conversation(conversation_id: str, payload: TakeoverRequest, db: AsyncSession = Depends(get_db)) -> dict[str, bool]:
    result = await db.execute(select(ConversationModel).where(ConversationModel.id == conversation_id))
    conversation = result.scalars().first()
    if not conversation:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Conversation not found")

    conversation.takeover = payload.mode
    await db.commit()
    return {"ok": True}


@router.post("/{conversation_id}/summarize", response_model=SummarizeResponse)
async def summarize_conversation(conversation_id: str, db: AsyncSession = Depends(get_db)) -> SummarizeResponse:
    return SummarizeResponse(**(await chat_service.summarize_conversation(db, conversation_id)))
