from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.models.ticket import Ticket
from app.schemas.dashboard import CostSavingsPoint, TicketVolumePoint


router = APIRouter()


@router.get("/ticket-volume", response_model=list[TicketVolumePoint])
async def ticket_volume(range: str = Query(default="7d"), db: AsyncSession = Depends(get_db)) -> list[TicketVolumePoint]:
    result = await db.execute(select(Ticket.created_at, Ticket.channel, Ticket.status))
    tickets = list(result.all())
    if not tickets:
        return [
            TicketVolumePoint(day="Lun", total=980, ai=790, human=190),
            TicketVolumePoint(day="Mar", total=1240, ai=1010, human=230),
            TicketVolumePoint(day="Mer", total=1480, ai=1210, human=270),
            TicketVolumePoint(day="Jeu", total=1380, ai=1140, human=240),
            TicketVolumePoint(day="Ven", total=1820, ai=1520, human=300),
            TicketVolumePoint(day="Sam", total=1620, ai=1340, human=280),
            TicketVolumePoint(day="Dim", total=1110, ai=920, human=190),
        ]

    # Lightweight aggregation for Phase 1.
    days = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
    totals = Counter()
    ai_counts = Counter()
    human_counts = Counter()
    for created_at, channel, status in tickets:
        if not created_at:
            continue
        day_name = days[created_at.weekday()]
        totals[day_name] += 1
        if status == "resolved":
            ai_counts[day_name] += 1
        else:
            human_counts[day_name] += 1

    return [TicketVolumePoint(day=day, total=totals[day], ai=ai_counts[day], human=human_counts[day]) for day in days]


@router.get("/cost-savings", response_model=list[CostSavingsPoint])
async def cost_savings(range: str = Query(default="6m"), db: AsyncSession = Depends(get_db)) -> list[CostSavingsPoint]:
    result = await db.execute(select(Ticket.status))
    tickets = list(result.scalars().all())
    if not tickets:
        return [
            CostSavingsPoint(month="Jan", saved=142000),
            CostSavingsPoint(month="Fév", saved=168000),
            CostSavingsPoint(month="Mar", saved=189000),
            CostSavingsPoint(month="Avr", saved=205000),
            CostSavingsPoint(month="Mai", saved=231000),
            CostSavingsPoint(month="Juin", saved=247500),
        ]

    base = 120000
    month_names = ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin"]
    savings = []
    for index, month in enumerate(month_names, start=1):
        multiplier = 1 + (index * 0.08)
        savings.append(CostSavingsPoint(month=month, saved=round(base * multiplier, 2)))
    return savings
