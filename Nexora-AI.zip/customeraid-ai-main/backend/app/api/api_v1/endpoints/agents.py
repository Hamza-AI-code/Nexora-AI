from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api import deps
from app.db.session import get_db
from app.models.ticket import Ticket as TicketModel
from app.models.user import User as UserModel
from app.schemas.agent import AgentProfile
from app.schemas.ticket import Ticket
from app.schemas.user import User, UserStatusUpdate


router = APIRouter()


async def _agent_profile(db: AsyncSession, user: UserModel) -> AgentProfile:
    resolved_count = (
        await db.execute(
            select(func.count()).select_from(TicketModel).where(TicketModel.agent_id == user.id, TicketModel.status == "resolved")
        )
    ).scalar() or 0
    open_count = (
        await db.execute(
            select(func.count())
            .select_from(TicketModel)
            .where(TicketModel.agent_id == user.id, TicketModel.status.in_(["open", "progress"]))
        )
    ).scalar() or 0
    escalated_count = (
        await db.execute(
            select(func.count()).select_from(TicketModel).where(TicketModel.agent_id == user.id, TicketModel.status == "escalated")
        )
    ).scalar() or 0

    return AgentProfile(
        id=user.id,
        name=user.name,
        email=user.email,
        role=user.role,
        status=user.status,
        resolvedCount=resolved_count,
        openCount=open_count,
        escalatedCount=escalated_count,
    )


@router.get("/me", response_model=AgentProfile)
async def my_profile(current_user: UserModel = Depends(deps.get_current_user), db: AsyncSession = Depends(get_db)) -> AgentProfile:
    return await _agent_profile(db, current_user)


@router.patch("/me/status", response_model=User)
async def update_my_status(
    payload: UserStatusUpdate,
    current_user: UserModel = Depends(deps.get_current_user),
    db: AsyncSession = Depends(get_db),
) -> UserModel:
    current_user.status = payload.status
    await db.commit()
    await db.refresh(current_user)
    return current_user


@router.get("/me/tickets", response_model=List[Ticket])
async def my_tickets(
    status_filter: str | None = Query(default=None, alias="status"),
    current_user: UserModel = Depends(deps.get_current_user),
    db: AsyncSession = Depends(get_db),
) -> List[TicketModel]:
    stmt = select(TicketModel).where(TicketModel.agent_id == current_user.id)
    if status_filter:
        stmt = stmt.where(TicketModel.status == status_filter)
    result = await db.execute(stmt.order_by(TicketModel.created_at.desc()))
    return list(result.scalars().all())


@router.get("", response_model=List[AgentProfile])
async def list_agents(
    _: UserModel = Depends(deps.get_current_admin),
    db: AsyncSession = Depends(get_db),
) -> List[AgentProfile]:
    agents = (await db.execute(select(UserModel).where(UserModel.role == "agent").order_by(UserModel.name))).scalars().all()
    return [await _agent_profile(db, agent) for agent in agents]
