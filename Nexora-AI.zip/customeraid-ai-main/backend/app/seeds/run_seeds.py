from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.core.security import get_password_hash
from app.db.base import Base
from app.db.session import AsyncSessionLocal, engine
from app.models.conversation import Conversation, Message
from app.models.knowledge import KnowledgeChunk, KnowledgeDocument
from app.models.settings import AISettings, CompanySettings, Integration
from app.models.ticket import ActivityLog, Ticket
from app.models.user import User


async def seed_data() -> None:
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    async with AsyncSessionLocal() as db:
        existing_admin = await db.execute(select(User).where(User.email == "admin@nexora.ma"))
        if existing_admin.scalars().first() is None:
            db.add_all(
                [
                    User(name="Admin User", email="admin@nexora.ma", password_hash=get_password_hash("admin123"), role="admin"),
                    User(name="Agent User", email="agent@nexora.ma", password_hash=get_password_hash("agent123"), role="agent"),
                ]
            )

        company_exists = await db.execute(select(CompanySettings).limit(1))
        if company_exists.scalars().first() is None:
            db.add(CompanySettings(name="Nexora AI Demo", sector="E-commerce", country="Maroc", timezone="Africa/Casablanca"))

        ai_exists = await db.execute(select(AISettings).limit(1))
        if ai_exists.scalars().first() is None:
            db.add(AISettings(model="gpt-4o-mini", temperature=0.3, system_prompt="Tu es l'assistant IA de Nexora."))

        integration_exists = await db.execute(select(Integration).limit(1))
        if integration_exists.scalars().first() is None:
            db.add_all(
                [
                    Integration(vendor="whatsapp", connected=True, credentials_metadata_json={"enabled": True}),
                    Integration(vendor="hubspot", connected=True, credentials_metadata_json={"enabled": True}),
                    Integration(vendor="salesforce", connected=False, credentials_metadata_json={"enabled": False}),
                ]
            )

        conversation_exists = await db.execute(select(Conversation).limit(1))
        if conversation_exists.scalars().first() is None:
            conversation = Conversation(customer="Karim El Idrissi", channel="whatsapp", last_message="Merci pour votre aide !", unread=0, takeover="ai", sentiment="positive")
            db.add(conversation)
            await db.flush()
            db.add_all(
                [
                    Message(conversation_id=conversation.id, role="user", content="Bonjour, où en est ma commande ?", sentiment="neutral", created_at=datetime.now(timezone.utc) - timedelta(minutes=6)),
                    Message(conversation_id=conversation.id, role="ai", content="Votre commande est en cours de livraison et arrive demain.", sentiment="positive", created_at=datetime.now(timezone.utc) - timedelta(minutes=5)),
                ]
            )

        knowledge_exists = await db.execute(select(KnowledgeDocument).limit(1))
        if knowledge_exists.scalars().first() is None:
            document = KnowledgeDocument(title="Politique de retour 2026.pdf", source="manual", content="Les retours sont acceptés sous 14 jours...", chunks=1, indexed_at=datetime.now(timezone.utc))
            db.add(document)
            await db.flush()
            db.add(KnowledgeChunk(document_id=document.id, chunk_index=0, content="Les retours sont acceptés sous 14 jours...", embedding=[0.01] * 1536, metadata_json={"title": document.title, "source": document.source}))

        ticket_exists = await db.execute(select(Ticket).limit(1))
        if ticket_exists.scalars().first() is None:
            db.add_all(
                [
                    Ticket(customer="Karim El Idrissi", intent="Suivi commande", priority="low", status="resolved", agent="IA — Auto", channel="WhatsApp", created_at=datetime.now(timezone.utc) - timedelta(days=2)),
                    Ticket(customer="Fatima Benali", intent="Réclamation facture", priority="high", status="progress", agent="Sara M.", channel="Web"),
                    Ticket(customer="Yassir Lamrini", intent="Demande de remboursement", priority="high", status="open", agent="Non assigné", channel="WhatsApp"),
                ]
            )

        activity_exists = await db.execute(select(ActivityLog).limit(1))
        if activity_exists.scalars().first() is None:
            db.add_all(
                [
                    ActivityLog(type="intent", payload_json={"text": "Intent détecté : Suivi de commande", "channel": "WhatsApp"}),
                    ActivityLog(type="resolved", payload_json={"text": "Ticket #4821 auto-résolu par l'IA", "channel": "Web"}),
                    ActivityLog(type="knowledge", payload_json={"text": "Base de connaissances mise à jour : Politique retours", "channel": "Système"}),
                ]
            )

        await db.commit()
        print("Seed data added successfully!")


if __name__ == "__main__":
    asyncio.run(seed_data())
