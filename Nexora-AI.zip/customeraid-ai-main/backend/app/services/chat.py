from __future__ import annotations

import re
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.conversation import Conversation, Message
from app.models.ticket import ActivityLog, Ticket
from app.models.user import User
from app.services.knowledge import knowledge_service
from app.services.llm import llm_service

# Maximum number of AI replies in a conversation before it is automatically
# handed over to a human agent (cost control + guarantees tickets get created).
AI_REPLY_CAP = 8

HANDOFF_MESSAGE = (
    "Merci pour votre patience ! Votre demande necessite l'attention d'un membre de notre equipe, "
    "qui prendra le relais de cette conversation tres prochainement."
)


def _detect_sentiment(text: str) -> str:
    lowered = text.lower()
    negative_markers = ["problem", "issue", "error", "delay", "late", "refund", "complaint", "pas reçu", "n'ai pas", "retard"]
    positive_markers = ["merci", "thanks", "great", "perfect", "resolved", "parfait", "bien"]
    if any(marker in lowered for marker in negative_markers):
        return "negative"
    if any(marker in lowered for marker in positive_markers):
        return "positive"
    return "neutral"


def _intent_from_text(text: str) -> str:
    lowered = text.lower()
    intents = {
        "order_tracking": ["order", "commande", "tracking", "delivery", "livraison"],
        "invoice": ["invoice", "facture", "bill"],
        "refund": ["refund", "remboursement"],
        "pricing": ["price", "pricing", "prix", "tarif"],
        "account_access": ["password", "mot de passe", "login", "connexion"],
    }
    for intent, markers in intents.items():
        if any(marker in lowered for marker in markers):
            return intent
    return "general_support"


class ChatService:
    async def get_conversations(self, db: AsyncSession) -> list[Conversation]:
        result = await db.execute(select(Conversation).order_by(Conversation.updated_at.desc().nullslast(), Conversation.created_at.desc()))
        return list(result.scalars().all())

    async def get_messages(self, db: AsyncSession, conversation_id: str) -> list[Message]:
        result = await db.execute(select(Message).where(Message.conversation_id == conversation_id).order_by(Message.created_at.asc()))
        return list(result.scalars().all())

    async def ensure_conversation(self, db: AsyncSession, conversation_id: str) -> Conversation:
        conversation = await db.get(Conversation, conversation_id)
        if conversation:
            return conversation
        conversation = Conversation(id=conversation_id, customer="New Visitor", channel="web", takeover="ai", sentiment="neutral", unread=0)
        db.add(conversation)
        await db.flush()
        return conversation

    async def add_message(self, db: AsyncSession, conversation_id: str, content: str, role: str) -> Message:
        conversation = await self.ensure_conversation(db, conversation_id)

        user_message = Message(
            conversation_id=conversation.id,
            role=role,
            content=content,
            sentiment=_detect_sentiment(content),
            metadata_json={"intent": _intent_from_text(content)},
            created_at=datetime.now(timezone.utc),
        )
        db.add(user_message)
        conversation.last_message = content
        conversation.sentiment = user_message.sentiment
        conversation.updated_at = datetime.now(timezone.utc)

        generated_message: Message | None = None
        if role == "user" and conversation.takeover == "ai":
            history = await self.get_messages(db, conversation.id)
            ai_reply_count = sum(1 for message in history if message.role == "ai")

            if ai_reply_count >= AI_REPLY_CAP:
                conversation.takeover = "human"
                generated_message = Message(
                    conversation_id=conversation.id,
                    role="ai",
                    content=HANDOFF_MESSAGE,
                    sentiment="neutral",
                    metadata_json={"handoff": True, "intent": _intent_from_text(content)},
                    created_at=datetime.now(timezone.utc),
                )
                db.add(generated_message)
                conversation.last_message = HANDOFF_MESSAGE
                await self._create_escalation_ticket(db, conversation, content)
            else:
                context_chunks = await knowledge_service.query_knowledge(db, content)
                context_text = "\n\n".join(chunk["text"] for chunk in context_chunks) or "No relevant knowledge base context was found."
                messages = [
                    {
                        "role": "system",
                        "content": (
                            "You are Nexora AI, a support assistant for a Moroccan and MENA call center SaaS. "
                            "Answer in the same language as the user whenever possible. Use only the provided knowledge context and conversation history. "
                            f"Context:\n{context_text}"
                        ),
                    }
                ]
                for history_message in history[-10:]:
                    messages.append(
                        {
                            "role": "assistant" if history_message.role == "ai" else "user",
                            "content": history_message.content,
                        }
                    )
                messages.append({"role": "user", "content": content})
                ai_content = await llm_service.get_chat_response(messages)
                generated_message = Message(
                    conversation_id=conversation.id,
                    role="ai",
                    content=ai_content,
                    sentiment=_detect_sentiment(ai_content),
                    metadata_json={"sources": [chunk["source"] for chunk in context_chunks], "intent": _intent_from_text(content)},
                    created_at=datetime.now(timezone.utc),
                )
                db.add(generated_message)
                conversation.last_message = ai_content
                conversation.sentiment = generated_message.sentiment

        db.add(ActivityLog(type="intent", payload_json={"conversation_id": conversation.id, "intent": _intent_from_text(content)}))
        await db.commit()
        await db.refresh(user_message)
        if generated_message:
            await db.refresh(generated_message)
            return generated_message
        return user_message

    async def _find_best_agent(self, db: AsyncSession, intent: str) -> User | None:
        online_agents = (
            await db.execute(select(User).where(User.role == "agent", User.status == "online"))
        ).scalars().all()
        if not online_agents:
            return None

        best_agent: User | None = None
        best_score = -1
        for agent in online_agents:
            intent_count = (
                await db.execute(
                    select(func.count())
                    .select_from(Ticket)
                    .where(Ticket.agent_id == agent.id, Ticket.intent == intent, Ticket.status == "resolved")
                )
            ).scalar() or 0
            total_resolved = (
                await db.execute(
                    select(func.count())
                    .select_from(Ticket)
                    .where(Ticket.agent_id == agent.id, Ticket.status == "resolved")
                )
            ).scalar() or 0
            score = intent_count * 10 + total_resolved
            if score > best_score:
                best_score = score
                best_agent = agent
        return best_agent

    async def _create_escalation_ticket(self, db: AsyncSession, conversation: Conversation, last_message: str) -> Ticket:
        existing = (
            await db.execute(select(Ticket).where(Ticket.conversation_id == conversation.id))
        ).scalars().first()
        if existing:
            return existing

        intent = _intent_from_text(last_message)
        priority = "high" if conversation.sentiment == "negative" else "medium" if conversation.sentiment == "neutral" else "low"
        assigned_agent = await self._find_best_agent(db, intent)

        ticket = Ticket(
            customer=conversation.customer,
            intent=intent,
            priority=priority,
            status="open",
            agent=assigned_agent.name if assigned_agent else "Non assigne",
            agent_id=assigned_agent.id if assigned_agent else None,
            channel=conversation.channel,
            conversation_id=conversation.id,
        )
        db.add(ticket)
        db.add(ActivityLog(type="escalation", payload_json={"conversation_id": conversation.id, "intent": intent, "agent": ticket.agent}))
        return ticket

    async def summarize_conversation(self, db: AsyncSession, conversation_id: str) -> dict[str, object]:
        messages = await self.get_messages(db, conversation_id)
        if not messages:
            return {"summary": "No conversation found.", "intents": [], "sentiment": "neutral"}

        transcript = "\n".join(f"{message.role}: {message.content}" for message in messages)
        intents = sorted({message.metadata_json.get("intent") for message in messages if message.metadata_json and message.metadata_json.get("intent")})
        sentiment_scores = {"positive": 0, "neutral": 0, "negative": 0}
        for message in messages:
            sentiment_scores[message.sentiment or "neutral"] += 1
        sentiment = max(sentiment_scores, key=sentiment_scores.get)

        summary = await llm_service.get_chat_response(
            [
                {
                    "role": "system",
                    "content": "Summarize the support conversation in one concise paragraph.",
                },
                {"role": "user", "content": transcript},
            ]
        )
        return {"summary": summary, "intents": intents or ["general_support"], "sentiment": sentiment}


chat_service = ChatService()
