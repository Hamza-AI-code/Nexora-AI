from __future__ import annotations

import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup
from pypdf import PdfReader
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.knowledge import KnowledgeChunk, KnowledgeDocument
from app.models.ticket import ActivityLog
from app.services.llm import llm_service


def _normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _chunk_text(text: str, chunk_size: int = 900, overlap: int = 120) -> list[str]:
    text = _normalize_whitespace(text)
    if not text:
        return []
    words = text.split(" ")
    chunks: list[str] = []
    start = 0
    while start < len(words):
        end = min(len(words), start + chunk_size)
        chunks.append(" ".join(words[start:end]))
        if end >= len(words):
            break
        start = max(0, end - overlap)
    return chunks


def _cosine_similarity(left: list[float], right: list[float]) -> float:
    if not left or not right:
        return 0.0
    length = min(len(left), len(right))
    left = left[:length]
    right = right[:length]
    dot = sum(l * r for l, r in zip(left, right))
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    if left_norm == 0 or right_norm == 0:
        return 0.0
    return dot / (left_norm * right_norm)


def _title_from_source(source: str, source_url: str | None = None) -> str:
    if source_url:
        parsed = urlparse(source_url)
        return parsed.netloc or source_url
    return source


class KnowledgeService:
    async def extract_text_from_upload(self, file_path: Path, filename: str) -> str:
        suffix = file_path.suffix.lower() or Path(filename).suffix.lower()
        if suffix == ".pdf":
            reader = PdfReader(str(file_path))
            return _normalize_whitespace("\n".join(page.extract_text() or "" for page in reader.pages))
        return _normalize_whitespace(file_path.read_text(encoding="utf-8", errors="ignore"))

    async def extract_text_from_url(self, url: str) -> tuple[str, str]:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            raise ValueError("Only http and https URLs are allowed")
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.get(url)
            response.raise_for_status()
        html = response.text
        soup = BeautifulSoup(html, "html.parser")
        title = _normalize_whitespace(soup.title.text if soup.title and soup.title.text else url)
        text = _normalize_whitespace(soup.get_text(" ", strip=True))
        return title, text

    async def ingest_document(
        self,
        db: AsyncSession,
        *,
        title: str,
        source: str = "manual",
        content: str | None = None,
        source_url: str | None = None,
        storage_path: str | None = None,
    ) -> KnowledgeDocument:
        if source not in {"pdf", "url", "manual"}:
            raise ValueError("Invalid source type")

        if content is None:
            if source == "url" and source_url:
                _, content = await self.extract_text_from_url(source_url)
            elif storage_path:
                content = await self.extract_text_from_upload(Path(storage_path), title)
            else:
                content = ""

        document = KnowledgeDocument(
            title=title,
            source=source,
            source_url=source_url,
            storage_path=storage_path,
            content=content,
            chunks=0,
            indexed_at=datetime.now(timezone.utc),
        )
        db.add(document)
        await db.flush()

        chunk_texts = _chunk_text(content)
        for index, chunk_text in enumerate(chunk_texts):
            embedding = await llm_service.get_embedding(chunk_text)
            db.add(
                KnowledgeChunk(
                    document_id=document.id,
                    chunk_index=index,
                    content=chunk_text,
                    embedding=embedding,
                    metadata_json={"title": title, "source": source, "source_url": source_url},
                )
            )

        document.chunks = len(chunk_texts)
        document.indexed_at = datetime.now(timezone.utc)
        await db.flush()
        db.add(ActivityLog(type="knowledge", payload_json={"document_id": document.id, "title": document.title}))
        await db.commit()
        await db.refresh(document)
        return document

    async def delete_document(self, db: AsyncSession, document_id: str) -> bool:
        document = await db.get(KnowledgeDocument, document_id)
        if not document:
            return False
        await db.delete(document)
        await db.commit()
        return True

    async def list_documents(self, db: AsyncSession) -> list[KnowledgeDocument]:
        result = await db.execute(select(KnowledgeDocument).order_by(KnowledgeDocument.updated_at.desc().nullslast(), KnowledgeDocument.created_at.desc()))
        return list(result.scalars().all())

    async def query_knowledge(self, db: AsyncSession, query: str, top_k: int = 3) -> list[dict[str, Any]]:
        query_embedding = await llm_service.get_embedding(query)
        result = await db.execute(select(KnowledgeChunk).join(KnowledgeDocument))
        chunks = list(result.scalars().all())
        scored: list[tuple[float, KnowledgeChunk]] = []
        for chunk in chunks:
            score = _cosine_similarity(query_embedding, list(chunk.embedding) if chunk.embedding is not None else [])
            scored.append((score, chunk))
        scored.sort(key=lambda item: item[0], reverse=True)
        output: list[dict[str, Any]] = []
        for score, chunk in scored[:top_k]:
            title = chunk.metadata_json.get("title") if chunk.metadata_json else None
            source_url = chunk.metadata_json.get("source_url") if chunk.metadata_json else None
            source_name = chunk.metadata_json.get("source") if chunk.metadata_json else None
            output.append(
                {
                    "text": chunk.content,
                    "score": round(float(score), 4),
                    "source": title or source_name or source_url or "Knowledge Base",
                }
            )
        return output

    async def reindex_document(self, db: AsyncSession, document_id: str | None = None) -> int:
        if document_id:
            documents = [await db.get(KnowledgeDocument, document_id)]
        else:
            result = await db.execute(select(KnowledgeDocument))
            documents = list(result.scalars().all())

        reindexed = 0
        for document in documents:
            if not document:
                continue
            await db.execute(delete(KnowledgeChunk).where(KnowledgeChunk.document_id == document.id))
            for index, chunk_text in enumerate(_chunk_text(document.content or "")):
                embedding = await llm_service.get_embedding(chunk_text)
                db.add(
                    KnowledgeChunk(
                        document_id=document.id,
                        chunk_index=index,
                        content=chunk_text,
                        embedding=embedding,
                        metadata_json={"title": document.title, "source": document.source, "source_url": document.source_url},
                    )
                )
            document.chunks = len(_chunk_text(document.content or ""))
            document.indexed_at = datetime.now(timezone.utc)
            reindexed += 1
        await db.commit()
        return reindexed


knowledge_service = KnowledgeService()
