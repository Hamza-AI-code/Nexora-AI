from __future__ import annotations

import asyncio
import hashlib
import math
from typing import Any

from openai import AsyncOpenAI

from app.core.config import settings


def _deterministic_vector(text: str, size: int = 1536) -> list[float]:
    seed = hashlib.sha256(text.encode("utf-8")).digest()
    values: list[float] = []
    while len(values) < size:
        seed = hashlib.sha256(seed).digest()
        values.extend((byte / 127.5) - 1.0 for byte in seed)
    return values[:size]


def _looks_arabic(text: str) -> bool:
    return any("\u0600" <= char <= "\u06ff" for char in text)


def _mock_response(messages: list[dict[str, str]]) -> str:
    user_text = next((message["content"] for message in reversed(messages) if message.get("role") == "user"), "")
    if _looks_arabic(user_text):
        return "هذا رد تجريبي من Nexora AI يعتمد على قاعدة المعرفة المتاحة."
    lowered = user_text.lower()
    french_markers = ["bonjour", "merci", "commande", "facture", "livraison", "retour", "support", "prix"]
    if any(marker in lowered for marker in french_markers):
        return "Réponse simulée de Nexora AI basée sur le contexte récupéré."
    return "Mock answer from Nexora AI based on the retrieved knowledge context."


class LLMService:
    def __init__(self) -> None:
        self.client = (
            AsyncOpenAI(api_key=settings.OPENAI_API_KEY, base_url=settings.OPENAI_BASE_URL or None)
            if settings.OPENAI_API_KEY
            else None
        )
        # Providers like Groq are OpenAI-compatible for chat but don't offer an
        # embeddings endpoint, so fall back to the deterministic mock vector.
        self.embeddings_available = bool(self.client) and not settings.OPENAI_BASE_URL

    async def get_embedding(self, text: str) -> list[float]:
        if not self.embeddings_available:
            return _deterministic_vector(text)
        response = await self.client.embeddings.create(model=settings.OPENAI_EMBEDDING_MODEL, input=text)
        return list(response.data[0].embedding)

    async def get_chat_response(self, messages: list[dict[str, str]], model: str | None = None, temperature: float | None = None) -> str:
        if not self.client:
            return _mock_response(messages)
        response = await self.client.chat.completions.create(
            model=model or settings.OPENAI_CHAT_MODEL,
            messages=messages,
            temperature=temperature if temperature is not None else 0.3,
        )
        return response.choices[0].message.content or ""


llm_service = LLMService()
