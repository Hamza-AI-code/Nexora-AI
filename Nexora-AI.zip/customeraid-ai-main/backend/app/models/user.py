from __future__ import annotations

import uuid

from sqlalchemy import DateTime, Enum, String
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func

from app.db.base_class import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    name: Mapped[str] = mapped_column(String, index=True)
    email: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String, nullable=False)
    role: Mapped[str] = mapped_column(Enum("admin", "agent", name="user_role"), default="agent")
    status: Mapped[str] = mapped_column(Enum("online", "offline", name="presence_status"), default="offline")
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now())
