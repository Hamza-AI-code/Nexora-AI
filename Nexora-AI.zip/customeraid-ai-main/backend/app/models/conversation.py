from __future__ import annotations

import uuid

from sqlalchemy import DateTime, Enum, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.db.base_class import Base


class Conversation(Base):
    __tablename__ = "conversations"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    customer: Mapped[str] = mapped_column(String, index=True)
    channel: Mapped[str] = mapped_column(Enum("whatsapp", "web", "voice", "facebook", "instagram", name="channel_type"), default="web")
    last_message: Mapped[str | None] = mapped_column(Text, default=None)
    unread: Mapped[int] = mapped_column(Integer, default=0)
    takeover: Mapped[str] = mapped_column(Enum("ai", "human", name="takeover_mode"), default="ai")
    sentiment: Mapped[str] = mapped_column(Enum("positive", "neutral", "negative", name="sentiment_type"), default="neutral")
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    conversation_id: Mapped[str] = mapped_column(String, ForeignKey("conversations.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(Enum("user", "ai", "agent", name="message_role"))
    content: Mapped[str] = mapped_column(Text, nullable=False)
    sentiment: Mapped[str] = mapped_column(Enum("positive", "neutral", "negative", name="message_sentiment"), default="neutral")
    metadata_json: Mapped[dict | None] = mapped_column("metadata", JSON, default=None)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now())

    conversation = relationship("Conversation", back_populates="messages")
