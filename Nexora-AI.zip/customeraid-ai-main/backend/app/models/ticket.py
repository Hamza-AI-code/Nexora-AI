from __future__ import annotations

import uuid

from sqlalchemy import DateTime, Enum, ForeignKey, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func

from app.db.base_class import Base


class Ticket(Base):
    __tablename__ = "tickets"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    customer: Mapped[str] = mapped_column(String, index=True)
    intent: Mapped[str] = mapped_column(String)
    priority: Mapped[str] = mapped_column(Enum("low", "medium", "high", name="priority_type"), default="medium")
    status: Mapped[str] = mapped_column(Enum("open", "progress", "resolved", "escalated", name="ticket_status"), default="open")
    agent: Mapped[str] = mapped_column(String, default="Unassigned")
    agent_id: Mapped[str | None] = mapped_column(String, ForeignKey("users.id"), default=None, index=True)
    channel: Mapped[str] = mapped_column(String)
    conversation_id: Mapped[str | None] = mapped_column(String, default=None, index=True)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), onupdate=func.now())


class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    type: Mapped[str] = mapped_column(Enum("intent", "resolved", "escalation", "knowledge", name="activity_type"))
    payload_json: Mapped[dict | None] = mapped_column("payload", JSON, default=None)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now())
