from __future__ import annotations

import uuid

from pgvector.sqlalchemy import Vector
from sqlalchemy import DateTime, Enum, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.db.base_class import Base


class KnowledgeDocument(Base):
    __tablename__ = "knowledge_documents"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    title: Mapped[str] = mapped_column(String, index=True)
    source: Mapped[str] = mapped_column(Enum("pdf", "url", "manual", name="source_type"))
    source_url: Mapped[str | None] = mapped_column(String, default=None)
    storage_path: Mapped[str | None] = mapped_column(String, default=None)
    content: Mapped[str | None] = mapped_column(Text, default=None)
    chunks: Mapped[int] = mapped_column(Integer, default=0)
    indexed_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), default=None)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    chunks_rel = relationship("KnowledgeChunk", back_populates="document", cascade="all, delete-orphan")


class KnowledgeChunk(Base):
    __tablename__ = "knowledge_chunks"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    document_id: Mapped[str] = mapped_column(String, ForeignKey("knowledge_documents.id", ondelete="CASCADE"), index=True)
    chunk_index: Mapped[int] = mapped_column(Integer)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    embedding: Mapped[list[float]] = mapped_column(Vector(1536))
    metadata_json: Mapped[dict | None] = mapped_column("metadata", JSON, default=None)
    created_at: Mapped[object] = mapped_column(DateTime(timezone=True), server_default=func.now())

    document = relationship("KnowledgeDocument", back_populates="chunks_rel")
