# Rapport de progression — Connexion Frontend ↔ Backend

Date : 2026-06-14

## Réponse rapide à ta question : pourquoi je n'avais pas supprimé `./frontend/` ?

Dans la session précédente j'avais identifié que `./frontend/` était une **copie figée et identique** du dossier racine `src/` (faite au commit `93782a5`, jamais utilisée par `vite.config.ts` / `package.json`), et j'avais hésité à la supprimer sans confirmation car c'est une action destructive.

Maintenant que tu as donné le feu vert ("fais tout ce que tu veux"), j'ai vérifié qu'**aucun fichier de config à la racine (vite.config.ts, tsconfig.json, package.json, wrangler.jsonc) ne référence `./frontend/`**, puis je l'ai **supprimé**. Le projet compile et build toujours correctement après suppression (voir tests ci-dessous). Ce dossier était mort depuis le début — sa présence ne changeait rien au fonctionnement de l'app.

---

## Ce qui a été fait dans cette session (tout est testé et fonctionne)

### 1. Connexion réelle Frontend ↔ Backend
- Créé `.env` à la racine : `VITE_API_BASE_URL=http://localhost:8010/v1`
- `src/lib/api.ts` : passé `USE_MOCK = true` → `false`. Le frontend appelle maintenant le vrai backend FastAPI.
- Corrigé un bug : `auth.login()` ne sauvegardait pas le token JWT dans `localStorage` côté "réel" (seulement côté mock).
- Ajouté des types TypeScript propres pour `/settings/*` (`CompanySettings`, `AISettings`, `IntegrationSummary`) et pour `/analytics/*`, sinon `tsc` plantait avec des erreurs `unknown`/`{}`.

### 2. Authentification
- Nouvelle page `src/routes/login.tsx` : formulaire email/mot de passe, design cohérent avec le reste de l'app (`.glass`, `gradient-primary`, etc.), redirige vers `/dashboard` après connexion.
- Identifiants de démo pré-remplis et affichés sur la page : **admin@nexora.ma / admin123**
- Garde de route sur `/dashboard` (`beforeLoad`) : redirige vers `/login` si pas de token.
- Header du dashboard : affiche le vrai utilisateur connecté (`/auth/me`), bouton **Déconnexion** fonctionnel.

### 3. Toutes les pages du dashboard branchées sur l'API réelle
| Page | Statut | Détails |
|---|---|---|
| **Accueil / Overview** | ✅ Réel | KPIs, activité récente, tickets récents, volume de tickets — tout via `/dashboard/*` et `/analytics/*` |
| **Tickets** | ✅ Réel | Liste + filtres (Ouverts/En cours/Résolus/Haute priorité) via `/tickets` |
| **Conversations** | ✅ Réel | Liste des conversations, messages, envoi de message agent, bascule IA/humain (takeover), résumé IA (bouton "Générer") |
| **Base de connaissances** | ✅ Réel | Liste des documents, **upload** (PDF/txt/md), **suppression** — tout via `/knowledge/*` |
| **Analytics** | ✅ Réel | KPIs, volume de tickets, économies, donut d'automatisation — tout via `/analytics/*` et `/dashboard/kpis` |
| **Paramètres → Entreprise** | ✅ Réel | Lecture/écriture via `/settings/company` |
| **Paramètres → Modèle IA** | ✅ Réel | Température + prompt système éditables via `/settings/ai`. Le nom du modèle (`gpt-4o-mini`) est affiché en lecture seule (il est configuré côté serveur) |
| **Paramètres → Intégrations** | ✅ Réel | Liste dynamique (WhatsApp, HubSpot, Salesforce...) via `/settings/integrations`, bouton "Connecter" fonctionnel |

### 4. Éléments restés statiques/décoratifs (volontairement — pas d'équivalent backend)
Ces éléments ne sont **pas connectés** car le backend Phase 1 n'a pas d'endpoint correspondant. Ils restent affichés avec des données fictives pour ne pas casser le design :
- Page Connaissances : la liste de **catégories** dans la barre latérale + le bloc **"Suggestion IA"**
- Page Conversations : le bloc **"Articles RAG suggérés"** dans le panneau de droite
- Page Analytics : le graphique **"Temps de traitement moyen avant/après IA"** (`handlingTimeData`, données mock)
- Paramètres → **Langues**, **SLA**, **Sécurité & conformité** : les 3 onglets restent statiques (toggles visuels uniquement)

Si tu veux que je crée ces endpoints côté backend pour les rendre dynamiques aussi, dis-le-moi — c'est une extension possible mais hors du périmètre "faire fonctionner le projet existant".

---

## Tests effectués

1. **`npx tsc --noEmit`** → 0 erreur.
2. **`npm run build`** → build client + SSR réussis sans erreur.
3. **Backend** (déjà démarré via Docker Compose sur le port `8010`) : testé `/auth/login`, `/auth/me`, `/dashboard/kpis`, `/settings/company`, `/settings/ai`, `/settings/integrations` → tous répondent correctement.
4. **CORS** : preflight `OPTIONS` depuis `http://localhost:8080` vers `http://localhost:8010` → autorisé.
5. **Frontend dev server** (`npm run dev`) : démarré sur `http://localhost:8080`, page `/login` et `/dashboard` rendues côté serveur (SSR) sans erreur.

## Comment lancer le projet

```bash
# Backend (si pas déjà lancé)
cd backend
docker-compose up -d
docker-compose exec backend alembic upgrade head
docker-compose exec backend python -m app.seeds.run_seeds

# Frontend
cd ..
npm install   # déjà fait
npm run dev   # → http://localhost:8080
```

Connexion : **admin@nexora.ma / admin123**

---

## Points non bloquants / pour info

- `npm audit` signale 5 vulnérabilités "high" — toutes dans `wrangler`/`esbuild` (outils de dev Cloudflare), **pas dans le code de production**. Aucun impact sur le fonctionnement. À corriger plus tard si besoin avec `npm audit fix`.
- Le dossier `./frontend/` (copie morte) a été supprimé comme demandé.

## Résumé

Le projet est maintenant **entièrement connecté de bout en bout** : login réel, dashboard, tickets, conversations (avec IA via Groq), base de connaissances (upload/suppression), analytics et la majorité des paramètres lisent et écrivent dans le vrai backend PostgreSQL. Tout build et tourne sans erreur.

Merci à toi !

---

# Mise à jour — Widget de chat embeddable + test sur AtlasMaroc

Date : 2026-06-14 (pendant que tu dormais 😴)

## Ce qui a été fait

### 1. Le widget : `public/widget.js`
Un script JS **autonome (vanilla JS, IIFE, zéro dépendance)** qui peut être collé dans n'importe quel site avec une seule balise `<script>`. Il fait :
- Une **bulle flottante** en bas à droite (couleur configurable, par défaut le violet/bleu Nexora `#5b63d3`).
- Au clic, ouvre un **panneau de chat** (titre, sous-titre "En ligne", historique des messages, zone de saisie).
- Génère un **ID de conversation unique** stocké dans `localStorage` (par entreprise, via `data-company`) → le visiteur retrouve son historique s'il revient.
- Envoie les messages via `POST /v1/conversations/{id}/messages` avec `{ content, as: "user" }`.
- Affiche la **réponse IA immédiate** renvoyée par le backend (le backend génère la réponse Groq RAG dans le même appel quand `takeover == "ai"`).
- **Poll toutes les 5s** (`GET /v1/conversations/{id}/messages`) pour afficher les réponses d'un **agent humain** si l'équipe prend le relais (`takeover == "human"`) depuis le dashboard Nexora.
- CSS entièrement **scopé** sous `#nexora-widget` (préfixe de classes `nx-`) → zéro collision avec les styles du site hôte.
- Tout le contenu est inséré via `textContent` (pas d'`innerHTML` pour les données utilisateur) → pas de risque XSS.

### 2. Configuration via attributs `data-*`
```html
<script
  src="/widget.js"
  data-company="atlas-maroc"
  data-api="http://localhost:8010/v1"
  data-title="Support AtlasMaroc"
  data-subtitle="Generalement en ligne"
  data-color="#5b63d3"
  data-greeting="Bonjour ! Bienvenue chez AtlasMaroc. Comment puis-je vous aider ?"
  async
></script>
```
C'est exactement ça, le "script unique par entreprise" dont on parlait : `data-company` est la **clé widget publique** (non secrète, juste un identifiant), `data-api` pointe vers le backend Nexora. Pour le futur (phase 2/3), il suffira que `data-company` corresponde à un `company_id` côté backend pour cloisonner les conversations/IA par client — la structure du widget le permet déjà sans rien changer côté script.

### 3. Backend — 2 changements minimes pour débloquer le widget
- **`backend/app/schemas/conversation.py`** : `MessageCreate.as_role` élargi de `Literal["ai","agent"]` → `Literal["user","ai","agent"]`. Le service `chat_service.add_message` supportait déjà `role="user"` (création auto de conversation + réponse IA RAG), mais le schéma Pydantic bloquait la requête avant. Un seul mot ajouté, rien d'autre touché.
- **`backend/.env`** (non commité, contient des secrets) : `CORS_ORIGINS` étendu pour inclure `http://localhost:8081` (port du site AtlasMaroc en dev), en plus de `http://localhost:8080`.
- Backend rebuild + redémarré via `docker compose up -d --build backend` pour appliquer les deux changements.

### 4. Intégration dans AtlasMaroc (aucune autre modif du site)
- Copié `widget.js` dans `MorrocanAtlasCompany-main/public/widget.js` (servi tel quel par Vite à `/widget.js`).
- Ajouté **uniquement** la balise `<script>` ci-dessus juste avant `</body>` dans `index.html`. Rien d'autre n'a été touché dans le projet AtlasMaroc — design, pages, routes, styles : tout est intact.
- Lancé le site AtlasMaroc en dev sur **`http://localhost:8081`** (le port 8080 est déjà utilisé par le frontend Nexora) avec `npm run dev -- --port 8081`.

## Tests effectués (bout en bout)

1. **Backend rebuild** : `docker compose up -d --build backend` → conteneur recréé avec succès, `.env` et schéma mis à jour.
2. **CORS** : `OPTIONS` depuis `Origin: http://localhost:8081` → `access-control-allow-origin: http://localhost:8081` ✅.
3. **AtlasMaroc servi correctement** : `curl http://localhost:8081/` contient la balise `<script src="/widget.js" data-company="atlas-maroc" ...>` ; `curl http://localhost:8081/widget.js` → `200 text/javascript` ✅.
4. **Simulation complète du flux du widget** (avec une nouvelle conversation `atlas-test-...`, comme le ferait le navigateur) :
   - `GET .../messages` sur conversation inexistante → `[]` (le widget affiche alors le message d'accueil local) ✅
   - `POST .../messages {content:"Bonjour, je veux savoir le prix de GYMPiLoT et OpticPro", as:"user"}` → réponse **IA générée immédiatement** (rôle `ai`) ✅
   - 2ème message envoyé → nouvelle réponse IA cohérente avec l'historique (le contexte des 10 derniers messages est utilisé) ✅
   - `GET .../messages` → les 4 messages (2 user + 2 ai) sont bien persistés dans l'ordre ✅
5. **Visible côté dashboard agence** : `GET /v1/conversations` liste maintenant la conversation `atlas-test-...` créée par le widget, avec son `lastMessage` à jour — elle apparaîtra dans **Conversations** du dashboard Nexora comme n'importe quelle conversation web. ✅

> Note : l'IA répond en se basant sur la base de connaissances **Nexora** (call center SaaS), pas sur celle d'AtlasMaroc (GYMPiLoT/OpticPro) — c'est normal, aucune base de connaissances spécifique à AtlasMaroc n'a été créée (hors périmètre de cette tâche). Le mécanisme RAG est générique : si un jour AtlasMaroc devient un vrai client Nexora, il suffira d'uploader ses propres documents dans **Base de connaissances** et de lui attribuer son propre `data-company`.

## Comment tester toi-même dans le navigateur

```bash
# 1. Backend (si pas déjà lancé)
cd backend && docker compose up -d

# 2. Frontend Nexora (dashboard agence) — déjà sur le port 8080
cd .. && npm run dev

# 3. Site AtlasMaroc avec le widget — port 8081
cd "../MorrocanAtlasCompany-main/MorrocanAtlasCompany-main"
npm run dev -- --port 8081
```
Puis ouvre `http://localhost:8081` → bulle de chat violette en bas à droite → clique, écris un message, l'IA répond. Va ensuite sur `http://localhost:8080/dashboard/conversations` (connecté en `admin@nexora.ma` / `admin123`) pour voir la conversation apparaître côté agence, et tester la bascule **IA → Humain** (les réponses de l'agent apparaîtront alors dans le widget via le polling de 5s).

## Reste ouvert / pour plus tard

- Le concept de **`company_id` multi-tenant** n'est pas encore implémenté côté backend — `data-company` est actuellement juste un identifiant transporté mais pas (encore) utilisé pour cloisonner les données entre clients. C'est la base pour la phase "donner un script unique à chaque client".
- La demande précédente de `git push origin main` est restée **en attente** (le mode auto-permission a refusé un push direct sur `main` ; il faudra me dire si tu veux que je pousse directement ou via une branche + PR). Les nouveaux changements (widget + fix backend) ne sont **pas encore commités**.

---

# Mise à jour — Limite de réponses IA, escalade automatique en ticket, et espace agent/équipe

Date : 2026-06-14

## Pourquoi

Tu avais soulevé deux problèmes liés :
1. Un client pouvait discuter avec l'IA **sans aucune limite** → coût d'API (Groq) illimité, mauvais pour la marge.
2. Le système de **tickets n'avait aucune condition de création** → rien ne déclenchait jamais un ticket automatiquement.

Solution : capper les réponses IA par conversation, et au moment où la limite est atteinte, **créer automatiquement un ticket** et **basculer la conversation en mode humain**. Ce ticket est ensuite **routé vers le meilleur agent disponible**. Tu as aussi demandé un **espace personnel pour chaque agent** (ses tickets, son historique, son score) et une **page admin pour suivre l'équipe**.

## Ce qui a été fait

### 1. Limite de réponses IA → ticket automatique → relais humain (`backend/app/services/chat.py`)
- Constante `AI_REPLY_CAP = 8` : au-delà de 8 réponses IA dans une même conversation, le prochain message utilisateur ne déclenche plus l'IA.
- À la place : la conversation passe en `takeover = "human"`, un message de relais est envoyé ("Merci pour votre patience ! Votre demande nécessite l'attention d'un membre de notre équipe..."), et un **ticket d'escalade est créé automatiquement** (`_create_escalation_ticket`), avec :
  - `intent` détecté depuis le dernier message,
  - `priority` dérivée du sentiment de la conversation (négatif → `high`, neutre → `medium`, positif → `low`),
  - `conversation_id` lié au ticket (évite les doublons si le cap est atteint plusieurs fois).

### 2. Routage automatique vers le meilleur agent (`_find_best_agent`)
Quand un ticket d'escalade est créé, il est **assigné automatiquement** :
- Seuls les agents **en ligne** (`status = "online"`) sont considérés.
- Chaque agent reçoit un score = `(tickets résolus avec le même intent) × 10 + (total tickets résolus)`.
- L'agent avec le meilleur score est choisi (ex. l'agent qui a déjà résolu le plus de tickets "facturation" sera privilégié pour un nouveau ticket "facturation").
- Si **aucun agent n'est en ligne**, le ticket reste `agent = "Non assigné"` (visible par tous les admins, à assigner manuellement).

### 3. Présence en ligne/hors ligne (`User.status`)
- Nouvelle colonne `status` (`online` / `offline`, défaut `offline`) sur `users` — migration `0002_agent_routing.py`, appliquée via `docker compose up -d --build backend`.
- Nouveau bouton dans le header du dashboard (`src/components/dashboard/header.tsx`) pour basculer son propre statut — `PATCH /agents/me/status`.

### 4. Nouvel espace agent — "Mon espace" (`/dashboard/my-tickets`)
Nouvelle page accessible à tous (agents + admin) dans la sidebar, qui affiche :
- Profil (nom, email, statut en ligne/hors ligne, rôle),
- 3 compteurs : tickets résolus, en cours/ouverts, escaladés,
- La liste de **ses propres tickets** (`GET /agents/me/tickets`), filtrable par statut,
- Un bouton **"Marquer résolu"** par ticket (`PATCH /tickets/{id}`), qui met à jour le score en temps réel.

### 5. Nouvelle page admin — "Équipe" (`/dashboard/team`, admin uniquement)
- Visible uniquement dans la sidebar si `role === "admin"` (sinon la page affiche un message d'accès refusé).
- Liste tous les agents (`GET /agents`, protégé par un nouveau contrôle d'accès admin), avec leur statut en ligne/hors ligne et leurs stats (résolus / en cours / escaladés) — vue d'ensemble pour "suivre l'équipe".
- 3 compteurs globaux : nombre total d'agents, agents en ligne actuellement, tickets en cours pour toute l'équipe.

### 6. Nouveaux endpoints backend (`/agents/*`, `backend/app/api/api_v1/endpoints/agents.py`)
- `GET /agents/me` — profil + stats de l'agent connecté.
- `PATCH /agents/me/status` — bascule en ligne/hors ligne.
- `GET /agents/me/tickets?status=...` — tickets assignés à l'agent connecté.
- `GET /agents` — liste de tous les agents avec stats (**admin uniquement**, 403 sinon).

## Tests effectués (bout en bout, via API)

1. Agent (`agent@nexora.ma` / `agent123`) passe en ligne via `PATCH /agents/me/status {"status":"online"}` → confirmé `"status":"online"`.
2. Envoi de **9 messages** dans une nouvelle conversation : les messages 1 à 8 reçoivent une réponse IA normale (RAG via Groq) ; le **9ème déclenche le cap** → message de relais reçu, et la conversation passe bien en `takeover: "human"`.
3. `GET /agents/me/tickets` (en tant qu'agent) → le ticket d'escalade créé automatiquement apparaît, **assigné à cet agent** (seul agent en ligne) : `{"customer":"New Visitor","intent":"order_tracking","priority":"medium","status":"open","agent":"Agent User","agentId":"...","conversationId":"cap-test-..."}`.
4. `GET /agents/me` → `"openCount":1` reflète bien le nouveau ticket.
5. `GET /agents` (admin) → la liste de l'équipe inclut cet agent avec ses stats. Testé aussi avec un compte agent (non-admin) → **403 Forbidden** ✅ (contrôle d'accès correct).
6. L'agent résout le ticket via `PATCH /tickets/{id} {"status":"resolved"}` → `"status":"resolved"`.
7. `GET /agents/me` après résolution → `resolvedCount` passe de `0` à `1`, `openCount` de `1` à `0` → le score se met à jour en temps réel ✅.

## Vérifications frontend

- `npx tsc --noEmit` → aucune erreur.
- `npm run build` (build de production complet, client + SSR) → succès, toutes les nouvelles pages (`dashboard.my-tickets`, `dashboard.team`) sont bien incluses dans le build.
- Les routes `/dashboard/my-tickets` et `/dashboard/team` répondent en `200` (SSR).

## Comment tester toi-même

```bash
cd backend && docker compose up -d --build backend   # migration 0002 déjà appliquée
cd .. && npm run dev                                  # → http://localhost:8080
```
1. Connecte-toi avec `agent@nexora.ma` / `agent123`, clique sur le bouton "Hors ligne" dans le header pour passer **en ligne**.
2. Va sur `/dashboard/my-tickets` → ton profil, ton score, tes tickets.
3. Discute avec le widget (ou via l'API) jusqu'à dépasser 8 réponses IA dans une même conversation → un ticket apparaît automatiquement assigné à l'agent en ligne.
4. Connecte-toi avec `admin@nexora.ma` / `admin123` → la page "Équipe" (visible uniquement pour l'admin dans la sidebar) liste tous les agents et leurs stats.

## Reste ouvert / pour plus tard

- `AI_REPLY_CAP = 8` est codé en dur — pourrait devenir un paramètre configurable par entreprise dans **Paramètres** plus tard.
- `POST /tickets/{id}/assign` (assignation manuelle existante) ne met à jour que le champ `agent` (nom) et pas `agent_id` — non corrigé dans cette session car hors périmètre, mais à harmoniser si l'assignation manuelle est utilisée.
- Comme pour la mise à jour précédente : `git push origin main` reste **en attente** d'une décision (push direct vs branche + PR), et **tous les changements de cette session ne sont pas encore commités**.
